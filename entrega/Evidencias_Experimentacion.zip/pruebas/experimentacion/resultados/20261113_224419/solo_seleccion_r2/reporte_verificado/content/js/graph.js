/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 1.0, "minX": 0.0, "maxY": 209.0, "series": [{"data": [[0.0, 1.0], [0.1, 1.0], [0.2, 1.0], [0.3, 2.0], [0.4, 2.0], [0.5, 2.0], [0.6, 2.0], [0.7, 2.0], [0.8, 2.0], [0.9, 2.0], [1.0, 2.0], [1.1, 2.0], [1.2, 2.0], [1.3, 2.0], [1.4, 2.0], [1.5, 2.0], [1.6, 2.0], [1.7, 2.0], [1.8, 2.0], [1.9, 2.0], [2.0, 2.0], [2.1, 2.0], [2.2, 2.0], [2.3, 3.0], [2.4, 3.0], [2.5, 3.0], [2.6, 3.0], [2.7, 3.0], [2.8, 3.0], [2.9, 3.0], [3.0, 3.0], [3.1, 3.0], [3.2, 3.0], [3.3, 3.0], [3.4, 3.0], [3.5, 3.0], [3.6, 3.0], [3.7, 3.0], [3.8, 3.0], [3.9, 3.0], [4.0, 3.0], [4.1, 3.0], [4.2, 3.0], [4.3, 3.0], [4.4, 3.0], [4.5, 3.0], [4.6, 3.0], [4.7, 3.0], [4.8, 3.0], [4.9, 3.0], [5.0, 3.0], [5.1, 3.0], [5.2, 3.0], [5.3, 3.0], [5.4, 3.0], [5.5, 3.0], [5.6, 3.0], [5.7, 3.0], [5.8, 3.0], [5.9, 3.0], [6.0, 3.0], [6.1, 3.0], [6.2, 3.0], [6.3, 3.0], [6.4, 3.0], [6.5, 3.0], [6.6, 3.0], [6.7, 3.0], [6.8, 3.0], [6.9, 3.0], [7.0, 3.0], [7.1, 3.0], [7.2, 3.0], [7.3, 3.0], [7.4, 3.0], [7.5, 3.0], [7.6, 3.0], [7.7, 3.0], [7.8, 3.0], [7.9, 3.0], [8.0, 3.0], [8.1, 3.0], [8.2, 3.0], [8.3, 3.0], [8.4, 3.0], [8.5, 3.0], [8.6, 3.0], [8.7, 3.0], [8.8, 3.0], [8.9, 3.0], [9.0, 3.0], [9.1, 3.0], [9.2, 3.0], [9.3, 3.0], [9.4, 3.0], [9.5, 3.0], [9.6, 3.0], [9.7, 3.0], [9.8, 3.0], [9.9, 3.0], [10.0, 3.0], [10.1, 3.0], [10.2, 3.0], [10.3, 3.0], [10.4, 3.0], [10.5, 3.0], [10.6, 3.0], [10.7, 3.0], [10.8, 3.0], [10.9, 3.0], [11.0, 3.0], [11.1, 3.0], [11.2, 3.0], [11.3, 3.0], [11.4, 3.0], [11.5, 3.0], [11.6, 3.0], [11.7, 3.0], [11.8, 3.0], [11.9, 3.0], [12.0, 3.0], [12.1, 3.0], [12.2, 3.0], [12.3, 3.0], [12.4, 3.0], [12.5, 3.0], [12.6, 3.0], [12.7, 3.0], [12.8, 3.0], [12.9, 3.0], [13.0, 3.0], [13.1, 3.0], [13.2, 3.0], [13.3, 3.0], [13.4, 3.0], [13.5, 3.0], [13.6, 3.0], [13.7, 3.0], [13.8, 3.0], [13.9, 3.0], [14.0, 3.0], [14.1, 3.0], [14.2, 3.0], [14.3, 3.0], [14.4, 3.0], [14.5, 3.0], [14.6, 4.0], [14.7, 4.0], [14.8, 4.0], [14.9, 4.0], [15.0, 4.0], [15.1, 4.0], [15.2, 4.0], [15.3, 4.0], [15.4, 4.0], [15.5, 4.0], [15.6, 4.0], [15.7, 4.0], [15.8, 4.0], [15.9, 4.0], [16.0, 4.0], [16.1, 4.0], [16.2, 4.0], [16.3, 4.0], [16.4, 4.0], [16.5, 4.0], [16.6, 4.0], [16.7, 4.0], [16.8, 4.0], [16.9, 4.0], [17.0, 4.0], [17.1, 4.0], [17.2, 4.0], [17.3, 4.0], [17.4, 4.0], [17.5, 4.0], [17.6, 4.0], [17.7, 4.0], [17.8, 4.0], [17.9, 4.0], [18.0, 4.0], [18.1, 4.0], [18.2, 4.0], [18.3, 4.0], [18.4, 4.0], [18.5, 4.0], [18.6, 4.0], [18.7, 4.0], [18.8, 4.0], [18.9, 4.0], [19.0, 4.0], [19.1, 4.0], [19.2, 4.0], [19.3, 4.0], [19.4, 4.0], [19.5, 4.0], [19.6, 4.0], [19.7, 4.0], [19.8, 4.0], [19.9, 4.0], [20.0, 4.0], [20.1, 4.0], [20.2, 4.0], [20.3, 4.0], [20.4, 4.0], [20.5, 4.0], [20.6, 4.0], [20.7, 4.0], [20.8, 4.0], [20.9, 4.0], [21.0, 4.0], [21.1, 4.0], [21.2, 4.0], [21.3, 4.0], [21.4, 4.0], [21.5, 4.0], [21.6, 4.0], [21.7, 4.0], [21.8, 4.0], [21.9, 4.0], [22.0, 4.0], [22.1, 4.0], [22.2, 4.0], [22.3, 4.0], [22.4, 4.0], [22.5, 4.0], [22.6, 4.0], [22.7, 4.0], [22.8, 4.0], [22.9, 4.0], [23.0, 4.0], [23.1, 4.0], [23.2, 4.0], [23.3, 4.0], [23.4, 4.0], [23.5, 4.0], [23.6, 4.0], [23.7, 4.0], [23.8, 4.0], [23.9, 4.0], [24.0, 4.0], [24.1, 4.0], [24.2, 4.0], [24.3, 4.0], [24.4, 4.0], [24.5, 4.0], [24.6, 4.0], [24.7, 4.0], [24.8, 4.0], [24.9, 4.0], [25.0, 4.0], [25.1, 4.0], [25.2, 4.0], [25.3, 4.0], [25.4, 4.0], [25.5, 4.0], [25.6, 4.0], [25.7, 4.0], [25.8, 4.0], [25.9, 4.0], [26.0, 4.0], [26.1, 4.0], [26.2, 4.0], [26.3, 4.0], [26.4, 4.0], [26.5, 4.0], [26.6, 4.0], [26.7, 4.0], [26.8, 4.0], [26.9, 4.0], [27.0, 4.0], [27.1, 4.0], [27.2, 4.0], [27.3, 4.0], [27.4, 4.0], [27.5, 4.0], [27.6, 4.0], [27.7, 4.0], [27.8, 4.0], [27.9, 4.0], [28.0, 4.0], [28.1, 4.0], [28.2, 4.0], [28.3, 4.0], [28.4, 4.0], [28.5, 4.0], [28.6, 4.0], [28.7, 4.0], [28.8, 4.0], [28.9, 4.0], [29.0, 4.0], [29.1, 4.0], [29.2, 4.0], [29.3, 4.0], [29.4, 4.0], [29.5, 4.0], [29.6, 4.0], [29.7, 4.0], [29.8, 4.0], [29.9, 4.0], [30.0, 4.0], [30.1, 4.0], [30.2, 4.0], [30.3, 4.0], [30.4, 4.0], [30.5, 4.0], [30.6, 4.0], [30.7, 4.0], [30.8, 4.0], [30.9, 4.0], [31.0, 4.0], [31.1, 4.0], [31.2, 4.0], [31.3, 4.0], [31.4, 4.0], [31.5, 4.0], [31.6, 4.0], [31.7, 4.0], [31.8, 4.0], [31.9, 4.0], [32.0, 4.0], [32.1, 4.0], [32.2, 4.0], [32.3, 4.0], [32.4, 4.0], [32.5, 4.0], [32.6, 4.0], [32.7, 4.0], [32.8, 4.0], [32.9, 4.0], [33.0, 4.0], [33.1, 4.0], [33.2, 4.0], [33.3, 4.0], [33.4, 4.0], [33.5, 4.0], [33.6, 4.0], [33.7, 4.0], [33.8, 4.0], [33.9, 4.0], [34.0, 4.0], [34.1, 4.0], [34.2, 4.0], [34.3, 4.0], [34.4, 4.0], [34.5, 4.0], [34.6, 4.0], [34.7, 4.0], [34.8, 4.0], [34.9, 4.0], [35.0, 4.0], [35.1, 4.0], [35.2, 4.0], [35.3, 4.0], [35.4, 4.0], [35.5, 5.0], [35.6, 5.0], [35.7, 5.0], [35.8, 5.0], [35.9, 5.0], [36.0, 5.0], [36.1, 5.0], [36.2, 5.0], [36.3, 5.0], [36.4, 5.0], [36.5, 5.0], [36.6, 5.0], [36.7, 5.0], [36.8, 5.0], [36.9, 5.0], [37.0, 5.0], [37.1, 5.0], [37.2, 5.0], [37.3, 5.0], [37.4, 5.0], [37.5, 5.0], [37.6, 5.0], [37.7, 5.0], [37.8, 5.0], [37.9, 5.0], [38.0, 5.0], [38.1, 5.0], [38.2, 5.0], [38.3, 5.0], [38.4, 5.0], [38.5, 5.0], [38.6, 5.0], [38.7, 5.0], [38.8, 5.0], [38.9, 5.0], [39.0, 5.0], [39.1, 5.0], [39.2, 5.0], [39.3, 5.0], [39.4, 5.0], [39.5, 5.0], [39.6, 5.0], [39.7, 5.0], [39.8, 5.0], [39.9, 5.0], [40.0, 5.0], [40.1, 5.0], [40.2, 5.0], [40.3, 5.0], [40.4, 5.0], [40.5, 5.0], [40.6, 5.0], [40.7, 5.0], [40.8, 5.0], [40.9, 5.0], [41.0, 5.0], [41.1, 5.0], [41.2, 5.0], [41.3, 5.0], [41.4, 5.0], [41.5, 5.0], [41.6, 5.0], [41.7, 5.0], [41.8, 5.0], [41.9, 5.0], [42.0, 5.0], [42.1, 5.0], [42.2, 5.0], [42.3, 5.0], [42.4, 5.0], [42.5, 5.0], [42.6, 5.0], [42.7, 5.0], [42.8, 5.0], [42.9, 5.0], [43.0, 5.0], [43.1, 5.0], [43.2, 5.0], [43.3, 5.0], [43.4, 5.0], [43.5, 5.0], [43.6, 5.0], [43.7, 5.0], [43.8, 5.0], [43.9, 5.0], [44.0, 5.0], [44.1, 5.0], [44.2, 5.0], [44.3, 5.0], [44.4, 5.0], [44.5, 5.0], [44.6, 5.0], [44.7, 5.0], [44.8, 5.0], [44.9, 5.0], [45.0, 5.0], [45.1, 5.0], [45.2, 5.0], [45.3, 5.0], [45.4, 5.0], [45.5, 5.0], [45.6, 5.0], [45.7, 5.0], [45.8, 5.0], [45.9, 5.0], [46.0, 5.0], [46.1, 5.0], [46.2, 5.0], [46.3, 5.0], [46.4, 5.0], [46.5, 5.0], [46.6, 5.0], [46.7, 5.0], [46.8, 5.0], [46.9, 5.0], [47.0, 5.0], [47.1, 5.0], [47.2, 5.0], [47.3, 5.0], [47.4, 5.0], [47.5, 5.0], [47.6, 5.0], [47.7, 5.0], [47.8, 5.0], [47.9, 5.0], [48.0, 5.0], [48.1, 5.0], [48.2, 5.0], [48.3, 5.0], [48.4, 5.0], [48.5, 5.0], [48.6, 5.0], [48.7, 5.0], [48.8, 5.0], [48.9, 5.0], [49.0, 5.0], [49.1, 5.0], [49.2, 5.0], [49.3, 5.0], [49.4, 5.0], [49.5, 5.0], [49.6, 5.0], [49.7, 5.0], [49.8, 5.0], [49.9, 5.0], [50.0, 5.0], [50.1, 5.0], [50.2, 5.0], [50.3, 5.0], [50.4, 5.0], [50.5, 5.0], [50.6, 5.0], [50.7, 5.0], [50.8, 5.0], [50.9, 5.0], [51.0, 5.0], [51.1, 5.0], [51.2, 5.0], [51.3, 5.0], [51.4, 5.0], [51.5, 5.0], [51.6, 5.0], [51.7, 5.0], [51.8, 5.0], [51.9, 5.0], [52.0, 5.0], [52.1, 5.0], [52.2, 5.0], [52.3, 5.0], [52.4, 5.0], [52.5, 5.0], [52.6, 5.0], [52.7, 5.0], [52.8, 5.0], [52.9, 5.0], [53.0, 5.0], [53.1, 5.0], [53.2, 5.0], [53.3, 5.0], [53.4, 5.0], [53.5, 5.0], [53.6, 5.0], [53.7, 5.0], [53.8, 5.0], [53.9, 5.0], [54.0, 5.0], [54.1, 5.0], [54.2, 5.0], [54.3, 6.0], [54.4, 6.0], [54.5, 6.0], [54.6, 6.0], [54.7, 6.0], [54.8, 6.0], [54.9, 6.0], [55.0, 6.0], [55.1, 6.0], [55.2, 6.0], [55.3, 6.0], [55.4, 6.0], [55.5, 6.0], [55.6, 6.0], [55.7, 6.0], [55.8, 6.0], [55.9, 6.0], [56.0, 6.0], [56.1, 6.0], [56.2, 6.0], [56.3, 6.0], [56.4, 6.0], [56.5, 6.0], [56.6, 6.0], [56.7, 6.0], [56.8, 6.0], [56.9, 6.0], [57.0, 6.0], [57.1, 6.0], [57.2, 6.0], [57.3, 6.0], [57.4, 6.0], [57.5, 6.0], [57.6, 6.0], [57.7, 6.0], [57.8, 6.0], [57.9, 6.0], [58.0, 6.0], [58.1, 6.0], [58.2, 6.0], [58.3, 6.0], [58.4, 6.0], [58.5, 6.0], [58.6, 6.0], [58.7, 6.0], [58.8, 6.0], [58.9, 6.0], [59.0, 6.0], [59.1, 6.0], [59.2, 6.0], [59.3, 6.0], [59.4, 6.0], [59.5, 6.0], [59.6, 6.0], [59.7, 6.0], [59.8, 6.0], [59.9, 6.0], [60.0, 6.0], [60.1, 6.0], [60.2, 6.0], [60.3, 6.0], [60.4, 6.0], [60.5, 6.0], [60.6, 6.0], [60.7, 6.0], [60.8, 6.0], [60.9, 6.0], [61.0, 6.0], [61.1, 6.0], [61.2, 6.0], [61.3, 6.0], [61.4, 6.0], [61.5, 6.0], [61.6, 6.0], [61.7, 6.0], [61.8, 6.0], [61.9, 6.0], [62.0, 6.0], [62.1, 6.0], [62.2, 6.0], [62.3, 6.0], [62.4, 6.0], [62.5, 6.0], [62.6, 6.0], [62.7, 6.0], [62.8, 6.0], [62.9, 6.0], [63.0, 6.0], [63.1, 6.0], [63.2, 6.0], [63.3, 6.0], [63.4, 6.0], [63.5, 6.0], [63.6, 6.0], [63.7, 6.0], [63.8, 6.0], [63.9, 6.0], [64.0, 6.0], [64.1, 6.0], [64.2, 6.0], [64.3, 6.0], [64.4, 6.0], [64.5, 6.0], [64.6, 6.0], [64.7, 6.0], [64.8, 6.0], [64.9, 6.0], [65.0, 6.0], [65.1, 6.0], [65.2, 6.0], [65.3, 6.0], [65.4, 6.0], [65.5, 6.0], [65.6, 6.0], [65.7, 6.0], [65.8, 6.0], [65.9, 6.0], [66.0, 6.0], [66.1, 6.0], [66.2, 6.0], [66.3, 6.0], [66.4, 6.0], [66.5, 6.0], [66.6, 6.0], [66.7, 6.0], [66.8, 6.0], [66.9, 6.0], [67.0, 6.0], [67.1, 6.0], [67.2, 6.0], [67.3, 6.0], [67.4, 6.0], [67.5, 6.0], [67.6, 6.0], [67.7, 6.0], [67.8, 6.0], [67.9, 6.0], [68.0, 6.0], [68.1, 6.0], [68.2, 6.0], [68.3, 6.0], [68.4, 6.0], [68.5, 6.0], [68.6, 6.0], [68.7, 6.0], [68.8, 6.0], [68.9, 6.0], [69.0, 6.0], [69.1, 6.0], [69.2, 6.0], [69.3, 7.0], [69.4, 7.0], [69.5, 7.0], [69.6, 7.0], [69.7, 7.0], [69.8, 7.0], [69.9, 7.0], [70.0, 7.0], [70.1, 7.0], [70.2, 7.0], [70.3, 7.0], [70.4, 7.0], [70.5, 7.0], [70.6, 7.0], [70.7, 7.0], [70.8, 7.0], [70.9, 7.0], [71.0, 7.0], [71.1, 7.0], [71.2, 7.0], [71.3, 7.0], [71.4, 7.0], [71.5, 7.0], [71.6, 7.0], [71.7, 7.0], [71.8, 7.0], [71.9, 7.0], [72.0, 7.0], [72.1, 7.0], [72.2, 7.0], [72.3, 7.0], [72.4, 7.0], [72.5, 7.0], [72.6, 7.0], [72.7, 7.0], [72.8, 7.0], [72.9, 7.0], [73.0, 7.0], [73.1, 7.0], [73.2, 7.0], [73.3, 7.0], [73.4, 7.0], [73.5, 7.0], [73.6, 7.0], [73.7, 7.0], [73.8, 7.0], [73.9, 7.0], [74.0, 7.0], [74.1, 7.0], [74.2, 7.0], [74.3, 7.0], [74.4, 7.0], [74.5, 7.0], [74.6, 7.0], [74.7, 7.0], [74.8, 7.0], [74.9, 7.0], [75.0, 7.0], [75.1, 7.0], [75.2, 7.0], [75.3, 7.0], [75.4, 7.0], [75.5, 7.0], [75.6, 7.0], [75.7, 7.0], [75.8, 7.0], [75.9, 7.0], [76.0, 7.0], [76.1, 7.0], [76.2, 7.0], [76.3, 7.0], [76.4, 7.0], [76.5, 7.0], [76.6, 7.0], [76.7, 7.0], [76.8, 7.0], [76.9, 7.0], [77.0, 7.0], [77.1, 7.0], [77.2, 7.0], [77.3, 7.0], [77.4, 7.0], [77.5, 7.0], [77.6, 7.0], [77.7, 7.0], [77.8, 7.0], [77.9, 7.0], [78.0, 7.0], [78.1, 7.0], [78.2, 7.0], [78.3, 7.0], [78.4, 7.0], [78.5, 7.0], [78.6, 7.0], [78.7, 7.0], [78.8, 7.0], [78.9, 7.0], [79.0, 7.0], [79.1, 7.0], [79.2, 7.0], [79.3, 7.0], [79.4, 7.0], [79.5, 8.0], [79.6, 8.0], [79.7, 8.0], [79.8, 8.0], [79.9, 8.0], [80.0, 8.0], [80.1, 8.0], [80.2, 8.0], [80.3, 8.0], [80.4, 8.0], [80.5, 8.0], [80.6, 8.0], [80.7, 8.0], [80.8, 8.0], [80.9, 8.0], [81.0, 8.0], [81.1, 8.0], [81.2, 8.0], [81.3, 8.0], [81.4, 8.0], [81.5, 8.0], [81.6, 8.0], [81.7, 8.0], [81.8, 8.0], [81.9, 8.0], [82.0, 8.0], [82.1, 8.0], [82.2, 8.0], [82.3, 8.0], [82.4, 8.0], [82.5, 8.0], [82.6, 8.0], [82.7, 8.0], [82.8, 8.0], [82.9, 8.0], [83.0, 8.0], [83.1, 8.0], [83.2, 8.0], [83.3, 8.0], [83.4, 8.0], [83.5, 8.0], [83.6, 8.0], [83.7, 8.0], [83.8, 8.0], [83.9, 8.0], [84.0, 8.0], [84.1, 8.0], [84.2, 8.0], [84.3, 8.0], [84.4, 8.0], [84.5, 8.0], [84.6, 8.0], [84.7, 8.0], [84.8, 8.0], [84.9, 8.0], [85.0, 8.0], [85.1, 8.0], [85.2, 8.0], [85.3, 8.0], [85.4, 8.0], [85.5, 8.0], [85.6, 8.0], [85.7, 8.0], [85.8, 9.0], [85.9, 9.0], [86.0, 9.0], [86.1, 9.0], [86.2, 9.0], [86.3, 9.0], [86.4, 9.0], [86.5, 9.0], [86.6, 9.0], [86.7, 9.0], [86.8, 9.0], [86.9, 9.0], [87.0, 9.0], [87.1, 9.0], [87.2, 9.0], [87.3, 9.0], [87.4, 9.0], [87.5, 9.0], [87.6, 9.0], [87.7, 9.0], [87.8, 9.0], [87.9, 9.0], [88.0, 9.0], [88.1, 9.0], [88.2, 9.0], [88.3, 9.0], [88.4, 9.0], [88.5, 9.0], [88.6, 9.0], [88.7, 9.0], [88.8, 9.0], [88.9, 9.0], [89.0, 9.0], [89.1, 9.0], [89.2, 9.0], [89.3, 9.0], [89.4, 9.0], [89.5, 9.0], [89.6, 9.0], [89.7, 10.0], [89.8, 10.0], [89.9, 10.0], [90.0, 10.0], [90.1, 10.0], [90.2, 10.0], [90.3, 10.0], [90.4, 10.0], [90.5, 10.0], [90.6, 10.0], [90.7, 10.0], [90.8, 10.0], [90.9, 10.0], [91.0, 10.0], [91.1, 10.0], [91.2, 10.0], [91.3, 10.0], [91.4, 10.0], [91.5, 10.0], [91.6, 10.0], [91.7, 10.0], [91.8, 10.0], [91.9, 10.0], [92.0, 10.0], [92.1, 10.0], [92.2, 10.0], [92.3, 10.0], [92.4, 11.0], [92.5, 11.0], [92.6, 11.0], [92.7, 11.0], [92.8, 11.0], [92.9, 11.0], [93.0, 11.0], [93.1, 11.0], [93.2, 11.0], [93.3, 11.0], [93.4, 11.0], [93.5, 11.0], [93.6, 11.0], [93.7, 11.0], [93.8, 11.0], [93.9, 12.0], [94.0, 12.0], [94.1, 12.0], [94.2, 12.0], [94.3, 12.0], [94.4, 12.0], [94.5, 12.0], [94.6, 12.0], [94.7, 12.0], [94.8, 13.0], [94.9, 13.0], [95.0, 13.0], [95.1, 13.0], [95.2, 13.0], [95.3, 14.0], [95.4, 14.0], [95.5, 14.0], [95.6, 14.0], [95.7, 15.0], [95.8, 15.0], [95.9, 15.0], [96.0, 16.0], [96.1, 17.0], [96.2, 17.0], [96.3, 17.0], [96.4, 18.0], [96.5, 19.0], [96.6, 19.0], [96.7, 20.0], [96.8, 22.0], [96.9, 22.0], [97.0, 23.0], [97.1, 25.0], [97.2, 26.0], [97.3, 28.0], [97.4, 29.0], [97.5, 31.0], [97.6, 33.0], [97.7, 35.0], [97.8, 36.0], [97.9, 37.0], [98.0, 39.0], [98.1, 40.0], [98.2, 41.0], [98.3, 44.0], [98.4, 46.0], [98.5, 48.0], [98.6, 51.0], [98.7, 53.0], [98.8, 58.0], [98.9, 61.0], [99.0, 65.0], [99.1, 70.0], [99.2, 74.0], [99.3, 78.0], [99.4, 82.0], [99.5, 92.0], [99.6, 99.0], [99.7, 109.0], [99.8, 137.0], [99.9, 172.0]], "isOverall": false, "label": "SeleccionTarifaYCantidad", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 0.0, "maxY": 5316.0, "series": [{"data": [[0.0, 5316.0], [100.0, 20.0], [200.0, 1.0]], "isOverall": false, "label": "SeleccionTarifaYCantidad", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 200.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 57.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1.500ms"], [2, "Requests having \nresponse time > 1.500ms"], [3, "Requests in error"]], "maxY": 5280.0, "series": [{"data": [[0.0, 5280.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1.500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1.500ms", "isController": false}, {"data": [[3.0, 57.0]], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 24.874999999999993, "minX": 1.79466641E12, "maxY": 100.0, "series": [{"data": [[1.794666434E12, 100.0], [1.794666436E12, 100.0], [1.79466644E12, 100.0], [1.794666438E12, 100.0], [1.794666442E12, 100.0], [1.794666444E12, 100.0], [1.794666448E12, 100.0], [1.794666446E12, 100.0], [1.79466645E12, 100.0], [1.794666452E12, 100.0], [1.794666455E12, 100.0], [1.794666412E12, 52.408163265306115], [1.794666416E12, 91.962962962963], [1.794666414E12, 72.09836065573768], [1.794666457E12, 100.0], [1.794666418E12, 100.0], [1.794666461E12, 100.0], [1.794666459E12, 100.0], [1.794666463E12, 100.0], [1.79466642E12, 100.0], [1.794666424E12, 100.0], [1.794666422E12, 100.0], [1.794666465E12, 100.0], [1.794666426E12, 100.0], [1.794666467E12, 24.874999999999993], [1.794666428E12, 100.0], [1.794666432E12, 100.0], [1.79466643E12, 100.0], [1.794666433E12, 100.0], [1.794666437E12, 100.0], [1.794666435E12, 100.0], [1.794666439E12, 100.0], [1.794666441E12, 100.0], [1.794666445E12, 100.0], [1.794666443E12, 100.0], [1.794666447E12, 100.0], [1.794666449E12, 100.0], [1.79466641E12, 34.23529411764706], [1.794666453E12, 100.0], [1.794666451E12, 100.0], [1.794666413E12, 62.40983606557378], [1.794666456E12, 100.0], [1.794666411E12, 40.05263157894737], [1.794666454E12, 100.0], [1.794666415E12, 82.00000000000001], [1.794666458E12, 100.0], [1.794666417E12, 99.55789473684212], [1.79466646E12, 100.0], [1.794666421E12, 100.0], [1.794666464E12, 100.0], [1.794666419E12, 100.0], [1.794666462E12, 100.0], [1.794666423E12, 100.0], [1.794666466E12, 81.31578947368423], [1.794666425E12, 100.0], [1.794666429E12, 100.0], [1.794666427E12, 100.0], [1.794666431E12, 100.0]], "isOverall": false, "label": "Usuarios parametrizados - experimentacion", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.794666467E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 2.0, "minX": 1.0, "maxY": 47.1, "series": [{"data": [[3.0, 6.5], [5.0, 4.5], [6.0, 7.0], [7.0, 5.0], [9.0, 4.5], [10.0, 4.0], [11.0, 5.0], [12.0, 3.0], [13.0, 5.0], [15.0, 6.5], [16.0, 5.0], [19.0, 9.333333333333334], [20.0, 4.0], [21.0, 5.0], [22.0, 3.0], [24.0, 4.5], [25.0, 9.0], [26.0, 5.0], [27.0, 8.0], [28.0, 4.0], [29.0, 4.0], [31.0, 5.0], [33.0, 47.1], [34.0, 6.333333333333333], [35.0, 11.5], [37.0, 7.0], [36.0, 6.833333333333333], [38.0, 17.6], [39.0, 8.875], [41.0, 7.333333333333333], [40.0, 20.0], [42.0, 19.0], [43.0, 13.0], [45.0, 13.666666666666668], [44.0, 8.0], [46.0, 5.0], [47.0, 5.8], [48.0, 5.666666666666667], [49.0, 5.0], [50.0, 5.666666666666667], [51.0, 5.0], [52.0, 5.999999999999999], [53.0, 4.8], [54.0, 5.6], [55.0, 6.333333333333333], [56.0, 4.2], [57.0, 4.5], [58.0, 4.166666666666667], [59.0, 15.4], [60.0, 5.5], [61.0, 7.428571428571429], [62.0, 5.222222222222222], [63.0, 6.25], [64.0, 5.833333333333334], [65.0, 6.4], [66.0, 6.727272727272728], [67.0, 8.454545454545455], [68.0, 11.5], [69.0, 5.833333333333333], [70.0, 6.0], [71.0, 3.4], [72.0, 6.555555555555555], [73.0, 5.857142857142857], [74.0, 7.333333333333334], [75.0, 6.8181818181818175], [76.0, 5.0], [77.0, 5.625], [78.0, 6.5], [79.0, 5.8], [80.0, 6.0], [81.0, 7.222222222222222], [82.0, 8.142857142857144], [83.0, 8.3], [84.0, 5.0], [85.0, 5.624999999999999], [86.0, 6.615384615384617], [87.0, 6.000000000000001], [88.0, 8.266666666666666], [89.0, 6.111111111111111], [90.0, 5.777777777777778], [91.0, 5.538461538461538], [92.0, 6.625], [93.0, 5.7272727272727275], [94.0, 6.0], [95.0, 5.777777777777778], [96.0, 6.722222222222222], [97.0, 7.23076923076923], [98.0, 13.777777777777779], [99.0, 28.000000000000004], [100.0, 7.350695164971987], [1.0, 2.0]], "isOverall": false, "label": "SeleccionTarifaYCantidad", "isController": false}, {"data": [[96.98707138842079, 7.413902941727533]], "isOverall": false, "label": "SeleccionTarifaYCantidad-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 3879.0, "minX": 1.79466641E12, "maxY": 113394.0, "series": [{"data": [[1.794666434E12, 26873.0], [1.794666436E12, 28212.0], [1.79466644E12, 26860.0], [1.794666438E12, 38539.0], [1.794666442E12, 25780.0], [1.794666444E12, 23586.0], [1.794666448E12, 28497.0], [1.794666446E12, 26878.0], [1.79466645E12, 29343.0], [1.794666452E12, 27381.0], [1.794666455E12, 26051.0], [1.794666412E12, 13427.0], [1.794666416E12, 22241.0], [1.794666414E12, 16698.0], [1.794666457E12, 26912.0], [1.794666418E12, 113394.0], [1.794666461E12, 27400.0], [1.794666459E12, 26102.0], [1.794666463E12, 27710.0], [1.79466642E12, 26339.0], [1.794666424E12, 27456.0], [1.794666422E12, 27942.0], [1.794666465E12, 28211.0], [1.794666426E12, 24662.0], [1.794666467E12, 13181.0], [1.794666428E12, 25804.0], [1.794666432E12, 28521.0], [1.79466643E12, 27164.0], [1.794666433E12, 25780.0], [1.794666437E12, 26920.0], [1.794666435E12, 25797.0], [1.794666439E12, 26847.0], [1.794666441E12, 27991.0], [1.794666445E12, 28246.0], [1.794666443E12, 29070.0], [1.794666447E12, 28811.0], [1.794666449E12, 25535.0], [1.79466641E12, 7021.0], [1.794666453E12, 24437.0], [1.794666451E12, 28245.0], [1.794666413E12, 16766.0], [1.794666456E12, 27679.0], [1.794666411E12, 5220.0], [1.794666454E12, 29063.0], [1.794666415E12, 21639.0], [1.794666458E12, 27672.0], [1.794666417E12, 45035.0], [1.79466646E12, 27127.0], [1.794666421E12, 26331.0], [1.794666464E12, 25790.0], [1.794666419E12, 41288.0], [1.794666462E12, 27173.0], [1.794666423E12, 27430.0], [1.794666466E12, 26056.0], [1.794666425E12, 26294.0], [1.794666429E12, 26885.0], [1.794666427E12, 28506.0], [1.794666431E12, 26878.0]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.794666434E12, 23807.0], [1.794666436E12, 24996.0], [1.79466644E12, 23801.0], [1.794666438E12, 24785.0], [1.794666442E12, 22843.0], [1.794666444E12, 20900.0], [1.794666448E12, 25249.0], [1.794666446E12, 23815.0], [1.79466645E12, 26001.0], [1.794666452E12, 24260.0], [1.794666455E12, 23088.0], [1.794666412E12, 11899.0], [1.794666416E12, 19707.0], [1.794666414E12, 14802.0], [1.794666457E12, 23848.0], [1.794666418E12, 13824.0], [1.794666461E12, 24281.0], [1.794666459E12, 23127.0], [1.794666463E12, 24553.0], [1.79466642E12, 23339.0], [1.794666424E12, 24329.0], [1.794666422E12, 24756.0], [1.794666465E12, 24994.0], [1.794666426E12, 21851.0], [1.794666467E12, 11685.0], [1.794666428E12, 22862.0], [1.794666432E12, 25275.0], [1.79466643E12, 24069.0], [1.794666433E12, 22843.0], [1.794666437E12, 23847.0], [1.794666435E12, 22864.0], [1.794666439E12, 23791.0], [1.794666441E12, 24796.0], [1.794666445E12, 25026.0], [1.794666443E12, 25756.0], [1.794666447E12, 25530.0], [1.794666449E12, 22624.0], [1.79466641E12, 3879.0], [1.794666453E12, 21653.0], [1.794666451E12, 25027.0], [1.794666413E12, 14848.0], [1.794666456E12, 24518.0], [1.794666411E12, 4626.0], [1.794666454E12, 25749.0], [1.794666415E12, 19171.0], [1.794666458E12, 24521.0], [1.794666417E12, 21169.0], [1.79466646E12, 24035.0], [1.794666421E12, 23330.0], [1.794666464E12, 22855.0], [1.794666419E12, 20193.0], [1.794666462E12, 24073.0], [1.794666423E12, 24305.0], [1.794666466E12, 23083.0], [1.794666425E12, 23301.0], [1.794666429E12, 23820.0], [1.794666427E12, 25257.0], [1.794666431E12, 23812.0]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.794666467E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 4.505050505050504, "minX": 1.79466641E12, "maxY": 45.202127659574465, "series": [{"data": [[1.794666434E12, 4.938775510204082], [1.794666436E12, 5.203883495145633], [1.79466644E12, 5.448979591836732], [1.794666438E12, 11.830188679245282], [1.794666442E12, 5.872340425531913], [1.794666444E12, 5.639534883720931], [1.794666448E12, 6.201923076923077], [1.794666446E12, 5.306122448979593], [1.79466645E12, 4.523364485981308], [1.794666452E12, 5.919999999999997], [1.794666455E12, 4.831578947368423], [1.794666412E12, 5.653061224489796], [1.794666416E12, 6.4320987654321], [1.794666414E12, 6.918032786885246], [1.794666457E12, 4.806122448979593], [1.794666418E12, 45.202127659574465], [1.794666461E12, 4.690000000000001], [1.794666459E12, 5.578947368421052], [1.794666463E12, 5.237623762376237], [1.79466642E12, 6.187500000000002], [1.794666424E12, 5.42], [1.794666422E12, 6.264705882352942], [1.794666465E12, 6.145631067961166], [1.794666426E12, 4.800000000000002], [1.794666467E12, 5.687500000000001], [1.794666428E12, 5.904255319148938], [1.794666432E12, 5.759615384615384], [1.79466643E12, 5.474747474747474], [1.794666433E12, 5.531914893617019], [1.794666437E12, 6.510204081632653], [1.794666435E12, 5.521276595744681], [1.794666439E12, 5.408163265306125], [1.794666441E12, 5.774509803921568], [1.794666445E12, 6.49514563106796], [1.794666443E12, 5.811320754716981], [1.794666447E12, 6.095238095238093], [1.794666449E12, 5.89247311827957], [1.79466641E12, 31.0], [1.794666453E12, 5.337078651685394], [1.794666451E12, 5.213592233009709], [1.794666413E12, 6.967213114754098], [1.794666456E12, 5.841584158415843], [1.794666411E12, 15.68421052631579], [1.794666454E12, 4.773584905660376], [1.794666415E12, 6.924050632911395], [1.794666458E12, 5.33663366336634], [1.794666417E12, 26.147368421052636], [1.79466646E12, 5.222222222222224], [1.794666421E12, 5.989583333333334], [1.794666464E12, 5.829787234042555], [1.794666419E12, 36.00000000000001], [1.794666462E12, 4.505050505050504], [1.794666423E12, 6.160000000000002], [1.794666466E12, 5.442105263157894], [1.794666425E12, 4.6874999999999964], [1.794666429E12, 5.03061224489796], [1.794666427E12, 5.451923076923077], [1.794666431E12, 5.9183673469387745]], "isOverall": false, "label": "SeleccionTarifaYCantidad", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.794666467E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 4.313131313131312, "minX": 1.79466641E12, "maxY": 39.84042553191489, "series": [{"data": [[1.794666434E12, 4.683673469387757], [1.794666436E12, 4.941747572815536], [1.79466644E12, 5.1938775510204085], [1.794666438E12, 11.509433962264152], [1.794666442E12, 5.595744680851066], [1.794666444E12, 5.395348837209302], [1.794666448E12, 5.875000000000001], [1.794666446E12, 5.061224489795917], [1.79466645E12, 4.32710280373832], [1.794666452E12, 5.699999999999998], [1.794666455E12, 4.547368421052635], [1.794666412E12, 5.081632653061225], [1.794666416E12, 5.851851851851853], [1.794666414E12, 6.508196721311475], [1.794666457E12, 4.540816326530614], [1.794666418E12, 39.84042553191489], [1.794666461E12, 4.419999999999998], [1.794666459E12, 5.28421052631579], [1.794666463E12, 4.970297029702971], [1.79466642E12, 5.833333333333331], [1.794666424E12, 5.12], [1.794666422E12, 6.019607843137256], [1.794666465E12, 5.873786407766992], [1.794666426E12, 4.499999999999999], [1.794666467E12, 5.395833333333334], [1.794666428E12, 5.670212765957448], [1.794666432E12, 5.509615384615388], [1.79466643E12, 5.24242424242424], [1.794666433E12, 5.319148936170214], [1.794666437E12, 6.193877551020409], [1.794666435E12, 5.244680851063829], [1.794666439E12, 5.173469387755104], [1.794666441E12, 5.490196078431373], [1.794666445E12, 6.1747572815534], [1.794666443E12, 5.594339622641508], [1.794666447E12, 5.838095238095237], [1.794666449E12, 5.548387096774192], [1.79466641E12, 26.58823529411765], [1.794666453E12, 5.112359550561799], [1.794666451E12, 4.932038834951456], [1.794666413E12, 6.409836065573771], [1.794666456E12, 5.544554455445543], [1.794666411E12, 15.210526315789473], [1.794666454E12, 4.547169811320754], [1.794666415E12, 6.3544303797468356], [1.794666458E12, 5.029702970297029], [1.794666417E12, 24.810526315789474], [1.79466646E12, 4.9393939393939394], [1.794666421E12, 5.666666666666664], [1.794666464E12, 5.627659574468083], [1.794666419E12, 34.66666666666667], [1.794666462E12, 4.313131313131312], [1.794666423E12, 5.669999999999999], [1.794666466E12, 5.136842105263155], [1.794666425E12, 4.437500000000002], [1.794666429E12, 4.7857142857142865], [1.794666427E12, 5.182692307692307], [1.794666431E12, 5.540816326530613]], "isOverall": false, "label": "SeleccionTarifaYCantidad", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.794666467E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 1.53125, "minX": 1.79466641E12, "maxY": 20.647058823529413, "series": [{"data": [[1.794666434E12, 1.6224489795918369], [1.794666436E12, 1.54368932038835], [1.79466644E12, 1.9183673469387752], [1.794666438E12, 1.9905660377358483], [1.794666442E12, 1.957446808510638], [1.794666444E12, 1.9883720930232556], [1.794666448E12, 2.0865384615384617], [1.794666446E12, 1.846938775510204], [1.79466645E12, 1.5981308411214954], [1.794666452E12, 2.11], [1.794666455E12, 1.6421052631578943], [1.794666412E12, 2.5102040816326534], [1.794666416E12, 2.308641975308643], [1.794666414E12, 2.573770491803278], [1.794666457E12, 1.6632653061224496], [1.794666418E12, 9.074468085106385], [1.794666461E12, 1.78], [1.794666459E12, 1.842105263157894], [1.794666463E12, 1.9306930693069309], [1.79466642E12, 2.0208333333333317], [1.794666424E12, 1.9399999999999997], [1.794666422E12, 2.0098039215686283], [1.794666465E12, 2.194174757281555], [1.794666426E12, 1.8222222222222224], [1.794666467E12, 1.9999999999999998], [1.794666428E12, 1.8723404255319145], [1.794666432E12, 1.7500000000000004], [1.79466643E12, 1.6767676767676765], [1.794666433E12, 1.8617021276595749], [1.794666437E12, 2.0306122448979593], [1.794666435E12, 1.8510638297872344], [1.794666439E12, 1.846938775510204], [1.794666441E12, 1.7156862745098036], [1.794666445E12, 1.9902912621359221], [1.794666443E12, 1.9056603773584904], [1.794666447E12, 2.00952380952381], [1.794666449E12, 1.935483870967742], [1.79466641E12, 20.647058823529413], [1.794666453E12, 1.887640449438202], [1.794666451E12, 1.8834951456310682], [1.794666413E12, 2.3442622950819674], [1.794666456E12, 2.1881188118811883], [1.794666411E12, 6.3157894736842115], [1.794666454E12, 1.7641509433962261], [1.794666415E12, 2.6455696202531636], [1.794666458E12, 1.821782178217822], [1.794666417E12, 5.189473684210524], [1.79466646E12, 1.8383838383838382], [1.794666421E12, 2.0624999999999996], [1.794666464E12, 2.053191489361702], [1.794666419E12, 4.12222222222222], [1.794666462E12, 1.6464646464646469], [1.794666423E12, 1.7899999999999994], [1.794666466E12, 1.9473684210526314], [1.794666425E12, 1.53125], [1.794666429E12, 1.5408163265306127], [1.794666427E12, 1.798076923076923], [1.794666431E12, 1.8979591836734693]], "isOverall": false, "label": "SeleccionTarifaYCantidad", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.794666467E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 2.0, "minX": 1.79466641E12, "maxY": 209.0, "series": [{"data": [[1.794666434E12, 13.0], [1.794666436E12, 10.0], [1.79466644E12, 13.0], [1.794666438E12, 143.0], [1.794666442E12, 15.0], [1.794666444E12, 10.0], [1.794666448E12, 20.0], [1.794666446E12, 13.0], [1.79466645E12, 9.0], [1.794666452E12, 14.0], [1.794666455E12, 17.0], [1.794666412E12, 14.0], [1.794666416E12, 20.0], [1.794666414E12, 24.0], [1.794666457E12, 13.0], [1.794666418E12, 209.0], [1.794666461E12, 11.0], [1.794666459E12, 13.0], [1.794666463E12, 12.0], [1.79466642E12, 17.0], [1.794666424E12, 12.0], [1.794666422E12, 14.0], [1.794666465E12, 13.0], [1.794666426E12, 15.0], [1.794666467E12, 11.0], [1.794666428E12, 13.0], [1.794666432E12, 21.0], [1.79466643E12, 13.0], [1.794666433E12, 11.0], [1.794666437E12, 14.0], [1.794666435E12, 12.0], [1.794666439E12, 12.0], [1.794666441E12, 12.0], [1.794666445E12, 21.0], [1.794666443E12, 14.0], [1.794666447E12, 13.0], [1.794666449E12, 11.0], [1.79466641E12, 72.0], [1.794666453E12, 11.0], [1.794666451E12, 9.0], [1.794666413E12, 22.0], [1.794666456E12, 17.0], [1.794666411E12, 44.0], [1.794666454E12, 12.0], [1.794666415E12, 18.0], [1.794666458E12, 12.0], [1.794666417E12, 82.0], [1.79466646E12, 12.0], [1.794666421E12, 11.0], [1.794666464E12, 16.0], [1.794666419E12, 125.0], [1.794666462E12, 10.0], [1.794666423E12, 17.0], [1.794666466E12, 12.0], [1.794666425E12, 11.0], [1.794666429E12, 12.0], [1.794666427E12, 14.0], [1.794666431E12, 13.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.794666434E12, 2.0], [1.794666436E12, 2.0], [1.79466644E12, 3.0], [1.794666438E12, 2.0], [1.794666442E12, 3.0], [1.794666444E12, 3.0], [1.794666448E12, 2.0], [1.794666446E12, 2.0], [1.79466645E12, 2.0], [1.794666452E12, 3.0], [1.794666455E12, 2.0], [1.794666412E12, 3.0], [1.794666416E12, 3.0], [1.794666414E12, 3.0], [1.794666457E12, 2.0], [1.794666418E12, 3.0], [1.794666461E12, 2.0], [1.794666459E12, 3.0], [1.794666463E12, 2.0], [1.79466642E12, 3.0], [1.794666424E12, 2.0], [1.794666422E12, 3.0], [1.794666465E12, 2.0], [1.794666426E12, 2.0], [1.794666467E12, 2.0], [1.794666428E12, 2.0], [1.794666432E12, 2.0], [1.79466643E12, 2.0], [1.794666433E12, 3.0], [1.794666437E12, 3.0], [1.794666435E12, 2.0], [1.794666439E12, 2.0], [1.794666441E12, 3.0], [1.794666445E12, 2.0], [1.794666443E12, 2.0], [1.794666447E12, 2.0], [1.794666449E12, 2.0], [1.79466641E12, 5.0], [1.794666453E12, 2.0], [1.794666451E12, 2.0], [1.794666413E12, 3.0], [1.794666456E12, 2.0], [1.794666411E12, 5.0], [1.794666454E12, 2.0], [1.794666415E12, 3.0], [1.794666458E12, 2.0], [1.794666417E12, 3.0], [1.79466646E12, 2.0], [1.794666421E12, 3.0], [1.794666464E12, 2.0], [1.794666419E12, 3.0], [1.794666462E12, 2.0], [1.794666423E12, 3.0], [1.794666466E12, 2.0], [1.794666425E12, 2.0], [1.794666429E12, 2.0], [1.794666427E12, 2.0], [1.794666431E12, 3.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.794666434E12, 8.100000000000009], [1.794666436E12, 8.0], [1.79466644E12, 8.0], [1.794666438E12, 15.0], [1.794666442E12, 9.0], [1.794666444E12, 8.299999999999997], [1.794666448E12, 10.0], [1.794666446E12, 8.0], [1.79466645E12, 7.0], [1.794666452E12, 9.0], [1.794666455E12, 7.400000000000006], [1.794666412E12, 7.0], [1.794666416E12, 9.0], [1.794666414E12, 11.0], [1.794666457E12, 8.0], [1.794666418E12, 173.40000000000003], [1.794666461E12, 7.0], [1.794666459E12, 8.0], [1.794666463E12, 8.0], [1.79466642E12, 9.0], [1.794666424E12, 8.0], [1.794666422E12, 10.0], [1.794666465E12, 9.0], [1.794666426E12, 7.0], [1.794666467E12, 8.100000000000001], [1.794666428E12, 9.0], [1.794666432E12, 9.0], [1.79466643E12, 8.0], [1.794666433E12, 9.0], [1.794666437E12, 10.0], [1.794666435E12, 8.0], [1.794666439E12, 8.0], [1.794666441E12, 8.0], [1.794666445E12, 10.0], [1.794666443E12, 9.0], [1.794666447E12, 9.400000000000006], [1.794666449E12, 10.0], [1.79466641E12, 71.3], [1.794666453E12, 7.0], [1.794666451E12, 7.0], [1.794666413E12, 10.800000000000004], [1.794666456E12, 9.0], [1.794666411E12, 29.0], [1.794666454E12, 7.299999999999997], [1.794666415E12, 11.0], [1.794666458E12, 9.0], [1.794666417E12, 54.40000000000002], [1.79466646E12, 8.0], [1.794666421E12, 9.0], [1.794666464E12, 9.0], [1.794666419E12, 90.20000000000002], [1.794666462E12, 7.0], [1.794666423E12, 9.900000000000006], [1.794666466E12, 9.0], [1.794666425E12, 7.299999999999997], [1.794666429E12, 9.0], [1.794666427E12, 9.0], [1.794666431E12, 9.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.794666434E12, 13.0], [1.794666436E12, 9.959999999999994], [1.79466644E12, 13.0], [1.794666438E12, 141.64999999999995], [1.794666442E12, 15.0], [1.794666444E12, 10.0], [1.794666448E12, 19.950000000000003], [1.794666446E12, 13.0], [1.79466645E12, 9.0], [1.794666452E12, 13.989999999999995], [1.794666455E12, 17.0], [1.794666412E12, 14.0], [1.794666416E12, 20.0], [1.794666414E12, 24.0], [1.794666457E12, 13.0], [1.794666418E12, 209.0], [1.794666461E12, 10.97999999999999], [1.794666459E12, 13.0], [1.794666463E12, 12.0], [1.79466642E12, 17.0], [1.794666424E12, 11.989999999999995], [1.794666422E12, 13.969999999999999], [1.794666465E12, 12.959999999999994], [1.794666426E12, 15.0], [1.794666467E12, 11.0], [1.794666428E12, 13.0], [1.794666432E12, 20.950000000000003], [1.79466643E12, 13.0], [1.794666433E12, 11.0], [1.794666437E12, 14.0], [1.794666435E12, 12.0], [1.794666439E12, 12.0], [1.794666441E12, 11.969999999999999], [1.794666445E12, 20.79999999999997], [1.794666443E12, 13.859999999999985], [1.794666447E12, 13.0], [1.794666449E12, 11.0], [1.79466641E12, 72.0], [1.794666453E12, 11.0], [1.794666451E12, 9.0], [1.794666413E12, 22.0], [1.794666456E12, 16.960000000000008], [1.794666411E12, 44.0], [1.794666454E12, 11.859999999999985], [1.794666415E12, 18.0], [1.794666458E12, 11.980000000000004], [1.794666417E12, 82.0], [1.79466646E12, 12.0], [1.794666421E12, 11.0], [1.794666464E12, 16.0], [1.794666419E12, 125.0], [1.794666462E12, 10.0], [1.794666423E12, 16.95999999999998], [1.794666466E12, 12.0], [1.794666425E12, 11.0], [1.794666429E12, 12.0], [1.794666427E12, 13.900000000000006], [1.794666431E12, 13.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.794666434E12, 4.0], [1.794666436E12, 5.0], [1.79466644E12, 5.0], [1.794666438E12, 6.0], [1.794666442E12, 5.0], [1.794666444E12, 5.0], [1.794666448E12, 5.0], [1.794666446E12, 5.0], [1.79466645E12, 4.0], [1.794666452E12, 5.0], [1.794666455E12, 4.0], [1.794666412E12, 5.0], [1.794666416E12, 6.0], [1.794666414E12, 6.0], [1.794666457E12, 4.0], [1.794666418E12, 44.0], [1.794666461E12, 4.0], [1.794666459E12, 5.0], [1.794666463E12, 5.0], [1.79466642E12, 6.0], [1.794666424E12, 5.0], [1.794666422E12, 5.5], [1.794666465E12, 6.0], [1.794666426E12, 4.5], [1.794666467E12, 5.0], [1.794666428E12, 5.0], [1.794666432E12, 5.0], [1.79466643E12, 5.0], [1.794666433E12, 5.0], [1.794666437E12, 6.0], [1.794666435E12, 5.0], [1.794666439E12, 5.0], [1.794666441E12, 6.0], [1.794666445E12, 6.0], [1.794666443E12, 5.0], [1.794666447E12, 5.0], [1.794666449E12, 5.0], [1.79466641E12, 12.5], [1.794666453E12, 5.0], [1.794666451E12, 5.0], [1.794666413E12, 7.0], [1.794666456E12, 5.0], [1.794666411E12, 13.0], [1.794666454E12, 4.0], [1.794666415E12, 6.0], [1.794666458E12, 5.0], [1.794666417E12, 25.0], [1.79466646E12, 5.0], [1.794666421E12, 6.0], [1.794666464E12, 5.0], [1.794666419E12, 30.0], [1.794666462E12, 4.0], [1.794666423E12, 6.0], [1.794666466E12, 5.0], [1.794666425E12, 4.0], [1.794666429E12, 4.0], [1.794666427E12, 5.0], [1.794666431E12, 6.0]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.794666434E12, 10.049999999999997], [1.794666436E12, 8.799999999999997], [1.79466644E12, 9.049999999999997], [1.794666438E12, 78.39999999999998], [1.794666442E12, 10.0], [1.794666444E12, 9.0], [1.794666448E12, 11.0], [1.794666446E12, 9.049999999999997], [1.79466645E12, 7.599999999999994], [1.794666452E12, 10.949999999999989], [1.794666455E12, 8.199999999999989], [1.794666412E12, 8.5], [1.794666416E12, 10.0], [1.794666414E12, 12.0], [1.794666457E12, 8.049999999999997], [1.794666418E12, 194.49999999999997], [1.794666461E12, 8.0], [1.794666459E12, 10.0], [1.794666463E12, 9.899999999999991], [1.79466642E12, 11.0], [1.794666424E12, 9.0], [1.794666422E12, 11.0], [1.794666465E12, 11.0], [1.794666426E12, 8.0], [1.794666467E12, 10.099999999999994], [1.794666428E12, 11.0], [1.794666432E12, 10.75], [1.79466643E12, 10.0], [1.794666433E12, 10.0], [1.794666437E12, 11.049999999999997], [1.794666435E12, 8.0], [1.794666439E12, 10.0], [1.794666441E12, 10.0], [1.794666445E12, 12.0], [1.794666443E12, 10.649999999999991], [1.794666447E12, 10.0], [1.794666449E12, 10.0], [1.79466641E12, 72.0], [1.794666453E12, 9.5], [1.794666451E12, 8.0], [1.794666413E12, 15.899999999999999], [1.794666456E12, 12.0], [1.794666411E12, 44.0], [1.794666454E12, 8.649999999999991], [1.794666415E12, 13.0], [1.794666458E12, 9.899999999999991], [1.794666417E12, 66.59999999999997], [1.79466646E12, 9.0], [1.794666421E12, 10.0], [1.794666464E12, 11.0], [1.794666419E12, 110.6], [1.794666462E12, 7.0], [1.794666423E12, 11.0], [1.794666466E12, 10.0], [1.794666425E12, 9.0], [1.794666429E12, 10.0], [1.794666427E12, 10.0], [1.794666431E12, 9.049999999999997]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.794666467E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 1.0, "minX": 17.0, "maxY": 57.0, "series": [{"data": [[49.0, 5.0], [48.0, 5.0], [61.0, 6.0], [17.0, 12.5], [19.0, 13.0], [79.0, 6.0], [81.0, 6.0], [86.0, 5.0], [90.0, 6.0], [89.0, 5.0], [95.0, 5.0], [94.0, 6.0], [93.0, 5.0], [96.0, 5.0], [98.0, 5.0], [99.0, 5.0], [102.0, 6.0], [100.0, 5.0], [103.0, 5.0], [101.0, 5.0], [104.0, 5.0], [106.0, 5.0], [105.0, 5.0], [107.0, 4.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[17.0, 57.0], [90.0, 8.0], [95.0, 7.5], [94.0, 5.0], [106.0, 1.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 107.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 0.0, "minX": 17.0, "maxY": 13.0, "series": [{"data": [[49.0, 5.0], [48.0, 5.0], [61.0, 6.0], [17.0, 9.5], [19.0, 13.0], [79.0, 5.0], [81.0, 5.0], [86.0, 5.0], [90.0, 6.0], [89.0, 5.0], [95.0, 5.0], [94.0, 5.0], [93.0, 5.0], [96.0, 5.0], [98.0, 5.0], [99.0, 4.0], [102.0, 5.0], [100.0, 5.0], [103.0, 5.0], [101.0, 5.0], [104.0, 5.0], [106.0, 5.0], [105.0, 5.0], [107.0, 4.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[17.0, 0.0], [90.0, 0.0], [95.0, 0.0], [94.0, 0.0], [106.0, 0.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 107.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 17.0, "minX": 1.79466641E12, "maxY": 107.0, "series": [{"data": [[1.794666434E12, 98.0], [1.794666436E12, 103.0], [1.79466644E12, 96.0], [1.794666438E12, 106.0], [1.794666442E12, 93.0], [1.794666444E12, 86.0], [1.794666448E12, 104.0], [1.794666446E12, 98.0], [1.79466645E12, 107.0], [1.794666452E12, 103.0], [1.794666455E12, 94.0], [1.794666412E12, 50.0], [1.794666416E12, 84.0], [1.794666414E12, 61.0], [1.794666457E12, 100.0], [1.794666418E12, 95.0], [1.794666461E12, 101.0], [1.794666459E12, 95.0], [1.794666463E12, 101.0], [1.79466642E12, 96.0], [1.794666424E12, 100.0], [1.794666422E12, 104.0], [1.794666465E12, 103.0], [1.794666426E12, 92.0], [1.794666467E12, 47.0], [1.794666428E12, 93.0], [1.794666432E12, 101.0], [1.79466643E12, 99.0], [1.794666433E12, 94.0], [1.794666437E12, 98.0], [1.794666435E12, 94.0], [1.794666439E12, 100.0], [1.794666441E12, 103.0], [1.794666445E12, 103.0], [1.794666443E12, 106.0], [1.794666447E12, 105.0], [1.794666449E12, 93.0], [1.79466641E12, 17.0], [1.794666453E12, 86.0], [1.794666451E12, 103.0], [1.794666413E12, 60.0], [1.794666456E12, 101.0], [1.794666411E12, 19.0], [1.794666454E12, 107.0], [1.794666415E12, 79.0], [1.794666458E12, 99.0], [1.794666417E12, 97.0], [1.79466646E12, 99.0], [1.794666421E12, 96.0], [1.794666464E12, 94.0], [1.794666419E12, 84.0], [1.794666462E12, 98.0], [1.794666423E12, 98.0], [1.794666466E12, 96.0], [1.794666425E12, 96.0], [1.794666429E12, 98.0], [1.794666427E12, 103.0], [1.794666431E12, 101.0]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.794666467E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 1.0, "minX": 1.79466641E12, "maxY": 107.0, "series": [{"data": [[1.794666434E12, 98.0], [1.794666436E12, 103.0], [1.79466644E12, 98.0], [1.794666438E12, 102.0], [1.794666442E12, 94.0], [1.794666444E12, 86.0], [1.794666448E12, 104.0], [1.794666446E12, 98.0], [1.79466645E12, 107.0], [1.794666452E12, 100.0], [1.794666455E12, 95.0], [1.794666412E12, 49.0], [1.794666416E12, 81.0], [1.794666414E12, 61.0], [1.794666457E12, 98.0], [1.794666418E12, 57.0], [1.794666461E12, 100.0], [1.794666459E12, 95.0], [1.794666463E12, 101.0], [1.79466642E12, 96.0], [1.794666424E12, 100.0], [1.794666422E12, 102.0], [1.794666465E12, 103.0], [1.794666426E12, 90.0], [1.794666467E12, 48.0], [1.794666428E12, 94.0], [1.794666432E12, 104.0], [1.79466643E12, 99.0], [1.794666433E12, 94.0], [1.794666437E12, 98.0], [1.794666435E12, 94.0], [1.794666439E12, 98.0], [1.794666441E12, 102.0], [1.794666445E12, 103.0], [1.794666443E12, 106.0], [1.794666447E12, 105.0], [1.794666449E12, 93.0], [1.79466641E12, 16.0], [1.794666453E12, 89.0], [1.794666451E12, 103.0], [1.794666413E12, 61.0], [1.794666456E12, 101.0], [1.794666411E12, 19.0], [1.794666454E12, 106.0], [1.794666415E12, 79.0], [1.794666458E12, 101.0], [1.794666417E12, 87.0], [1.79466646E12, 99.0], [1.794666421E12, 96.0], [1.794666464E12, 94.0], [1.794666419E12, 83.0], [1.794666462E12, 99.0], [1.794666423E12, 100.0], [1.794666466E12, 95.0], [1.794666425E12, 96.0], [1.794666429E12, 98.0], [1.794666427E12, 104.0], [1.794666431E12, 98.0]], "isOverall": false, "label": "201", "isController": false}, {"data": [[1.794666418E12, 37.0], [1.794666438E12, 4.0], [1.794666417E12, 8.0], [1.79466641E12, 1.0], [1.794666419E12, 7.0]], "isOverall": false, "label": "Non HTTP response code: org.apache.http.conn.HttpHostConnectException", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.794666467E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 1.0, "minX": 1.79466641E12, "maxY": 107.0, "series": [{"data": [[1.794666418E12, 37.0], [1.794666438E12, 4.0], [1.794666417E12, 8.0], [1.79466641E12, 1.0], [1.794666419E12, 7.0]], "isOverall": false, "label": "SeleccionTarifaYCantidad-failure", "isController": false}, {"data": [[1.794666434E12, 98.0], [1.794666436E12, 103.0], [1.79466644E12, 98.0], [1.794666438E12, 102.0], [1.794666442E12, 94.0], [1.794666444E12, 86.0], [1.794666448E12, 104.0], [1.794666446E12, 98.0], [1.79466645E12, 107.0], [1.794666452E12, 100.0], [1.794666455E12, 95.0], [1.794666412E12, 49.0], [1.794666416E12, 81.0], [1.794666414E12, 61.0], [1.794666457E12, 98.0], [1.794666418E12, 57.0], [1.794666461E12, 100.0], [1.794666459E12, 95.0], [1.794666463E12, 101.0], [1.79466642E12, 96.0], [1.794666424E12, 100.0], [1.794666422E12, 102.0], [1.794666465E12, 103.0], [1.794666426E12, 90.0], [1.794666467E12, 48.0], [1.794666428E12, 94.0], [1.794666432E12, 104.0], [1.79466643E12, 99.0], [1.794666433E12, 94.0], [1.794666437E12, 98.0], [1.794666435E12, 94.0], [1.794666439E12, 98.0], [1.794666441E12, 102.0], [1.794666445E12, 103.0], [1.794666443E12, 106.0], [1.794666447E12, 105.0], [1.794666449E12, 93.0], [1.79466641E12, 16.0], [1.794666453E12, 89.0], [1.794666451E12, 103.0], [1.794666413E12, 61.0], [1.794666456E12, 101.0], [1.794666411E12, 19.0], [1.794666454E12, 106.0], [1.794666415E12, 79.0], [1.794666458E12, 101.0], [1.794666417E12, 87.0], [1.79466646E12, 99.0], [1.794666421E12, 96.0], [1.794666464E12, 94.0], [1.794666419E12, 83.0], [1.794666462E12, 99.0], [1.794666423E12, 100.0], [1.794666466E12, 95.0], [1.794666425E12, 96.0], [1.794666429E12, 98.0], [1.794666427E12, 104.0], [1.794666431E12, 98.0]], "isOverall": false, "label": "SeleccionTarifaYCantidad-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.794666467E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 1.0, "minX": 1.79466641E12, "maxY": 107.0, "series": [{"data": [[1.794666434E12, 98.0], [1.794666436E12, 103.0], [1.79466644E12, 98.0], [1.794666438E12, 102.0], [1.794666442E12, 94.0], [1.794666444E12, 86.0], [1.794666448E12, 104.0], [1.794666446E12, 98.0], [1.79466645E12, 107.0], [1.794666452E12, 100.0], [1.794666455E12, 95.0], [1.794666412E12, 49.0], [1.794666416E12, 81.0], [1.794666414E12, 61.0], [1.794666457E12, 98.0], [1.794666418E12, 57.0], [1.794666461E12, 100.0], [1.794666459E12, 95.0], [1.794666463E12, 101.0], [1.79466642E12, 96.0], [1.794666424E12, 100.0], [1.794666422E12, 102.0], [1.794666465E12, 103.0], [1.794666426E12, 90.0], [1.794666467E12, 48.0], [1.794666428E12, 94.0], [1.794666432E12, 104.0], [1.79466643E12, 99.0], [1.794666433E12, 94.0], [1.794666437E12, 98.0], [1.794666435E12, 94.0], [1.794666439E12, 98.0], [1.794666441E12, 102.0], [1.794666445E12, 103.0], [1.794666443E12, 106.0], [1.794666447E12, 105.0], [1.794666449E12, 93.0], [1.79466641E12, 16.0], [1.794666453E12, 89.0], [1.794666451E12, 103.0], [1.794666413E12, 61.0], [1.794666456E12, 101.0], [1.794666411E12, 19.0], [1.794666454E12, 106.0], [1.794666415E12, 79.0], [1.794666458E12, 101.0], [1.794666417E12, 87.0], [1.79466646E12, 99.0], [1.794666421E12, 96.0], [1.794666464E12, 94.0], [1.794666419E12, 83.0], [1.794666462E12, 99.0], [1.794666423E12, 100.0], [1.794666466E12, 95.0], [1.794666425E12, 96.0], [1.794666429E12, 98.0], [1.794666427E12, 104.0], [1.794666431E12, 98.0]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [[1.794666418E12, 37.0], [1.794666438E12, 4.0], [1.794666417E12, 8.0], [1.79466641E12, 1.0], [1.794666419E12, 7.0]], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.794666467E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

