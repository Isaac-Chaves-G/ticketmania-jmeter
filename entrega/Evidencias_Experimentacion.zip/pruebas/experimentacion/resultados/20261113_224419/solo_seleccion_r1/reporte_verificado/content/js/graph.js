/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 0.0, "minX": 0.0, "maxY": 228.0, "series": [{"data": [[0.0, 0.0], [0.1, 1.0], [0.2, 1.0], [0.3, 1.0], [0.4, 1.0], [0.5, 1.0], [0.6, 2.0], [0.7, 2.0], [0.8, 2.0], [0.9, 2.0], [1.0, 2.0], [1.1, 2.0], [1.2, 2.0], [1.3, 2.0], [1.4, 2.0], [1.5, 2.0], [1.6, 2.0], [1.7, 2.0], [1.8, 2.0], [1.9, 2.0], [2.0, 2.0], [2.1, 2.0], [2.2, 2.0], [2.3, 2.0], [2.4, 2.0], [2.5, 2.0], [2.6, 2.0], [2.7, 2.0], [2.8, 2.0], [2.9, 2.0], [3.0, 2.0], [3.1, 2.0], [3.2, 2.0], [3.3, 2.0], [3.4, 2.0], [3.5, 2.0], [3.6, 2.0], [3.7, 2.0], [3.8, 2.0], [3.9, 2.0], [4.0, 2.0], [4.1, 2.0], [4.2, 2.0], [4.3, 2.0], [4.4, 2.0], [4.5, 2.0], [4.6, 2.0], [4.7, 2.0], [4.8, 2.0], [4.9, 2.0], [5.0, 2.0], [5.1, 2.0], [5.2, 2.0], [5.3, 2.0], [5.4, 2.0], [5.5, 2.0], [5.6, 2.0], [5.7, 2.0], [5.8, 2.0], [5.9, 2.0], [6.0, 2.0], [6.1, 2.0], [6.2, 2.0], [6.3, 2.0], [6.4, 2.0], [6.5, 2.0], [6.6, 2.0], [6.7, 2.0], [6.8, 2.0], [6.9, 2.0], [7.0, 2.0], [7.1, 2.0], [7.2, 2.0], [7.3, 2.0], [7.4, 2.0], [7.5, 2.0], [7.6, 2.0], [7.7, 2.0], [7.8, 2.0], [7.9, 2.0], [8.0, 2.0], [8.1, 2.0], [8.2, 2.0], [8.3, 2.0], [8.4, 2.0], [8.5, 2.0], [8.6, 2.0], [8.7, 2.0], [8.8, 2.0], [8.9, 2.0], [9.0, 2.0], [9.1, 2.0], [9.2, 2.0], [9.3, 2.0], [9.4, 2.0], [9.5, 2.0], [9.6, 2.0], [9.7, 2.0], [9.8, 2.0], [9.9, 2.0], [10.0, 2.0], [10.1, 3.0], [10.2, 3.0], [10.3, 3.0], [10.4, 3.0], [10.5, 3.0], [10.6, 3.0], [10.7, 3.0], [10.8, 3.0], [10.9, 3.0], [11.0, 3.0], [11.1, 3.0], [11.2, 3.0], [11.3, 3.0], [11.4, 3.0], [11.5, 3.0], [11.6, 3.0], [11.7, 3.0], [11.8, 3.0], [11.9, 3.0], [12.0, 3.0], [12.1, 3.0], [12.2, 3.0], [12.3, 3.0], [12.4, 3.0], [12.5, 3.0], [12.6, 3.0], [12.7, 3.0], [12.8, 3.0], [12.9, 3.0], [13.0, 3.0], [13.1, 3.0], [13.2, 3.0], [13.3, 3.0], [13.4, 3.0], [13.5, 3.0], [13.6, 3.0], [13.7, 3.0], [13.8, 3.0], [13.9, 3.0], [14.0, 3.0], [14.1, 3.0], [14.2, 3.0], [14.3, 3.0], [14.4, 3.0], [14.5, 3.0], [14.6, 3.0], [14.7, 3.0], [14.8, 3.0], [14.9, 3.0], [15.0, 3.0], [15.1, 3.0], [15.2, 3.0], [15.3, 3.0], [15.4, 3.0], [15.5, 3.0], [15.6, 3.0], [15.7, 3.0], [15.8, 3.0], [15.9, 3.0], [16.0, 3.0], [16.1, 3.0], [16.2, 3.0], [16.3, 3.0], [16.4, 3.0], [16.5, 3.0], [16.6, 3.0], [16.7, 3.0], [16.8, 3.0], [16.9, 3.0], [17.0, 3.0], [17.1, 3.0], [17.2, 3.0], [17.3, 3.0], [17.4, 3.0], [17.5, 3.0], [17.6, 3.0], [17.7, 3.0], [17.8, 3.0], [17.9, 3.0], [18.0, 3.0], [18.1, 3.0], [18.2, 3.0], [18.3, 3.0], [18.4, 3.0], [18.5, 3.0], [18.6, 3.0], [18.7, 3.0], [18.8, 3.0], [18.9, 3.0], [19.0, 3.0], [19.1, 3.0], [19.2, 3.0], [19.3, 3.0], [19.4, 3.0], [19.5, 3.0], [19.6, 3.0], [19.7, 3.0], [19.8, 3.0], [19.9, 3.0], [20.0, 3.0], [20.1, 3.0], [20.2, 3.0], [20.3, 3.0], [20.4, 3.0], [20.5, 3.0], [20.6, 3.0], [20.7, 3.0], [20.8, 3.0], [20.9, 3.0], [21.0, 3.0], [21.1, 3.0], [21.2, 3.0], [21.3, 3.0], [21.4, 3.0], [21.5, 3.0], [21.6, 3.0], [21.7, 3.0], [21.8, 3.0], [21.9, 3.0], [22.0, 3.0], [22.1, 3.0], [22.2, 3.0], [22.3, 3.0], [22.4, 3.0], [22.5, 3.0], [22.6, 3.0], [22.7, 3.0], [22.8, 3.0], [22.9, 3.0], [23.0, 3.0], [23.1, 3.0], [23.2, 3.0], [23.3, 3.0], [23.4, 3.0], [23.5, 3.0], [23.6, 3.0], [23.7, 3.0], [23.8, 3.0], [23.9, 3.0], [24.0, 3.0], [24.1, 3.0], [24.2, 3.0], [24.3, 3.0], [24.4, 3.0], [24.5, 3.0], [24.6, 3.0], [24.7, 3.0], [24.8, 3.0], [24.9, 3.0], [25.0, 3.0], [25.1, 3.0], [25.2, 3.0], [25.3, 3.0], [25.4, 3.0], [25.5, 3.0], [25.6, 3.0], [25.7, 3.0], [25.8, 3.0], [25.9, 3.0], [26.0, 3.0], [26.1, 3.0], [26.2, 3.0], [26.3, 3.0], [26.4, 3.0], [26.5, 3.0], [26.6, 3.0], [26.7, 3.0], [26.8, 3.0], [26.9, 3.0], [27.0, 3.0], [27.1, 3.0], [27.2, 3.0], [27.3, 3.0], [27.4, 3.0], [27.5, 3.0], [27.6, 3.0], [27.7, 3.0], [27.8, 3.0], [27.9, 3.0], [28.0, 3.0], [28.1, 3.0], [28.2, 3.0], [28.3, 3.0], [28.4, 3.0], [28.5, 3.0], [28.6, 3.0], [28.7, 3.0], [28.8, 3.0], [28.9, 3.0], [29.0, 3.0], [29.1, 3.0], [29.2, 3.0], [29.3, 3.0], [29.4, 3.0], [29.5, 3.0], [29.6, 3.0], [29.7, 3.0], [29.8, 3.0], [29.9, 3.0], [30.0, 3.0], [30.1, 3.0], [30.2, 3.0], [30.3, 3.0], [30.4, 3.0], [30.5, 3.0], [30.6, 3.0], [30.7, 3.0], [30.8, 3.0], [30.9, 3.0], [31.0, 3.0], [31.1, 3.0], [31.2, 3.0], [31.3, 3.0], [31.4, 3.0], [31.5, 3.0], [31.6, 3.0], [31.7, 3.0], [31.8, 3.0], [31.9, 3.0], [32.0, 3.0], [32.1, 3.0], [32.2, 3.0], [32.3, 3.0], [32.4, 3.0], [32.5, 3.0], [32.6, 3.0], [32.7, 3.0], [32.8, 3.0], [32.9, 3.0], [33.0, 3.0], [33.1, 3.0], [33.2, 3.0], [33.3, 3.0], [33.4, 3.0], [33.5, 3.0], [33.6, 3.0], [33.7, 3.0], [33.8, 3.0], [33.9, 3.0], [34.0, 3.0], [34.1, 3.0], [34.2, 3.0], [34.3, 3.0], [34.4, 3.0], [34.5, 3.0], [34.6, 3.0], [34.7, 3.0], [34.8, 3.0], [34.9, 3.0], [35.0, 3.0], [35.1, 3.0], [35.2, 3.0], [35.3, 3.0], [35.4, 3.0], [35.5, 3.0], [35.6, 3.0], [35.7, 3.0], [35.8, 3.0], [35.9, 3.0], [36.0, 3.0], [36.1, 3.0], [36.2, 3.0], [36.3, 3.0], [36.4, 3.0], [36.5, 3.0], [36.6, 3.0], [36.7, 3.0], [36.8, 3.0], [36.9, 3.0], [37.0, 3.0], [37.1, 3.0], [37.2, 3.0], [37.3, 3.0], [37.4, 3.0], [37.5, 3.0], [37.6, 3.0], [37.7, 3.0], [37.8, 3.0], [37.9, 3.0], [38.0, 3.0], [38.1, 3.0], [38.2, 3.0], [38.3, 3.0], [38.4, 3.0], [38.5, 3.0], [38.6, 3.0], [38.7, 3.0], [38.8, 3.0], [38.9, 3.0], [39.0, 3.0], [39.1, 3.0], [39.2, 3.0], [39.3, 3.0], [39.4, 3.0], [39.5, 3.0], [39.6, 3.0], [39.7, 3.0], [39.8, 3.0], [39.9, 3.0], [40.0, 3.0], [40.1, 3.0], [40.2, 3.0], [40.3, 3.0], [40.4, 3.0], [40.5, 3.0], [40.6, 4.0], [40.7, 4.0], [40.8, 4.0], [40.9, 4.0], [41.0, 4.0], [41.1, 4.0], [41.2, 4.0], [41.3, 4.0], [41.4, 4.0], [41.5, 4.0], [41.6, 4.0], [41.7, 4.0], [41.8, 4.0], [41.9, 4.0], [42.0, 4.0], [42.1, 4.0], [42.2, 4.0], [42.3, 4.0], [42.4, 4.0], [42.5, 4.0], [42.6, 4.0], [42.7, 4.0], [42.8, 4.0], [42.9, 4.0], [43.0, 4.0], [43.1, 4.0], [43.2, 4.0], [43.3, 4.0], [43.4, 4.0], [43.5, 4.0], [43.6, 4.0], [43.7, 4.0], [43.8, 4.0], [43.9, 4.0], [44.0, 4.0], [44.1, 4.0], [44.2, 4.0], [44.3, 4.0], [44.4, 4.0], [44.5, 4.0], [44.6, 4.0], [44.7, 4.0], [44.8, 4.0], [44.9, 4.0], [45.0, 4.0], [45.1, 4.0], [45.2, 4.0], [45.3, 4.0], [45.4, 4.0], [45.5, 4.0], [45.6, 4.0], [45.7, 4.0], [45.8, 4.0], [45.9, 4.0], [46.0, 4.0], [46.1, 4.0], [46.2, 4.0], [46.3, 4.0], [46.4, 4.0], [46.5, 4.0], [46.6, 4.0], [46.7, 4.0], [46.8, 4.0], [46.9, 4.0], [47.0, 4.0], [47.1, 4.0], [47.2, 4.0], [47.3, 4.0], [47.4, 4.0], [47.5, 4.0], [47.6, 4.0], [47.7, 4.0], [47.8, 4.0], [47.9, 4.0], [48.0, 4.0], [48.1, 4.0], [48.2, 4.0], [48.3, 4.0], [48.4, 4.0], [48.5, 4.0], [48.6, 4.0], [48.7, 4.0], [48.8, 4.0], [48.9, 4.0], [49.0, 4.0], [49.1, 4.0], [49.2, 4.0], [49.3, 4.0], [49.4, 4.0], [49.5, 4.0], [49.6, 4.0], [49.7, 4.0], [49.8, 4.0], [49.9, 4.0], [50.0, 4.0], [50.1, 4.0], [50.2, 4.0], [50.3, 4.0], [50.4, 4.0], [50.5, 4.0], [50.6, 4.0], [50.7, 4.0], [50.8, 4.0], [50.9, 4.0], [51.0, 4.0], [51.1, 4.0], [51.2, 4.0], [51.3, 4.0], [51.4, 4.0], [51.5, 4.0], [51.6, 4.0], [51.7, 4.0], [51.8, 4.0], [51.9, 4.0], [52.0, 4.0], [52.1, 4.0], [52.2, 4.0], [52.3, 4.0], [52.4, 4.0], [52.5, 4.0], [52.6, 4.0], [52.7, 4.0], [52.8, 4.0], [52.9, 4.0], [53.0, 4.0], [53.1, 4.0], [53.2, 4.0], [53.3, 4.0], [53.4, 4.0], [53.5, 4.0], [53.6, 4.0], [53.7, 4.0], [53.8, 4.0], [53.9, 4.0], [54.0, 4.0], [54.1, 4.0], [54.2, 4.0], [54.3, 4.0], [54.4, 4.0], [54.5, 4.0], [54.6, 4.0], [54.7, 4.0], [54.8, 4.0], [54.9, 4.0], [55.0, 4.0], [55.1, 4.0], [55.2, 4.0], [55.3, 4.0], [55.4, 4.0], [55.5, 4.0], [55.6, 4.0], [55.7, 4.0], [55.8, 4.0], [55.9, 4.0], [56.0, 4.0], [56.1, 4.0], [56.2, 4.0], [56.3, 4.0], [56.4, 4.0], [56.5, 4.0], [56.6, 4.0], [56.7, 4.0], [56.8, 4.0], [56.9, 4.0], [57.0, 4.0], [57.1, 4.0], [57.2, 4.0], [57.3, 4.0], [57.4, 4.0], [57.5, 4.0], [57.6, 4.0], [57.7, 4.0], [57.8, 4.0], [57.9, 4.0], [58.0, 4.0], [58.1, 4.0], [58.2, 4.0], [58.3, 4.0], [58.4, 4.0], [58.5, 4.0], [58.6, 4.0], [58.7, 4.0], [58.8, 4.0], [58.9, 4.0], [59.0, 4.0], [59.1, 4.0], [59.2, 4.0], [59.3, 4.0], [59.4, 4.0], [59.5, 4.0], [59.6, 4.0], [59.7, 4.0], [59.8, 4.0], [59.9, 4.0], [60.0, 4.0], [60.1, 4.0], [60.2, 4.0], [60.3, 4.0], [60.4, 4.0], [60.5, 4.0], [60.6, 4.0], [60.7, 4.0], [60.8, 4.0], [60.9, 4.0], [61.0, 4.0], [61.1, 4.0], [61.2, 4.0], [61.3, 4.0], [61.4, 4.0], [61.5, 4.0], [61.6, 4.0], [61.7, 4.0], [61.8, 4.0], [61.9, 4.0], [62.0, 4.0], [62.1, 4.0], [62.2, 4.0], [62.3, 4.0], [62.4, 4.0], [62.5, 4.0], [62.6, 4.0], [62.7, 4.0], [62.8, 4.0], [62.9, 4.0], [63.0, 4.0], [63.1, 4.0], [63.2, 4.0], [63.3, 4.0], [63.4, 4.0], [63.5, 4.0], [63.6, 4.0], [63.7, 4.0], [63.8, 4.0], [63.9, 4.0], [64.0, 4.0], [64.1, 4.0], [64.2, 4.0], [64.3, 4.0], [64.4, 4.0], [64.5, 4.0], [64.6, 4.0], [64.7, 4.0], [64.8, 4.0], [64.9, 4.0], [65.0, 4.0], [65.1, 4.0], [65.2, 4.0], [65.3, 4.0], [65.4, 4.0], [65.5, 4.0], [65.6, 4.0], [65.7, 4.0], [65.8, 4.0], [65.9, 4.0], [66.0, 4.0], [66.1, 4.0], [66.2, 4.0], [66.3, 4.0], [66.4, 4.0], [66.5, 4.0], [66.6, 4.0], [66.7, 4.0], [66.8, 4.0], [66.9, 4.0], [67.0, 4.0], [67.1, 4.0], [67.2, 4.0], [67.3, 4.0], [67.4, 4.0], [67.5, 4.0], [67.6, 4.0], [67.7, 4.0], [67.8, 4.0], [67.9, 4.0], [68.0, 4.0], [68.1, 4.0], [68.2, 4.0], [68.3, 4.0], [68.4, 4.0], [68.5, 4.0], [68.6, 4.0], [68.7, 4.0], [68.8, 4.0], [68.9, 4.0], [69.0, 4.0], [69.1, 4.0], [69.2, 4.0], [69.3, 4.0], [69.4, 4.0], [69.5, 4.0], [69.6, 4.0], [69.7, 4.0], [69.8, 4.0], [69.9, 4.0], [70.0, 4.0], [70.1, 4.0], [70.2, 4.0], [70.3, 4.0], [70.4, 4.0], [70.5, 4.0], [70.6, 4.0], [70.7, 4.0], [70.8, 4.0], [70.9, 4.0], [71.0, 4.0], [71.1, 4.0], [71.2, 4.0], [71.3, 4.0], [71.4, 4.0], [71.5, 4.0], [71.6, 4.0], [71.7, 4.0], [71.8, 4.0], [71.9, 4.0], [72.0, 4.0], [72.1, 4.0], [72.2, 4.0], [72.3, 4.0], [72.4, 4.0], [72.5, 4.0], [72.6, 4.0], [72.7, 4.0], [72.8, 4.0], [72.9, 4.0], [73.0, 4.0], [73.1, 4.0], [73.2, 4.0], [73.3, 4.0], [73.4, 4.0], [73.5, 4.0], [73.6, 4.0], [73.7, 4.0], [73.8, 4.0], [73.9, 4.0], [74.0, 4.0], [74.1, 4.0], [74.2, 4.0], [74.3, 4.0], [74.4, 4.0], [74.5, 4.0], [74.6, 4.0], [74.7, 4.0], [74.8, 4.0], [74.9, 4.0], [75.0, 4.0], [75.1, 4.0], [75.2, 4.0], [75.3, 4.0], [75.4, 4.0], [75.5, 4.0], [75.6, 4.0], [75.7, 4.0], [75.8, 4.0], [75.9, 4.0], [76.0, 4.0], [76.1, 4.0], [76.2, 4.0], [76.3, 4.0], [76.4, 4.0], [76.5, 4.0], [76.6, 4.0], [76.7, 4.0], [76.8, 4.0], [76.9, 4.0], [77.0, 4.0], [77.1, 4.0], [77.2, 4.0], [77.3, 4.0], [77.4, 4.0], [77.5, 4.0], [77.6, 4.0], [77.7, 4.0], [77.8, 4.0], [77.9, 4.0], [78.0, 4.0], [78.1, 4.0], [78.2, 4.0], [78.3, 4.0], [78.4, 5.0], [78.5, 5.0], [78.6, 5.0], [78.7, 5.0], [78.8, 5.0], [78.9, 5.0], [79.0, 5.0], [79.1, 5.0], [79.2, 5.0], [79.3, 5.0], [79.4, 5.0], [79.5, 5.0], [79.6, 5.0], [79.7, 5.0], [79.8, 5.0], [79.9, 5.0], [80.0, 5.0], [80.1, 5.0], [80.2, 5.0], [80.3, 5.0], [80.4, 5.0], [80.5, 5.0], [80.6, 5.0], [80.7, 5.0], [80.8, 5.0], [80.9, 5.0], [81.0, 5.0], [81.1, 5.0], [81.2, 5.0], [81.3, 5.0], [81.4, 5.0], [81.5, 5.0], [81.6, 5.0], [81.7, 5.0], [81.8, 5.0], [81.9, 5.0], [82.0, 5.0], [82.1, 5.0], [82.2, 5.0], [82.3, 5.0], [82.4, 5.0], [82.5, 5.0], [82.6, 5.0], [82.7, 5.0], [82.8, 5.0], [82.9, 5.0], [83.0, 5.0], [83.1, 5.0], [83.2, 5.0], [83.3, 5.0], [83.4, 5.0], [83.5, 5.0], [83.6, 5.0], [83.7, 5.0], [83.8, 5.0], [83.9, 5.0], [84.0, 5.0], [84.1, 5.0], [84.2, 5.0], [84.3, 5.0], [84.4, 5.0], [84.5, 5.0], [84.6, 5.0], [84.7, 5.0], [84.8, 5.0], [84.9, 5.0], [85.0, 5.0], [85.1, 5.0], [85.2, 5.0], [85.3, 5.0], [85.4, 5.0], [85.5, 5.0], [85.6, 5.0], [85.7, 5.0], [85.8, 5.0], [85.9, 5.0], [86.0, 5.0], [86.1, 5.0], [86.2, 5.0], [86.3, 5.0], [86.4, 5.0], [86.5, 5.0], [86.6, 5.0], [86.7, 5.0], [86.8, 5.0], [86.9, 5.0], [87.0, 5.0], [87.1, 5.0], [87.2, 5.0], [87.3, 5.0], [87.4, 5.0], [87.5, 5.0], [87.6, 5.0], [87.7, 5.0], [87.8, 5.0], [87.9, 5.0], [88.0, 5.0], [88.1, 5.0], [88.2, 5.0], [88.3, 5.0], [88.4, 5.0], [88.5, 5.0], [88.6, 5.0], [88.7, 5.0], [88.8, 5.0], [88.9, 5.0], [89.0, 5.0], [89.1, 5.0], [89.2, 5.0], [89.3, 5.0], [89.4, 5.0], [89.5, 5.0], [89.6, 5.0], [89.7, 5.0], [89.8, 5.0], [89.9, 5.0], [90.0, 5.0], [90.1, 5.0], [90.2, 5.0], [90.3, 5.0], [90.4, 5.0], [90.5, 5.0], [90.6, 5.0], [90.7, 5.0], [90.8, 5.0], [90.9, 5.0], [91.0, 5.0], [91.1, 5.0], [91.2, 5.0], [91.3, 5.0], [91.4, 5.0], [91.5, 5.0], [91.6, 5.0], [91.7, 5.0], [91.8, 5.0], [91.9, 5.0], [92.0, 5.0], [92.1, 5.0], [92.2, 5.0], [92.3, 5.0], [92.4, 6.0], [92.5, 6.0], [92.6, 6.0], [92.7, 6.0], [92.8, 6.0], [92.9, 6.0], [93.0, 6.0], [93.1, 6.0], [93.2, 6.0], [93.3, 6.0], [93.4, 6.0], [93.5, 6.0], [93.6, 6.0], [93.7, 6.0], [93.8, 6.0], [93.9, 6.0], [94.0, 6.0], [94.1, 6.0], [94.2, 6.0], [94.3, 6.0], [94.4, 6.0], [94.5, 6.0], [94.6, 6.0], [94.7, 6.0], [94.8, 6.0], [94.9, 6.0], [95.0, 6.0], [95.1, 6.0], [95.2, 6.0], [95.3, 6.0], [95.4, 6.0], [95.5, 6.0], [95.6, 6.0], [95.7, 6.0], [95.8, 6.0], [95.9, 6.0], [96.0, 6.0], [96.1, 6.0], [96.2, 6.0], [96.3, 6.0], [96.4, 6.0], [96.5, 6.0], [96.6, 6.0], [96.7, 6.0], [96.8, 7.0], [96.9, 7.0], [97.0, 7.0], [97.1, 7.0], [97.2, 7.0], [97.3, 7.0], [97.4, 7.0], [97.5, 7.0], [97.6, 7.0], [97.7, 7.0], [97.8, 7.0], [97.9, 7.0], [98.0, 7.0], [98.1, 8.0], [98.2, 8.0], [98.3, 8.0], [98.4, 8.0], [98.5, 8.0], [98.6, 9.0], [98.7, 9.0], [98.8, 9.0], [98.9, 10.0], [99.0, 11.0], [99.1, 12.0], [99.2, 14.0], [99.3, 17.0], [99.4, 23.0], [99.5, 27.0], [99.6, 36.0], [99.7, 58.0], [99.8, 163.0], [99.9, 184.0], [100.0, 228.0]], "isOverall": false, "label": "SeleccionTarifaYCantidad", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 3.0, "minX": 0.0, "maxY": 5374.0, "series": [{"data": [[0.0, 5374.0], [100.0, 11.0], [200.0, 3.0]], "isOverall": false, "label": "SeleccionTarifaYCantidad", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 200.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 31.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1.500ms"], [2, "Requests having \nresponse time > 1.500ms"], [3, "Requests in error"]], "maxY": 5357.0, "series": [{"data": [[0.0, 5357.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1.500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1.500ms", "isController": false}, {"data": [[3.0, 31.0]], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 22.727272727272727, "minX": 1.794629862E12, "maxY": 100.0, "series": [{"data": [[1.79462989E12, 100.0], [1.794629892E12, 100.0], [1.794629894E12, 100.0], [1.794629896E12, 100.0], [1.794629898E12, 100.0], [1.7946299E12, 100.0], [1.794629902E12, 100.0], [1.794629904E12, 100.0], [1.794629863E12, 31.15], [1.794629906E12, 100.0], [1.794629865E12, 51.693877551020414], [1.794629908E12, 100.0], [1.794629867E12, 72.0151515151515], [1.79462991E12, 100.0], [1.794629869E12, 91.78651685393261], [1.794629912E12, 100.0], [1.794629871E12, 100.0], [1.794629914E12, 100.0], [1.794629873E12, 100.0], [1.794629916E12, 100.0], [1.794629875E12, 100.0], [1.794629918E12, 100.0], [1.794629877E12, 100.0], [1.79462992E12, 22.727272727272727], [1.794629879E12, 100.0], [1.794629881E12, 100.0], [1.794629883E12, 100.0], [1.794629885E12, 100.0], [1.794629887E12, 100.0], [1.794629889E12, 100.0], [1.794629891E12, 100.0], [1.794629893E12, 100.0], [1.794629895E12, 100.0], [1.794629897E12, 100.0], [1.794629899E12, 100.0], [1.794629901E12, 100.0], [1.794629903E12, 100.0], [1.794629905E12, 100.0], [1.794629862E12, 27.0], [1.794629864E12, 42.96875], [1.794629907E12, 100.0], [1.794629909E12, 100.0], [1.794629866E12, 61.9622641509434], [1.794629868E12, 82.17808219178083], [1.794629911E12, 100.0], [1.794629913E12, 100.0], [1.79462987E12, 99.70000000000002], [1.794629872E12, 100.0], [1.794629915E12, 100.0], [1.794629917E12, 100.0], [1.794629874E12, 100.0], [1.794629876E12, 100.0], [1.794629919E12, 79.49473684210534], [1.794629878E12, 100.0], [1.79462988E12, 100.0], [1.794629882E12, 100.0], [1.794629884E12, 100.0], [1.794629886E12, 100.0], [1.794629888E12, 100.0]], "isOverall": false, "label": "Usuarios parametrizados - experimentacion", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.79462992E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 2.0, "minX": 2.0, "maxY": 35.75, "series": [{"data": [[2.0, 3.0], [3.0, 3.0], [5.0, 5.0], [6.0, 3.0], [7.0, 4.0], [8.0, 3.0], [9.0, 5.0], [10.0, 3.0], [12.0, 2.0], [13.0, 4.0], [14.0, 3.0], [16.0, 4.5], [18.0, 4.5], [19.0, 2.0], [20.0, 4.0], [22.0, 4.0], [23.0, 5.0], [24.0, 3.0], [25.0, 3.0], [26.0, 4.0], [27.0, 35.75], [28.0, 5.0], [29.0, 5.333333333333333], [30.0, 10.5], [31.0, 5.5], [32.0, 4.25], [33.0, 5.0], [34.0, 8.166666666666666], [35.0, 4.0], [37.0, 4.0], [36.0, 4.0], [38.0, 6.0], [39.0, 4.0], [40.0, 5.666666666666667], [41.0, 5.75], [42.0, 5.6], [43.0, 5.25], [44.0, 5.666666666666667], [45.0, 5.5], [46.0, 4.5], [47.0, 4.500000000000001], [48.0, 4.0], [49.0, 6.0], [50.0, 4.625000000000001], [51.0, 4.0], [52.0, 4.25], [53.0, 4.333333333333333], [54.0, 5.857142857142857], [55.0, 4.8], [56.0, 4.666666666666666], [57.0, 4.0], [58.0, 4.75], [59.0, 5.285714285714286], [60.0, 6.111111111111112], [61.0, 6.1000000000000005], [62.0, 4.124999999999999], [63.0, 5.4], [64.0, 5.166666666666666], [65.0, 5.4], [66.0, 4.0], [67.0, 5.0], [68.0, 4.909090909090909], [69.0, 5.5], [70.0, 5.7], [71.0, 5.333333333333334], [72.0, 4.875], [73.0, 5.125], [74.0, 4.428571428571429], [75.0, 4.153846153846154], [76.0, 3.6249999999999996], [77.0, 4.0], [78.0, 5.545454545454546], [79.0, 5.0], [80.0, 5.5], [81.0, 4.5], [82.0, 21.333333333333332], [83.0, 20.77777777777777], [84.0, 3.7499999999999996], [85.0, 4.214285714285714], [86.0, 4.428571428571429], [87.0, 3.5999999999999996], [88.0, 3.625], [89.0, 3.2500000000000004], [90.0, 6.312499999999999], [91.0, 4.875000000000001], [92.0, 4.92857142857143], [93.0, 3.7999999999999994], [94.0, 4.2142857142857135], [95.0, 4.8181818181818175], [96.0, 4.0], [97.0, 6.111111111111111], [98.0, 4.133333333333334], [99.0, 4.1875], [100.0, 4.26680412371134]], "isOverall": false, "label": "SeleccionTarifaYCantidad", "isController": false}, {"data": [[96.820527097253, 4.404046028210858]], "isOverall": false, "label": "SeleccionTarifaYCantidad-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 973.0, "minX": 1.794629862E12, "maxY": 70066.0, "series": [{"data": [[1.79462989E12, 28519.0], [1.794629892E12, 26608.0], [1.794629894E12, 26873.0], [1.794629896E12, 28815.0], [1.794629898E12, 29353.0], [1.7946299E12, 28523.0], [1.794629902E12, 24745.0], [1.794629904E12, 27134.0], [1.794629863E12, 5480.0], [1.794629906E12, 27984.0], [1.794629865E12, 13442.0], [1.794629908E12, 26342.0], [1.794629867E12, 18074.0], [1.79462991E12, 24389.0], [1.794629869E12, 24389.0], [1.794629912E12, 58752.0], [1.794629871E12, 28258.0], [1.794629914E12, 27692.0], [1.794629873E12, 29600.0], [1.794629916E12, 28795.0], [1.794629875E12, 27683.0], [1.794629918E12, 26588.0], [1.794629877E12, 27704.0], [1.79462992E12, 12094.0], [1.794629879E12, 29325.0], [1.794629881E12, 27942.0], [1.794629883E12, 25219.0], [1.794629885E12, 28005.0], [1.794629887E12, 27161.0], [1.794629889E12, 27699.0], [1.794629891E12, 26614.0], [1.794629893E12, 29328.0], [1.794629895E12, 26037.0], [1.794629897E12, 26899.0], [1.794629899E12, 23835.0], [1.794629901E12, 27392.0], [1.794629903E12, 29047.0], [1.794629905E12, 28536.0], [1.794629862E12, 1100.0], [1.794629864E12, 8776.0], [1.794629907E12, 26592.0], [1.794629909E12, 26026.0], [1.794629866E12, 14544.0], [1.794629868E12, 20056.0], [1.794629911E12, 26070.0], [1.794629913E12, 26355.0], [1.79462987E12, 24693.0], [1.794629872E12, 25214.0], [1.794629915E12, 27167.0], [1.794629917E12, 29625.0], [1.794629874E12, 25808.0], [1.794629876E12, 28264.0], [1.794629919E12, 26034.0], [1.794629878E12, 27958.0], [1.79462988E12, 26368.0], [1.794629882E12, 23610.0], [1.794629884E12, 70066.0], [1.794629886E12, 28764.0], [1.794629888E12, 27137.0]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.79462989E12, 25265.0], [1.794629892E12, 23577.0], [1.794629894E12, 23809.0], [1.794629896E12, 25531.0], [1.794629898E12, 26010.0], [1.7946299E12, 25283.0], [1.794629902E12, 21923.0], [1.794629904E12, 24042.0], [1.794629863E12, 4857.0], [1.794629906E12, 24793.0], [1.794629865E12, 11909.0], [1.794629908E12, 23338.0], [1.794629867E12, 16019.0], [1.79462991E12, 21612.0], [1.794629869E12, 21612.0], [1.794629912E12, 21618.0], [1.794629871E12, 25045.0], [1.794629914E12, 24534.0], [1.794629873E12, 26228.0], [1.794629916E12, 25513.0], [1.794629875E12, 24532.0], [1.794629918E12, 23562.0], [1.794629877E12, 24547.0], [1.79462992E12, 10712.0], [1.794629879E12, 25987.0], [1.794629881E12, 24756.0], [1.794629883E12, 22340.0], [1.794629885E12, 24816.0], [1.794629887E12, 24068.0], [1.794629889E12, 24549.0], [1.794629891E12, 23580.0], [1.794629893E12, 25989.0], [1.794629895E12, 23073.0], [1.794629897E12, 23827.0], [1.794629899E12, 21116.0], [1.794629901E12, 24267.0], [1.794629903E12, 25738.0], [1.794629905E12, 25285.0], [1.794629862E12, 973.0], [1.794629864E12, 7776.0], [1.794629907E12, 23563.0], [1.794629909E12, 23064.0], [1.794629866E12, 12886.0], [1.794629868E12, 17767.0], [1.794629911E12, 23094.0], [1.794629913E12, 23351.0], [1.79462987E12, 21875.0], [1.794629872E12, 22337.0], [1.794629915E12, 24073.0], [1.794629917E12, 26247.0], [1.794629874E12, 22863.0], [1.794629876E12, 25045.0], [1.794629919E12, 23069.0], [1.794629878E12, 24768.0], [1.79462988E12, 23369.0], [1.794629882E12, 20921.0], [1.794629884E12, 19931.0], [1.794629886E12, 25482.0], [1.794629888E12, 24044.0]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.79462992E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 3.1682242990654217, "minX": 1.794629862E12, "maxY": 35.75, "series": [{"data": [[1.79462989E12, 3.6634615384615388], [1.794629892E12, 3.68041237113402], [1.794629894E12, 3.7857142857142847], [1.794629896E12, 3.542857142857144], [1.794629898E12, 3.317757009345794], [1.7946299E12, 3.7403846153846145], [1.794629902E12, 3.9111111111111105], [1.794629904E12, 3.757575757575757], [1.794629863E12, 7.1], [1.794629906E12, 4.176470588235295], [1.794629865E12, 5.040816326530611], [1.794629908E12, 3.770833333333333], [1.794629867E12, 4.939393939393938], [1.79462991E12, 3.808988764044943], [1.794629869E12, 4.820224719101126], [1.794629912E12, 15.421568627450977], [1.794629871E12, 4.165048543689324], [1.794629914E12, 3.4554455445544563], [1.794629873E12, 3.9629629629629632], [1.794629916E12, 3.390476190476191], [1.794629875E12, 4.079207920792081], [1.794629918E12, 3.6391752577319587], [1.794629877E12, 3.6930693069306924], [1.79462992E12, 3.704545454545454], [1.794629879E12, 3.1682242990654217], [1.794629881E12, 3.4509803921568634], [1.794629883E12, 3.6739130434782616], [1.794629885E12, 3.372549019607842], [1.794629887E12, 3.7171717171717176], [1.794629889E12, 3.6435643564356432], [1.794629891E12, 4.989690721649484], [1.794629893E12, 3.60747663551402], [1.794629895E12, 3.873684210526317], [1.794629897E12, 3.438775510204082], [1.794629899E12, 3.574712643678161], [1.794629901E12, 3.6599999999999984], [1.794629903E12, 3.6415094339622645], [1.794629905E12, 3.6153846153846154], [1.794629862E12, 35.75], [1.794629864E12, 5.593749999999999], [1.794629907E12, 3.762886597938142], [1.794629909E12, 3.4736842105263177], [1.794629866E12, 5.566037735849056], [1.794629868E12, 9.342465753424658], [1.794629911E12, 3.947368421052632], [1.794629913E12, 3.322916666666667], [1.79462987E12, 4.933333333333331], [1.794629872E12, 4.152173913043479], [1.794629915E12, 3.333333333333333], [1.794629917E12, 3.666666666666667], [1.794629874E12, 4.148936170212766], [1.794629876E12, 4.155339805825242], [1.794629919E12, 3.747368421052633], [1.794629878E12, 3.5196078431372544], [1.79462988E12, 3.2708333333333335], [1.794629882E12, 3.383720930232558], [1.794629884E12, 17.92], [1.794629886E12, 3.685714285714286], [1.794629888E12, 3.9696969696969697]], "isOverall": false, "label": "SeleccionTarifaYCantidad", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.79462992E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 2.989583333333334, "minX": 1.794629862E12, "maxY": 34.75, "series": [{"data": [[1.79462989E12, 3.4038461538461533], [1.794629892E12, 3.4226804123711334], [1.794629894E12, 3.5306122448979607], [1.794629896E12, 3.3333333333333335], [1.794629898E12, 3.1401869158878495], [1.7946299E12, 3.5576923076923084], [1.794629902E12, 3.6333333333333337], [1.794629904E12, 3.5252525252525255], [1.794629863E12, 6.7], [1.794629906E12, 3.803921568627452], [1.794629865E12, 4.612244897959184], [1.794629908E12, 3.5104166666666674], [1.794629867E12, 4.545454545454546], [1.79462991E12, 3.4606741573033712], [1.794629869E12, 4.404494382022472], [1.794629912E12, 14.794117647058828], [1.794629871E12, 3.7475728155339816], [1.794629914E12, 3.257425742574259], [1.794629873E12, 3.749999999999999], [1.794629916E12, 3.1999999999999993], [1.794629875E12, 3.8415841584158423], [1.794629918E12, 3.371134020618557], [1.794629877E12, 3.455445544554456], [1.79462992E12, 3.4999999999999996], [1.794629879E12, 3.0], [1.794629881E12, 3.147058823529412], [1.794629883E12, 3.41304347826087], [1.794629885E12, 3.156862745098039], [1.794629887E12, 3.414141414141415], [1.794629889E12, 3.415841584158415], [1.794629891E12, 4.783505154639177], [1.794629893E12, 3.429906542056074], [1.794629895E12, 3.6], [1.794629897E12, 3.193877551020408], [1.794629899E12, 3.2873563218390793], [1.794629901E12, 3.44], [1.794629903E12, 3.443396226415094], [1.794629905E12, 3.451923076923077], [1.794629862E12, 34.75], [1.794629864E12, 4.968750000000002], [1.794629907E12, 3.5051546391752573], [1.794629909E12, 3.2947368421052645], [1.794629866E12, 5.226415094339623], [1.794629868E12, 8.972602739726021], [1.794629911E12, 3.684210526315791], [1.794629913E12, 3.03125], [1.79462987E12, 4.522222222222222], [1.794629872E12, 3.815217391304348], [1.794629915E12, 3.090909090909091], [1.794629917E12, 3.4814814814814823], [1.794629874E12, 3.8191489361702136], [1.794629876E12, 3.8834951456310685], [1.794629919E12, 3.505263157894738], [1.794629878E12, 3.333333333333333], [1.79462988E12, 2.989583333333334], [1.794629882E12, 3.2209302325581395], [1.794629884E12, 17.339999999999996], [1.794629886E12, 3.4285714285714275], [1.794629888E12, 3.7777777777777772]], "isOverall": false, "label": "SeleccionTarifaYCantidad", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.79462992E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 1.294117647058824, "minX": 1.794629862E12, "maxY": 23.0, "series": [{"data": [[1.79462989E12, 1.4615384615384615], [1.794629892E12, 1.5257731958762883], [1.794629894E12, 1.4795918367346934], [1.794629896E12, 1.4761904761904765], [1.794629898E12, 1.4299065420560746], [1.7946299E12, 1.5192307692307692], [1.794629902E12, 1.6444444444444448], [1.794629904E12, 1.575757575757576], [1.794629863E12, 3.2499999999999996], [1.794629906E12, 1.6568627450980393], [1.794629865E12, 2.387755102040816], [1.794629908E12, 1.7187499999999998], [1.794629867E12, 2.3030303030303023], [1.79462991E12, 1.7303370786516854], [1.794629869E12, 1.9325842696629207], [1.794629912E12, 1.6470588235294121], [1.794629871E12, 1.9611650485436891], [1.794629914E12, 1.5247524752475243], [1.794629873E12, 1.7777777777777781], [1.794629916E12, 1.5333333333333332], [1.794629875E12, 1.6633663366336637], [1.794629918E12, 1.4948453608247425], [1.794629877E12, 1.594059405940594], [1.79462992E12, 1.7727272727272725], [1.794629879E12, 1.4018691588785042], [1.794629881E12, 1.333333333333334], [1.794629883E12, 1.499999999999999], [1.794629885E12, 1.294117647058824], [1.794629887E12, 1.4747474747474747], [1.794629889E12, 1.5148514851485153], [1.794629891E12, 1.3917525773195878], [1.794629893E12, 1.5700934579439252], [1.794629895E12, 1.5789473684210524], [1.794629897E12, 1.551020408163265], [1.794629899E12, 1.5172413793103445], [1.794629901E12, 1.4300000000000002], [1.794629903E12, 1.4622641509433967], [1.794629905E12, 1.5480769230769234], [1.794629862E12, 23.0], [1.794629864E12, 2.656250000000001], [1.794629907E12, 1.6185567010309276], [1.794629909E12, 1.4631578947368427], [1.794629866E12, 2.4339622641509426], [1.794629868E12, 2.2602739726027403], [1.794629911E12, 1.6421052631578952], [1.794629913E12, 1.520833333333333], [1.79462987E12, 2.0888888888888886], [1.794629872E12, 1.9130434782608696], [1.794629915E12, 1.5454545454545456], [1.794629917E12, 1.62962962962963], [1.794629874E12, 1.7234042553191489], [1.794629876E12, 1.7184466019417473], [1.794629919E12, 1.705263157894737], [1.794629878E12, 1.3333333333333344], [1.79462988E12, 1.3541666666666672], [1.794629882E12, 1.3837209302325582], [1.794629884E12, 1.6000000000000005], [1.794629886E12, 1.342857142857143], [1.794629888E12, 1.5050505050505052]], "isOverall": false, "label": "SeleccionTarifaYCantidad", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.79462992E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 1.0, "minX": 1.794629862E12, "maxY": 228.0, "series": [{"data": [[1.79462989E12, 7.0], [1.794629892E12, 8.0], [1.794629894E12, 8.0], [1.794629896E12, 6.0], [1.794629898E12, 5.0], [1.7946299E12, 10.0], [1.794629902E12, 6.0], [1.794629904E12, 7.0], [1.794629863E12, 15.0], [1.794629906E12, 7.0], [1.794629865E12, 8.0], [1.794629908E12, 6.0], [1.794629867E12, 8.0], [1.79462991E12, 6.0], [1.794629869E12, 13.0], [1.794629912E12, 192.0], [1.794629871E12, 6.0], [1.794629914E12, 7.0], [1.794629873E12, 7.0], [1.794629916E12, 6.0], [1.794629875E12, 8.0], [1.794629918E12, 7.0], [1.794629877E12, 6.0], [1.79462992E12, 5.0], [1.794629879E12, 7.0], [1.794629881E12, 7.0], [1.794629883E12, 6.0], [1.794629885E12, 8.0], [1.794629887E12, 6.0], [1.794629889E12, 7.0], [1.794629891E12, 15.0], [1.794629893E12, 7.0], [1.794629895E12, 8.0], [1.794629897E12, 6.0], [1.794629899E12, 6.0], [1.794629901E12, 7.0], [1.794629903E12, 7.0], [1.794629905E12, 7.0], [1.794629862E12, 58.0], [1.794629864E12, 9.0], [1.794629907E12, 6.0], [1.794629909E12, 6.0], [1.794629866E12, 9.0], [1.794629868E12, 44.0], [1.794629911E12, 7.0], [1.794629913E12, 7.0], [1.79462987E12, 9.0], [1.794629872E12, 9.0], [1.794629915E12, 6.0], [1.794629917E12, 6.0], [1.794629874E12, 7.0], [1.794629876E12, 8.0], [1.794629919E12, 6.0], [1.794629878E12, 6.0], [1.79462988E12, 6.0], [1.794629882E12, 5.0], [1.794629884E12, 228.0], [1.794629886E12, 18.0], [1.794629888E12, 9.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.79462989E12, 1.0], [1.794629892E12, 1.0], [1.794629894E12, 2.0], [1.794629896E12, 1.0], [1.794629898E12, 2.0], [1.7946299E12, 2.0], [1.794629902E12, 2.0], [1.794629904E12, 2.0], [1.794629863E12, 4.0], [1.794629906E12, 2.0], [1.794629865E12, 3.0], [1.794629908E12, 2.0], [1.794629867E12, 3.0], [1.79462991E12, 2.0], [1.794629869E12, 2.0], [1.794629912E12, 2.0], [1.794629871E12, 2.0], [1.794629914E12, 2.0], [1.794629873E12, 2.0], [1.794629916E12, 2.0], [1.794629875E12, 2.0], [1.794629918E12, 1.0], [1.794629877E12, 2.0], [1.79462992E12, 2.0], [1.794629879E12, 2.0], [1.794629881E12, 2.0], [1.794629883E12, 2.0], [1.794629885E12, 2.0], [1.794629887E12, 2.0], [1.794629889E12, 2.0], [1.794629891E12, 2.0], [1.794629893E12, 2.0], [1.794629895E12, 2.0], [1.794629897E12, 2.0], [1.794629899E12, 2.0], [1.794629901E12, 2.0], [1.794629903E12, 2.0], [1.794629905E12, 1.0], [1.794629862E12, 10.0], [1.794629864E12, 4.0], [1.794629907E12, 2.0], [1.794629909E12, 2.0], [1.794629866E12, 3.0], [1.794629868E12, 3.0], [1.794629911E12, 1.0], [1.794629913E12, 2.0], [1.79462987E12, 2.0], [1.794629872E12, 2.0], [1.794629915E12, 2.0], [1.794629917E12, 1.0], [1.794629874E12, 2.0], [1.794629876E12, 2.0], [1.794629919E12, 1.0], [1.794629878E12, 2.0], [1.79462988E12, 2.0], [1.794629882E12, 1.0], [1.794629884E12, 1.0], [1.794629886E12, 1.0], [1.794629888E12, 2.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.79462989E12, 5.0], [1.794629892E12, 5.0], [1.794629894E12, 5.0], [1.794629896E12, 5.0], [1.794629898E12, 4.0], [1.7946299E12, 5.0], [1.794629902E12, 5.0], [1.794629904E12, 5.0], [1.794629863E12, 12.0], [1.794629906E12, 5.700000000000003], [1.794629865E12, 6.0], [1.794629908E12, 5.0], [1.794629867E12, 6.0], [1.79462991E12, 5.0], [1.794629869E12, 8.0], [1.794629912E12, 27.0], [1.794629871E12, 5.0], [1.794629914E12, 4.0], [1.794629873E12, 5.0], [1.794629916E12, 5.0], [1.794629875E12, 5.799999999999997], [1.794629918E12, 5.0], [1.794629877E12, 5.0], [1.79462992E12, 5.0], [1.794629879E12, 4.0], [1.794629881E12, 5.0], [1.794629883E12, 5.0], [1.794629885E12, 5.0], [1.794629887E12, 5.0], [1.794629889E12, 5.0], [1.794629891E12, 8.0], [1.794629893E12, 5.0], [1.794629895E12, 5.0], [1.794629897E12, 4.0], [1.794629899E12, 5.0], [1.794629901E12, 5.0], [1.794629903E12, 5.0], [1.794629905E12, 5.0], [1.794629862E12, 58.0], [1.794629864E12, 7.0], [1.794629907E12, 5.0], [1.794629909E12, 5.0], [1.794629866E12, 7.600000000000001], [1.794629868E12, 31.400000000000034], [1.794629911E12, 5.0], [1.794629913E12, 4.0], [1.79462987E12, 7.0], [1.794629872E12, 5.0], [1.794629915E12, 4.0], [1.794629917E12, 5.0], [1.794629874E12, 5.0], [1.794629876E12, 5.0], [1.794629919E12, 5.0], [1.794629878E12, 5.0], [1.79462988E12, 4.0], [1.794629882E12, 4.0], [1.794629884E12, 69.00000000000017], [1.794629886E12, 5.0], [1.794629888E12, 6.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.79462989E12, 6.950000000000003], [1.794629892E12, 8.0], [1.794629894E12, 8.0], [1.794629896E12, 6.0], [1.794629898E12, 5.0], [1.7946299E12, 9.800000000000011], [1.794629902E12, 6.0], [1.794629904E12, 7.0], [1.794629863E12, 15.0], [1.794629906E12, 7.0], [1.794629865E12, 8.0], [1.794629908E12, 6.0], [1.794629867E12, 8.0], [1.79462991E12, 6.0], [1.794629869E12, 13.0], [1.794629912E12, 192.0], [1.794629871E12, 6.0], [1.794629914E12, 6.960000000000008], [1.794629873E12, 7.0], [1.794629916E12, 5.939999999999998], [1.794629875E12, 7.980000000000004], [1.794629918E12, 7.0], [1.794629877E12, 6.0], [1.79462992E12, 5.0], [1.794629879E12, 6.920000000000002], [1.794629881E12, 6.969999999999999], [1.794629883E12, 6.0], [1.794629885E12, 7.969999999999999], [1.794629887E12, 6.0], [1.794629889E12, 7.0], [1.794629891E12, 15.0], [1.794629893E12, 6.920000000000002], [1.794629895E12, 8.0], [1.794629897E12, 6.0], [1.794629899E12, 6.0], [1.794629901E12, 7.0], [1.794629903E12, 6.929999999999993], [1.794629905E12, 6.950000000000003], [1.794629862E12, 58.0], [1.794629864E12, 9.0], [1.794629907E12, 6.0], [1.794629909E12, 6.0], [1.794629866E12, 9.0], [1.794629868E12, 44.0], [1.794629911E12, 7.0], [1.794629913E12, 7.0], [1.79462987E12, 9.0], [1.794629872E12, 9.0], [1.794629915E12, 6.0], [1.794629917E12, 6.0], [1.794629874E12, 7.0], [1.794629876E12, 7.959999999999994], [1.794629919E12, 6.0], [1.794629878E12, 6.0], [1.79462988E12, 6.0], [1.794629882E12, 5.0], [1.794629884E12, 228.0], [1.794629886E12, 17.939999999999998], [1.794629888E12, 9.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.79462989E12, 4.0], [1.794629892E12, 4.0], [1.794629894E12, 4.0], [1.794629896E12, 4.0], [1.794629898E12, 3.0], [1.7946299E12, 4.0], [1.794629902E12, 4.0], [1.794629904E12, 4.0], [1.794629863E12, 6.0], [1.794629906E12, 4.0], [1.794629865E12, 5.0], [1.794629908E12, 4.0], [1.794629867E12, 5.0], [1.79462991E12, 4.0], [1.794629869E12, 4.0], [1.794629912E12, 3.0], [1.794629871E12, 4.0], [1.794629914E12, 4.0], [1.794629873E12, 4.0], [1.794629916E12, 3.0], [1.794629875E12, 4.0], [1.794629918E12, 4.0], [1.794629877E12, 4.0], [1.79462992E12, 4.0], [1.794629879E12, 3.0], [1.794629881E12, 3.0], [1.794629883E12, 4.0], [1.794629885E12, 3.0], [1.794629887E12, 4.0], [1.794629889E12, 4.0], [1.794629891E12, 4.0], [1.794629893E12, 4.0], [1.794629895E12, 4.0], [1.794629897E12, 3.0], [1.794629899E12, 4.0], [1.794629901E12, 4.0], [1.794629903E12, 4.0], [1.794629905E12, 4.0], [1.794629862E12, 37.5], [1.794629864E12, 5.5], [1.794629907E12, 4.0], [1.794629909E12, 3.0], [1.794629866E12, 5.0], [1.794629868E12, 5.0], [1.794629911E12, 4.0], [1.794629913E12, 3.0], [1.79462987E12, 5.0], [1.794629872E12, 4.0], [1.794629915E12, 3.0], [1.794629917E12, 4.0], [1.794629874E12, 4.0], [1.794629876E12, 4.0], [1.794629919E12, 4.0], [1.794629878E12, 4.0], [1.79462988E12, 3.0], [1.794629882E12, 3.0], [1.794629884E12, 4.0], [1.794629886E12, 3.0], [1.794629888E12, 4.0]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.79462989E12, 5.0], [1.794629892E12, 5.099999999999994], [1.794629894E12, 6.0], [1.794629896E12, 5.0], [1.794629898E12, 4.0], [1.7946299E12, 5.75], [1.794629902E12, 5.0], [1.794629904E12, 5.0], [1.794629863E12, 14.849999999999998], [1.794629906E12, 6.0], [1.794629865E12, 7.5], [1.794629908E12, 5.0], [1.794629867E12, 7.0], [1.79462991E12, 5.0], [1.794629869E12, 9.5], [1.794629912E12, 163.5], [1.794629871E12, 5.799999999999997], [1.794629914E12, 4.8999999999999915], [1.794629873E12, 5.0], [1.794629916E12, 5.0], [1.794629875E12, 6.0], [1.794629918E12, 6.0], [1.794629877E12, 5.0], [1.79462992E12, 5.0], [1.794629879E12, 5.0], [1.794629881E12, 6.0], [1.794629883E12, 5.349999999999994], [1.794629885E12, 5.0], [1.794629887E12, 5.0], [1.794629889E12, 5.0], [1.794629891E12, 11.099999999999994], [1.794629893E12, 5.0], [1.794629895E12, 6.0], [1.794629897E12, 5.0], [1.794629899E12, 5.0], [1.794629901E12, 6.0], [1.794629903E12, 5.0], [1.794629905E12, 5.75], [1.794629862E12, 58.0], [1.794629864E12, 7.699999999999996], [1.794629907E12, 6.0], [1.794629909E12, 6.0], [1.794629866E12, 9.0], [1.794629868E12, 36.0], [1.794629911E12, 6.0], [1.794629913E12, 5.0], [1.79462987E12, 7.0], [1.794629872E12, 6.0], [1.794629915E12, 5.0], [1.794629917E12, 5.0], [1.794629874E12, 6.25], [1.794629876E12, 6.0], [1.794629919E12, 5.0], [1.794629878E12, 5.849999999999994], [1.79462988E12, 5.0], [1.794629882E12, 4.6499999999999915], [1.794629884E12, 195.9999999999999], [1.794629886E12, 5.0], [1.794629888E12, 6.0]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.79462992E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 1.0, "minX": 4.0, "maxY": 37.5, "series": [{"data": [[32.0, 5.5], [44.0, 4.0], [49.0, 5.0], [53.0, 5.0], [4.0, 37.5], [66.0, 5.0], [73.0, 5.0], [86.0, 3.0], [87.0, 4.0], [89.0, 4.0], [90.0, 4.0], [92.0, 4.0], [94.0, 4.0], [95.0, 4.0], [96.0, 3.0], [99.0, 4.0], [97.0, 4.0], [98.0, 4.0], [103.0, 4.0], [101.0, 4.0], [102.0, 4.0], [100.0, 4.0], [107.0, 3.0], [105.0, 3.0], [104.0, 4.0], [106.0, 4.0], [108.0, 4.0], [20.0, 6.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[100.0, 1.0], [102.0, 2.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 108.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 0.0, "minX": 4.0, "maxY": 36.5, "series": [{"data": [[32.0, 5.0], [44.0, 3.0], [49.0, 5.0], [53.0, 5.0], [4.0, 36.5], [66.0, 4.0], [73.0, 4.0], [86.0, 3.0], [87.0, 3.0], [89.0, 4.0], [90.0, 4.0], [92.0, 4.0], [94.0, 4.0], [95.0, 3.0], [96.0, 3.0], [99.0, 3.0], [97.0, 4.0], [98.0, 3.0], [103.0, 4.0], [101.0, 3.0], [102.0, 3.0], [100.0, 4.0], [107.0, 3.0], [105.0, 3.0], [104.0, 3.0], [106.0, 3.0], [108.0, 4.0], [20.0, 6.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[100.0, 0.0], [102.0, 0.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 108.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 4.0, "minX": 1.794629862E12, "maxY": 108.0, "series": [{"data": [[1.79462989E12, 104.0], [1.794629892E12, 97.0], [1.794629894E12, 98.0], [1.794629896E12, 103.0], [1.794629898E12, 106.0], [1.7946299E12, 104.0], [1.794629902E12, 91.0], [1.794629904E12, 98.0], [1.794629863E12, 20.0], [1.794629906E12, 101.0], [1.794629865E12, 48.0], [1.794629908E12, 97.0], [1.794629867E12, 66.0], [1.79462991E12, 89.0], [1.794629869E12, 89.0], [1.794629912E12, 102.0], [1.794629871E12, 102.0], [1.794629914E12, 101.0], [1.794629873E12, 108.0], [1.794629916E12, 106.0], [1.794629875E12, 102.0], [1.794629918E12, 97.0], [1.794629877E12, 101.0], [1.79462992E12, 44.0], [1.794629879E12, 108.0], [1.794629881E12, 102.0], [1.794629883E12, 93.0], [1.794629885E12, 103.0], [1.794629887E12, 99.0], [1.794629889E12, 99.0], [1.794629891E12, 97.0], [1.794629893E12, 107.0], [1.794629895E12, 97.0], [1.794629897E12, 99.0], [1.794629899E12, 87.0], [1.794629901E12, 100.0], [1.794629903E12, 106.0], [1.794629905E12, 105.0], [1.794629862E12, 4.0], [1.794629864E12, 33.0], [1.794629907E12, 97.0], [1.794629909E12, 94.0], [1.794629866E12, 53.0], [1.794629868E12, 73.0], [1.794629911E12, 95.0], [1.794629913E12, 96.0], [1.79462987E12, 91.0], [1.794629872E12, 92.0], [1.794629915E12, 99.0], [1.794629917E12, 107.0], [1.794629874E12, 94.0], [1.794629876E12, 103.0], [1.794629919E12, 95.0], [1.794629878E12, 101.0], [1.79462988E12, 95.0], [1.794629882E12, 86.0], [1.794629884E12, 99.0], [1.794629886E12, 104.0], [1.794629888E12, 101.0]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.79462992E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 4.0, "minX": 1.794629862E12, "maxY": 108.0, "series": [{"data": [[1.79462989E12, 104.0], [1.794629892E12, 97.0], [1.794629894E12, 98.0], [1.794629896E12, 105.0], [1.794629898E12, 107.0], [1.7946299E12, 104.0], [1.794629902E12, 90.0], [1.794629904E12, 99.0], [1.794629863E12, 20.0], [1.794629906E12, 102.0], [1.794629865E12, 49.0], [1.794629908E12, 96.0], [1.794629867E12, 66.0], [1.79462991E12, 89.0], [1.794629869E12, 89.0], [1.794629912E12, 89.0], [1.794629871E12, 103.0], [1.794629914E12, 101.0], [1.794629873E12, 108.0], [1.794629916E12, 105.0], [1.794629875E12, 101.0], [1.794629918E12, 97.0], [1.794629877E12, 101.0], [1.79462992E12, 44.0], [1.794629879E12, 107.0], [1.794629881E12, 102.0], [1.794629883E12, 92.0], [1.794629885E12, 102.0], [1.794629887E12, 99.0], [1.794629889E12, 101.0], [1.794629891E12, 97.0], [1.794629893E12, 107.0], [1.794629895E12, 95.0], [1.794629897E12, 98.0], [1.794629899E12, 87.0], [1.794629901E12, 100.0], [1.794629903E12, 106.0], [1.794629905E12, 104.0], [1.794629862E12, 4.0], [1.794629864E12, 32.0], [1.794629907E12, 97.0], [1.794629909E12, 95.0], [1.794629866E12, 53.0], [1.794629868E12, 73.0], [1.794629911E12, 95.0], [1.794629913E12, 96.0], [1.79462987E12, 90.0], [1.794629872E12, 92.0], [1.794629915E12, 99.0], [1.794629917E12, 108.0], [1.794629874E12, 94.0], [1.794629876E12, 103.0], [1.794629919E12, 95.0], [1.794629878E12, 102.0], [1.79462988E12, 96.0], [1.794629882E12, 86.0], [1.794629884E12, 82.0], [1.794629886E12, 105.0], [1.794629888E12, 99.0]], "isOverall": false, "label": "201", "isController": false}, {"data": [[1.794629912E12, 13.0], [1.794629884E12, 18.0]], "isOverall": false, "label": "Non HTTP response code: org.apache.http.conn.HttpHostConnectException", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.79462992E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 4.0, "minX": 1.794629862E12, "maxY": 108.0, "series": [{"data": [[1.794629912E12, 13.0], [1.794629884E12, 18.0]], "isOverall": false, "label": "SeleccionTarifaYCantidad-failure", "isController": false}, {"data": [[1.79462989E12, 104.0], [1.794629892E12, 97.0], [1.794629894E12, 98.0], [1.794629896E12, 105.0], [1.794629898E12, 107.0], [1.7946299E12, 104.0], [1.794629902E12, 90.0], [1.794629904E12, 99.0], [1.794629863E12, 20.0], [1.794629906E12, 102.0], [1.794629865E12, 49.0], [1.794629908E12, 96.0], [1.794629867E12, 66.0], [1.79462991E12, 89.0], [1.794629869E12, 89.0], [1.794629912E12, 89.0], [1.794629871E12, 103.0], [1.794629914E12, 101.0], [1.794629873E12, 108.0], [1.794629916E12, 105.0], [1.794629875E12, 101.0], [1.794629918E12, 97.0], [1.794629877E12, 101.0], [1.79462992E12, 44.0], [1.794629879E12, 107.0], [1.794629881E12, 102.0], [1.794629883E12, 92.0], [1.794629885E12, 102.0], [1.794629887E12, 99.0], [1.794629889E12, 101.0], [1.794629891E12, 97.0], [1.794629893E12, 107.0], [1.794629895E12, 95.0], [1.794629897E12, 98.0], [1.794629899E12, 87.0], [1.794629901E12, 100.0], [1.794629903E12, 106.0], [1.794629905E12, 104.0], [1.794629862E12, 4.0], [1.794629864E12, 32.0], [1.794629907E12, 97.0], [1.794629909E12, 95.0], [1.794629866E12, 53.0], [1.794629868E12, 73.0], [1.794629911E12, 95.0], [1.794629913E12, 96.0], [1.79462987E12, 90.0], [1.794629872E12, 92.0], [1.794629915E12, 99.0], [1.794629917E12, 108.0], [1.794629874E12, 94.0], [1.794629876E12, 103.0], [1.794629919E12, 95.0], [1.794629878E12, 102.0], [1.79462988E12, 96.0], [1.794629882E12, 86.0], [1.794629884E12, 82.0], [1.794629886E12, 105.0], [1.794629888E12, 99.0]], "isOverall": false, "label": "SeleccionTarifaYCantidad-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.79462992E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 4.0, "minX": 1.794629862E12, "maxY": 108.0, "series": [{"data": [[1.79462989E12, 104.0], [1.794629892E12, 97.0], [1.794629894E12, 98.0], [1.794629896E12, 105.0], [1.794629898E12, 107.0], [1.7946299E12, 104.0], [1.794629902E12, 90.0], [1.794629904E12, 99.0], [1.794629863E12, 20.0], [1.794629906E12, 102.0], [1.794629865E12, 49.0], [1.794629908E12, 96.0], [1.794629867E12, 66.0], [1.79462991E12, 89.0], [1.794629869E12, 89.0], [1.794629912E12, 89.0], [1.794629871E12, 103.0], [1.794629914E12, 101.0], [1.794629873E12, 108.0], [1.794629916E12, 105.0], [1.794629875E12, 101.0], [1.794629918E12, 97.0], [1.794629877E12, 101.0], [1.79462992E12, 44.0], [1.794629879E12, 107.0], [1.794629881E12, 102.0], [1.794629883E12, 92.0], [1.794629885E12, 102.0], [1.794629887E12, 99.0], [1.794629889E12, 101.0], [1.794629891E12, 97.0], [1.794629893E12, 107.0], [1.794629895E12, 95.0], [1.794629897E12, 98.0], [1.794629899E12, 87.0], [1.794629901E12, 100.0], [1.794629903E12, 106.0], [1.794629905E12, 104.0], [1.794629862E12, 4.0], [1.794629864E12, 32.0], [1.794629907E12, 97.0], [1.794629909E12, 95.0], [1.794629866E12, 53.0], [1.794629868E12, 73.0], [1.794629911E12, 95.0], [1.794629913E12, 96.0], [1.79462987E12, 90.0], [1.794629872E12, 92.0], [1.794629915E12, 99.0], [1.794629917E12, 108.0], [1.794629874E12, 94.0], [1.794629876E12, 103.0], [1.794629919E12, 95.0], [1.794629878E12, 102.0], [1.79462988E12, 96.0], [1.794629882E12, 86.0], [1.794629884E12, 82.0], [1.794629886E12, 105.0], [1.794629888E12, 99.0]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [[1.794629912E12, 13.0], [1.794629884E12, 18.0]], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.79462992E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

