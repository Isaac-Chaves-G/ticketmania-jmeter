/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 0.0, "minX": 0.0, "maxY": 347.0, "series": [{"data": [[0.0, 0.0], [0.1, 1.0], [0.2, 1.0], [0.3, 1.0], [0.4, 1.0], [0.5, 2.0], [0.6, 2.0], [0.7, 2.0], [0.8, 2.0], [0.9, 2.0], [1.0, 2.0], [1.1, 2.0], [1.2, 2.0], [1.3, 2.0], [1.4, 2.0], [1.5, 2.0], [1.6, 2.0], [1.7, 2.0], [1.8, 2.0], [1.9, 2.0], [2.0, 2.0], [2.1, 2.0], [2.2, 2.0], [2.3, 2.0], [2.4, 2.0], [2.5, 2.0], [2.6, 2.0], [2.7, 2.0], [2.8, 2.0], [2.9, 2.0], [3.0, 2.0], [3.1, 2.0], [3.2, 2.0], [3.3, 2.0], [3.4, 2.0], [3.5, 2.0], [3.6, 2.0], [3.7, 2.0], [3.8, 2.0], [3.9, 2.0], [4.0, 3.0], [4.1, 3.0], [4.2, 3.0], [4.3, 3.0], [4.4, 3.0], [4.5, 3.0], [4.6, 3.0], [4.7, 3.0], [4.8, 3.0], [4.9, 3.0], [5.0, 3.0], [5.1, 3.0], [5.2, 3.0], [5.3, 3.0], [5.4, 3.0], [5.5, 3.0], [5.6, 3.0], [5.7, 3.0], [5.8, 3.0], [5.9, 3.0], [6.0, 3.0], [6.1, 3.0], [6.2, 3.0], [6.3, 3.0], [6.4, 3.0], [6.5, 3.0], [6.6, 3.0], [6.7, 3.0], [6.8, 3.0], [6.9, 3.0], [7.0, 3.0], [7.1, 3.0], [7.2, 3.0], [7.3, 3.0], [7.4, 3.0], [7.5, 3.0], [7.6, 3.0], [7.7, 3.0], [7.8, 3.0], [7.9, 3.0], [8.0, 3.0], [8.1, 3.0], [8.2, 3.0], [8.3, 3.0], [8.4, 3.0], [8.5, 3.0], [8.6, 3.0], [8.7, 3.0], [8.8, 3.0], [8.9, 3.0], [9.0, 3.0], [9.1, 3.0], [9.2, 3.0], [9.3, 3.0], [9.4, 3.0], [9.5, 3.0], [9.6, 3.0], [9.7, 3.0], [9.8, 3.0], [9.9, 3.0], [10.0, 3.0], [10.1, 3.0], [10.2, 3.0], [10.3, 3.0], [10.4, 3.0], [10.5, 3.0], [10.6, 3.0], [10.7, 3.0], [10.8, 3.0], [10.9, 3.0], [11.0, 3.0], [11.1, 3.0], [11.2, 3.0], [11.3, 3.0], [11.4, 3.0], [11.5, 3.0], [11.6, 3.0], [11.7, 3.0], [11.8, 3.0], [11.9, 3.0], [12.0, 3.0], [12.1, 3.0], [12.2, 3.0], [12.3, 3.0], [12.4, 3.0], [12.5, 3.0], [12.6, 3.0], [12.7, 3.0], [12.8, 3.0], [12.9, 3.0], [13.0, 3.0], [13.1, 3.0], [13.2, 3.0], [13.3, 3.0], [13.4, 3.0], [13.5, 3.0], [13.6, 3.0], [13.7, 3.0], [13.8, 3.0], [13.9, 3.0], [14.0, 3.0], [14.1, 3.0], [14.2, 3.0], [14.3, 3.0], [14.4, 3.0], [14.5, 3.0], [14.6, 3.0], [14.7, 3.0], [14.8, 3.0], [14.9, 3.0], [15.0, 3.0], [15.1, 3.0], [15.2, 3.0], [15.3, 3.0], [15.4, 3.0], [15.5, 3.0], [15.6, 3.0], [15.7, 3.0], [15.8, 3.0], [15.9, 3.0], [16.0, 3.0], [16.1, 3.0], [16.2, 3.0], [16.3, 3.0], [16.4, 3.0], [16.5, 3.0], [16.6, 3.0], [16.7, 3.0], [16.8, 3.0], [16.9, 3.0], [17.0, 3.0], [17.1, 3.0], [17.2, 3.0], [17.3, 3.0], [17.4, 3.0], [17.5, 3.0], [17.6, 3.0], [17.7, 3.0], [17.8, 3.0], [17.9, 3.0], [18.0, 3.0], [18.1, 3.0], [18.2, 3.0], [18.3, 3.0], [18.4, 3.0], [18.5, 3.0], [18.6, 3.0], [18.7, 3.0], [18.8, 3.0], [18.9, 3.0], [19.0, 3.0], [19.1, 3.0], [19.2, 3.0], [19.3, 4.0], [19.4, 4.0], [19.5, 4.0], [19.6, 4.0], [19.7, 4.0], [19.8, 4.0], [19.9, 4.0], [20.0, 4.0], [20.1, 4.0], [20.2, 4.0], [20.3, 4.0], [20.4, 4.0], [20.5, 4.0], [20.6, 4.0], [20.7, 4.0], [20.8, 4.0], [20.9, 4.0], [21.0, 4.0], [21.1, 4.0], [21.2, 4.0], [21.3, 4.0], [21.4, 4.0], [21.5, 4.0], [21.6, 4.0], [21.7, 4.0], [21.8, 4.0], [21.9, 4.0], [22.0, 4.0], [22.1, 4.0], [22.2, 4.0], [22.3, 4.0], [22.4, 4.0], [22.5, 4.0], [22.6, 4.0], [22.7, 4.0], [22.8, 4.0], [22.9, 4.0], [23.0, 4.0], [23.1, 4.0], [23.2, 4.0], [23.3, 4.0], [23.4, 4.0], [23.5, 4.0], [23.6, 4.0], [23.7, 4.0], [23.8, 4.0], [23.9, 4.0], [24.0, 4.0], [24.1, 4.0], [24.2, 4.0], [24.3, 4.0], [24.4, 4.0], [24.5, 4.0], [24.6, 4.0], [24.7, 4.0], [24.8, 4.0], [24.9, 4.0], [25.0, 4.0], [25.1, 4.0], [25.2, 4.0], [25.3, 4.0], [25.4, 4.0], [25.5, 4.0], [25.6, 4.0], [25.7, 4.0], [25.8, 4.0], [25.9, 4.0], [26.0, 4.0], [26.1, 4.0], [26.2, 4.0], [26.3, 4.0], [26.4, 4.0], [26.5, 4.0], [26.6, 4.0], [26.7, 4.0], [26.8, 4.0], [26.9, 4.0], [27.0, 4.0], [27.1, 4.0], [27.2, 4.0], [27.3, 4.0], [27.4, 4.0], [27.5, 4.0], [27.6, 4.0], [27.7, 4.0], [27.8, 4.0], [27.9, 4.0], [28.0, 4.0], [28.1, 4.0], [28.2, 4.0], [28.3, 4.0], [28.4, 4.0], [28.5, 4.0], [28.6, 4.0], [28.7, 4.0], [28.8, 4.0], [28.9, 4.0], [29.0, 4.0], [29.1, 4.0], [29.2, 4.0], [29.3, 4.0], [29.4, 4.0], [29.5, 4.0], [29.6, 4.0], [29.7, 4.0], [29.8, 4.0], [29.9, 4.0], [30.0, 4.0], [30.1, 4.0], [30.2, 4.0], [30.3, 4.0], [30.4, 4.0], [30.5, 4.0], [30.6, 4.0], [30.7, 4.0], [30.8, 4.0], [30.9, 4.0], [31.0, 4.0], [31.1, 4.0], [31.2, 4.0], [31.3, 4.0], [31.4, 4.0], [31.5, 4.0], [31.6, 4.0], [31.7, 4.0], [31.8, 4.0], [31.9, 4.0], [32.0, 4.0], [32.1, 4.0], [32.2, 4.0], [32.3, 4.0], [32.4, 4.0], [32.5, 4.0], [32.6, 4.0], [32.7, 4.0], [32.8, 4.0], [32.9, 4.0], [33.0, 4.0], [33.1, 4.0], [33.2, 4.0], [33.3, 4.0], [33.4, 4.0], [33.5, 4.0], [33.6, 4.0], [33.7, 4.0], [33.8, 4.0], [33.9, 4.0], [34.0, 4.0], [34.1, 4.0], [34.2, 4.0], [34.3, 4.0], [34.4, 4.0], [34.5, 4.0], [34.6, 4.0], [34.7, 4.0], [34.8, 4.0], [34.9, 4.0], [35.0, 4.0], [35.1, 4.0], [35.2, 4.0], [35.3, 4.0], [35.4, 4.0], [35.5, 4.0], [35.6, 4.0], [35.7, 4.0], [35.8, 4.0], [35.9, 4.0], [36.0, 4.0], [36.1, 4.0], [36.2, 4.0], [36.3, 4.0], [36.4, 4.0], [36.5, 4.0], [36.6, 4.0], [36.7, 4.0], [36.8, 4.0], [36.9, 4.0], [37.0, 4.0], [37.1, 4.0], [37.2, 4.0], [37.3, 4.0], [37.4, 4.0], [37.5, 4.0], [37.6, 4.0], [37.7, 4.0], [37.8, 4.0], [37.9, 4.0], [38.0, 4.0], [38.1, 4.0], [38.2, 4.0], [38.3, 4.0], [38.4, 4.0], [38.5, 4.0], [38.6, 4.0], [38.7, 4.0], [38.8, 4.0], [38.9, 4.0], [39.0, 4.0], [39.1, 4.0], [39.2, 4.0], [39.3, 4.0], [39.4, 4.0], [39.5, 4.0], [39.6, 4.0], [39.7, 4.0], [39.8, 4.0], [39.9, 4.0], [40.0, 4.0], [40.1, 4.0], [40.2, 4.0], [40.3, 4.0], [40.4, 4.0], [40.5, 4.0], [40.6, 4.0], [40.7, 4.0], [40.8, 4.0], [40.9, 4.0], [41.0, 4.0], [41.1, 4.0], [41.2, 4.0], [41.3, 4.0], [41.4, 4.0], [41.5, 4.0], [41.6, 4.0], [41.7, 4.0], [41.8, 4.0], [41.9, 4.0], [42.0, 4.0], [42.1, 4.0], [42.2, 4.0], [42.3, 5.0], [42.4, 5.0], [42.5, 5.0], [42.6, 5.0], [42.7, 5.0], [42.8, 5.0], [42.9, 5.0], [43.0, 5.0], [43.1, 5.0], [43.2, 5.0], [43.3, 5.0], [43.4, 5.0], [43.5, 5.0], [43.6, 5.0], [43.7, 5.0], [43.8, 5.0], [43.9, 5.0], [44.0, 5.0], [44.1, 5.0], [44.2, 5.0], [44.3, 5.0], [44.4, 5.0], [44.5, 5.0], [44.6, 5.0], [44.7, 5.0], [44.8, 5.0], [44.9, 5.0], [45.0, 5.0], [45.1, 5.0], [45.2, 5.0], [45.3, 5.0], [45.4, 5.0], [45.5, 5.0], [45.6, 5.0], [45.7, 5.0], [45.8, 5.0], [45.9, 5.0], [46.0, 5.0], [46.1, 5.0], [46.2, 5.0], [46.3, 5.0], [46.4, 5.0], [46.5, 5.0], [46.6, 5.0], [46.7, 5.0], [46.8, 5.0], [46.9, 5.0], [47.0, 5.0], [47.1, 5.0], [47.2, 5.0], [47.3, 5.0], [47.4, 5.0], [47.5, 5.0], [47.6, 5.0], [47.7, 5.0], [47.8, 5.0], [47.9, 5.0], [48.0, 5.0], [48.1, 5.0], [48.2, 5.0], [48.3, 5.0], [48.4, 5.0], [48.5, 5.0], [48.6, 5.0], [48.7, 5.0], [48.8, 5.0], [48.9, 5.0], [49.0, 5.0], [49.1, 5.0], [49.2, 5.0], [49.3, 5.0], [49.4, 5.0], [49.5, 5.0], [49.6, 5.0], [49.7, 5.0], [49.8, 5.0], [49.9, 5.0], [50.0, 5.0], [50.1, 5.0], [50.2, 5.0], [50.3, 5.0], [50.4, 5.0], [50.5, 5.0], [50.6, 5.0], [50.7, 5.0], [50.8, 5.0], [50.9, 5.0], [51.0, 5.0], [51.1, 5.0], [51.2, 5.0], [51.3, 5.0], [51.4, 5.0], [51.5, 5.0], [51.6, 5.0], [51.7, 5.0], [51.8, 5.0], [51.9, 5.0], [52.0, 5.0], [52.1, 5.0], [52.2, 5.0], [52.3, 5.0], [52.4, 5.0], [52.5, 5.0], [52.6, 5.0], [52.7, 5.0], [52.8, 5.0], [52.9, 5.0], [53.0, 5.0], [53.1, 5.0], [53.2, 5.0], [53.3, 5.0], [53.4, 5.0], [53.5, 5.0], [53.6, 5.0], [53.7, 5.0], [53.8, 5.0], [53.9, 5.0], [54.0, 5.0], [54.1, 5.0], [54.2, 5.0], [54.3, 5.0], [54.4, 5.0], [54.5, 5.0], [54.6, 5.0], [54.7, 5.0], [54.8, 5.0], [54.9, 5.0], [55.0, 5.0], [55.1, 5.0], [55.2, 5.0], [55.3, 5.0], [55.4, 5.0], [55.5, 5.0], [55.6, 5.0], [55.7, 5.0], [55.8, 5.0], [55.9, 5.0], [56.0, 5.0], [56.1, 5.0], [56.2, 5.0], [56.3, 5.0], [56.4, 5.0], [56.5, 5.0], [56.6, 5.0], [56.7, 5.0], [56.8, 5.0], [56.9, 5.0], [57.0, 5.0], [57.1, 5.0], [57.2, 5.0], [57.3, 5.0], [57.4, 5.0], [57.5, 5.0], [57.6, 5.0], [57.7, 5.0], [57.8, 5.0], [57.9, 5.0], [58.0, 5.0], [58.1, 5.0], [58.2, 5.0], [58.3, 5.0], [58.4, 5.0], [58.5, 5.0], [58.6, 5.0], [58.7, 5.0], [58.8, 5.0], [58.9, 5.0], [59.0, 5.0], [59.1, 5.0], [59.2, 5.0], [59.3, 5.0], [59.4, 5.0], [59.5, 5.0], [59.6, 5.0], [59.7, 5.0], [59.8, 5.0], [59.9, 5.0], [60.0, 5.0], [60.1, 5.0], [60.2, 5.0], [60.3, 5.0], [60.4, 5.0], [60.5, 5.0], [60.6, 5.0], [60.7, 5.0], [60.8, 5.0], [60.9, 5.0], [61.0, 5.0], [61.1, 5.0], [61.2, 5.0], [61.3, 5.0], [61.4, 5.0], [61.5, 6.0], [61.6, 6.0], [61.7, 6.0], [61.8, 6.0], [61.9, 6.0], [62.0, 6.0], [62.1, 6.0], [62.2, 6.0], [62.3, 6.0], [62.4, 6.0], [62.5, 6.0], [62.6, 6.0], [62.7, 6.0], [62.8, 6.0], [62.9, 6.0], [63.0, 6.0], [63.1, 6.0], [63.2, 6.0], [63.3, 6.0], [63.4, 6.0], [63.5, 6.0], [63.6, 6.0], [63.7, 6.0], [63.8, 6.0], [63.9, 6.0], [64.0, 6.0], [64.1, 6.0], [64.2, 6.0], [64.3, 6.0], [64.4, 6.0], [64.5, 6.0], [64.6, 6.0], [64.7, 6.0], [64.8, 6.0], [64.9, 6.0], [65.0, 6.0], [65.1, 6.0], [65.2, 6.0], [65.3, 6.0], [65.4, 6.0], [65.5, 6.0], [65.6, 6.0], [65.7, 6.0], [65.8, 6.0], [65.9, 6.0], [66.0, 6.0], [66.1, 6.0], [66.2, 6.0], [66.3, 6.0], [66.4, 6.0], [66.5, 6.0], [66.6, 6.0], [66.7, 6.0], [66.8, 6.0], [66.9, 6.0], [67.0, 6.0], [67.1, 6.0], [67.2, 6.0], [67.3, 6.0], [67.4, 6.0], [67.5, 6.0], [67.6, 6.0], [67.7, 6.0], [67.8, 6.0], [67.9, 6.0], [68.0, 6.0], [68.1, 6.0], [68.2, 6.0], [68.3, 6.0], [68.4, 6.0], [68.5, 6.0], [68.6, 6.0], [68.7, 6.0], [68.8, 6.0], [68.9, 6.0], [69.0, 6.0], [69.1, 6.0], [69.2, 6.0], [69.3, 6.0], [69.4, 6.0], [69.5, 6.0], [69.6, 6.0], [69.7, 6.0], [69.8, 6.0], [69.9, 6.0], [70.0, 6.0], [70.1, 6.0], [70.2, 6.0], [70.3, 6.0], [70.4, 6.0], [70.5, 6.0], [70.6, 6.0], [70.7, 6.0], [70.8, 6.0], [70.9, 6.0], [71.0, 6.0], [71.1, 6.0], [71.2, 6.0], [71.3, 6.0], [71.4, 6.0], [71.5, 6.0], [71.6, 6.0], [71.7, 6.0], [71.8, 6.0], [71.9, 6.0], [72.0, 6.0], [72.1, 6.0], [72.2, 6.0], [72.3, 6.0], [72.4, 6.0], [72.5, 6.0], [72.6, 6.0], [72.7, 6.0], [72.8, 6.0], [72.9, 6.0], [73.0, 6.0], [73.1, 6.0], [73.2, 6.0], [73.3, 6.0], [73.4, 6.0], [73.5, 6.0], [73.6, 6.0], [73.7, 6.0], [73.8, 6.0], [73.9, 6.0], [74.0, 6.0], [74.1, 6.0], [74.2, 6.0], [74.3, 6.0], [74.4, 6.0], [74.5, 6.0], [74.6, 6.0], [74.7, 6.0], [74.8, 6.0], [74.9, 6.0], [75.0, 6.0], [75.1, 6.0], [75.2, 6.0], [75.3, 6.0], [75.4, 6.0], [75.5, 6.0], [75.6, 6.0], [75.7, 6.0], [75.8, 6.0], [75.9, 6.0], [76.0, 7.0], [76.1, 7.0], [76.2, 7.0], [76.3, 7.0], [76.4, 7.0], [76.5, 7.0], [76.6, 7.0], [76.7, 7.0], [76.8, 7.0], [76.9, 7.0], [77.0, 7.0], [77.1, 7.0], [77.2, 7.0], [77.3, 7.0], [77.4, 7.0], [77.5, 7.0], [77.6, 7.0], [77.7, 7.0], [77.8, 7.0], [77.9, 7.0], [78.0, 7.0], [78.1, 7.0], [78.2, 7.0], [78.3, 7.0], [78.4, 7.0], [78.5, 7.0], [78.6, 7.0], [78.7, 7.0], [78.8, 7.0], [78.9, 7.0], [79.0, 7.0], [79.1, 7.0], [79.2, 7.0], [79.3, 7.0], [79.4, 7.0], [79.5, 7.0], [79.6, 7.0], [79.7, 7.0], [79.8, 7.0], [79.9, 7.0], [80.0, 7.0], [80.1, 7.0], [80.2, 7.0], [80.3, 7.0], [80.4, 7.0], [80.5, 7.0], [80.6, 7.0], [80.7, 7.0], [80.8, 7.0], [80.9, 7.0], [81.0, 7.0], [81.1, 7.0], [81.2, 7.0], [81.3, 7.0], [81.4, 7.0], [81.5, 7.0], [81.6, 7.0], [81.7, 7.0], [81.8, 7.0], [81.9, 7.0], [82.0, 7.0], [82.1, 7.0], [82.2, 7.0], [82.3, 7.0], [82.4, 7.0], [82.5, 7.0], [82.6, 7.0], [82.7, 7.0], [82.8, 7.0], [82.9, 7.0], [83.0, 7.0], [83.1, 7.0], [83.2, 7.0], [83.3, 7.0], [83.4, 7.0], [83.5, 7.0], [83.6, 7.0], [83.7, 7.0], [83.8, 7.0], [83.9, 7.0], [84.0, 7.0], [84.1, 7.0], [84.2, 7.0], [84.3, 7.0], [84.4, 7.0], [84.5, 7.0], [84.6, 7.0], [84.7, 8.0], [84.8, 8.0], [84.9, 8.0], [85.0, 8.0], [85.1, 8.0], [85.2, 8.0], [85.3, 8.0], [85.4, 8.0], [85.5, 8.0], [85.6, 8.0], [85.7, 8.0], [85.8, 8.0], [85.9, 8.0], [86.0, 8.0], [86.1, 8.0], [86.2, 8.0], [86.3, 8.0], [86.4, 8.0], [86.5, 8.0], [86.6, 8.0], [86.7, 8.0], [86.8, 8.0], [86.9, 8.0], [87.0, 8.0], [87.1, 8.0], [87.2, 8.0], [87.3, 8.0], [87.4, 8.0], [87.5, 8.0], [87.6, 8.0], [87.7, 8.0], [87.8, 8.0], [87.9, 8.0], [88.0, 8.0], [88.1, 8.0], [88.2, 8.0], [88.3, 8.0], [88.4, 8.0], [88.5, 8.0], [88.6, 8.0], [88.7, 8.0], [88.8, 8.0], [88.9, 8.0], [89.0, 8.0], [89.1, 8.0], [89.2, 8.0], [89.3, 8.0], [89.4, 8.0], [89.5, 8.0], [89.6, 8.0], [89.7, 8.0], [89.8, 8.0], [89.9, 8.0], [90.0, 8.0], [90.1, 8.0], [90.2, 8.0], [90.3, 8.0], [90.4, 8.0], [90.5, 8.0], [90.6, 8.0], [90.7, 8.0], [90.8, 9.0], [90.9, 9.0], [91.0, 9.0], [91.1, 9.0], [91.2, 9.0], [91.3, 9.0], [91.4, 9.0], [91.5, 9.0], [91.6, 9.0], [91.7, 9.0], [91.8, 9.0], [91.9, 9.0], [92.0, 9.0], [92.1, 9.0], [92.2, 9.0], [92.3, 9.0], [92.4, 9.0], [92.5, 9.0], [92.6, 9.0], [92.7, 9.0], [92.8, 9.0], [92.9, 9.0], [93.0, 9.0], [93.1, 9.0], [93.2, 9.0], [93.3, 9.0], [93.4, 9.0], [93.5, 9.0], [93.6, 9.0], [93.7, 9.0], [93.8, 10.0], [93.9, 10.0], [94.0, 10.0], [94.1, 10.0], [94.2, 10.0], [94.3, 10.0], [94.4, 10.0], [94.5, 10.0], [94.6, 10.0], [94.7, 10.0], [94.8, 10.0], [94.9, 10.0], [95.0, 10.0], [95.1, 10.0], [95.2, 10.0], [95.3, 10.0], [95.4, 10.0], [95.5, 10.0], [95.6, 10.0], [95.7, 11.0], [95.8, 11.0], [95.9, 11.0], [96.0, 11.0], [96.1, 11.0], [96.2, 11.0], [96.3, 11.0], [96.4, 11.0], [96.5, 11.0], [96.6, 11.0], [96.7, 11.0], [96.8, 11.0], [96.9, 11.0], [97.0, 12.0], [97.1, 12.0], [97.2, 12.0], [97.3, 12.0], [97.4, 12.0], [97.5, 12.0], [97.6, 12.0], [97.7, 12.0], [97.8, 13.0], [97.9, 13.0], [98.0, 13.0], [98.1, 13.0], [98.2, 13.0], [98.3, 14.0], [98.4, 14.0], [98.5, 14.0], [98.6, 15.0], [98.7, 15.0], [98.8, 17.0], [98.9, 19.0], [99.0, 24.0], [99.1, 28.0], [99.2, 36.0], [99.3, 56.0], [99.4, 66.0], [99.5, 78.0], [99.6, 107.0], [99.7, 122.0], [99.8, 135.0], [99.9, 223.0], [100.0, 347.0]], "isOverall": false, "label": "Tarifas", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 3.0, "minX": 0.0, "maxY": 5304.0, "series": [{"data": [[0.0, 5304.0], [300.0, 3.0], [200.0, 3.0], [100.0, 17.0]], "isOverall": false, "label": "Tarifas", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 300.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 49.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1.500ms"], [2, "Requests having \nresponse time > 1.500ms"], [3, "Requests in error"]], "maxY": 5278.0, "series": [{"data": [[0.0, 5278.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1.500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1.500ms", "isController": false}, {"data": [[3.0, 49.0]], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 37.61764705882353, "minX": 1.794666344E12, "maxY": 100.0, "series": [{"data": [[1.794666391E12, 100.0], [1.794666348E12, 77.11538461538461], [1.794666352E12, 100.0], [1.79466635E12, 96.86206896551725], [1.794666393E12, 100.0], [1.794666354E12, 100.0], [1.794666397E12, 100.0], [1.794666395E12, 100.0], [1.794666399E12, 95.16831683168317], [1.794666356E12, 100.0], [1.79466636E12, 100.0], [1.794666358E12, 100.0], [1.794666362E12, 100.0], [1.794666364E12, 100.0], [1.794666368E12, 100.0], [1.794666366E12, 100.0], [1.794666369E12, 100.0], [1.794666373E12, 100.0], [1.794666371E12, 100.0], [1.794666375E12, 100.0], [1.794666377E12, 100.0], [1.794666381E12, 100.0], [1.794666379E12, 100.0], [1.794666383E12, 100.0], [1.794666344E12, 37.61764705882353], [1.794666385E12, 100.0], [1.794666346E12, 57.56249999999999], [1.794666389E12, 100.0], [1.794666387E12, 100.0], [1.794666349E12, 87.49315068493149], [1.794666392E12, 100.0], [1.794666347E12, 67.16363636363636], [1.79466639E12, 100.0], [1.794666351E12, 100.0], [1.794666394E12, 100.0], [1.794666353E12, 100.0], [1.794666396E12, 100.0], [1.794666357E12, 100.0], [1.7946664E12, 43.37931034482758], [1.794666355E12, 100.0], [1.794666398E12, 100.0], [1.794666359E12, 100.0], [1.794666361E12, 100.0], [1.794666365E12, 100.0], [1.794666363E12, 100.0], [1.794666367E12, 100.0], [1.79466637E12, 100.0], [1.794666372E12, 100.0], [1.794666376E12, 100.0], [1.794666374E12, 100.0], [1.794666378E12, 100.0], [1.79466638E12, 100.0], [1.794666384E12, 100.0], [1.794666382E12, 100.0], [1.794666386E12, 100.0], [1.794666345E12, 48.60975609756097], [1.794666388E12, 100.0]], "isOverall": false, "label": "Usuarios parametrizados - experimentacion", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.7946664E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 3.0, "minX": 1.0, "maxY": 157.99999999999997, "series": [{"data": [[2.0, 3.0], [3.0, 4.0], [5.0, 4.5], [6.0, 11.0], [8.0, 9.0], [9.0, 7.0], [10.0, 6.0], [12.0, 7.5], [14.0, 6.5], [16.0, 5.5], [18.0, 4.0], [19.0, 4.0], [20.0, 4.0], [22.0, 12.0], [23.0, 9.0], [24.0, 6.0], [25.0, 4.0], [26.0, 8.0], [27.0, 5.0], [28.0, 5.0], [30.0, 7.0], [31.0, 6.0], [32.0, 6.0], [35.0, 157.99999999999997], [34.0, 5.5], [36.0, 100.09090909090911], [37.0, 5.25], [38.0, 5.0], [39.0, 6.0], [40.0, 6.124999999999999], [41.0, 5.666666666666667], [42.0, 5.666666666666667], [43.0, 4.0], [44.0, 4.0], [45.0, 4.0], [46.0, 5.142857142857142], [47.0, 6.428571428571428], [48.0, 6.285714285714286], [49.0, 5.666666666666667], [50.0, 5.25], [51.0, 7.875], [52.0, 5.8], [53.0, 6.2], [54.0, 4.8], [55.0, 4.666666666666667], [56.0, 4.4], [57.0, 7.0], [58.0, 5.0], [59.0, 4.75], [60.0, 6.444444444444445], [61.0, 5.222222222222222], [62.0, 5.0], [63.0, 4.8], [64.0, 7.428571428571429], [65.0, 6.181818181818182], [66.0, 6.333333333333333], [67.0, 4.833333333333333], [68.0, 5.0], [69.0, 15.545454545454545], [70.0, 5.0], [71.0, 4.571428571428571], [72.0, 4.285714285714286], [73.0, 4.666666666666666], [74.0, 5.555555555555556], [75.0, 6.333333333333333], [76.0, 5.6], [77.0, 6.0], [78.0, 5.666666666666667], [79.0, 6.384615384615384], [80.0, 5.555555555555555], [81.0, 9.375000000000002], [82.0, 4.846153846153846], [83.0, 7.333333333333332], [84.0, 3.8749999999999996], [85.0, 4.124999999999999], [86.0, 3.9999999999999996], [87.0, 4.888888888888889], [88.0, 4.3125], [89.0, 3.75], [90.0, 4.363636363636363], [91.0, 4.111111111111111], [92.0, 5.888888888888889], [93.0, 5.533333333333332], [94.0, 5.888888888888889], [95.0, 4.846153846153846], [96.0, 5.2666666666666675], [97.0, 4.461538461538462], [98.0, 8.0], [99.0, 7.555555555555557], [100.0, 5.915328467153284], [1.0, 4.0]], "isOverall": false, "label": "Tarifas", "isController": false}, {"data": [[96.91083161253971, 6.295288154683668]], "isOverall": false, "label": "Tarifas-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 3584.0, "minX": 1.794666344E12, "maxY": 85523.0, "series": [{"data": [[1.794666391E12, 49088.0], [1.794666348E12, 36816.0], [1.794666352E12, 43896.0], [1.79466635E12, 41064.0], [1.794666393E12, 45312.0], [1.794666354E12, 47672.0], [1.794666397E12, 51920.0], [1.794666395E12, 44840.0], [1.794666399E12, 47672.0], [1.794666356E12, 47200.0], [1.79466636E12, 85523.0], [1.794666358E12, 46256.0], [1.794666362E12, 50315.0], [1.794666364E12, 45312.0], [1.794666368E12, 45784.0], [1.794666366E12, 48616.0], [1.794666369E12, 42952.0], [1.794666373E12, 46728.0], [1.794666371E12, 46728.0], [1.794666375E12, 44840.0], [1.794666377E12, 45312.0], [1.794666381E12, 48144.0], [1.794666379E12, 63341.0], [1.794666383E12, 43424.0], [1.794666344E12, 29074.0], [1.794666385E12, 48616.0], [1.794666346E12, 22656.0], [1.794666389E12, 47200.0], [1.794666387E12, 43424.0], [1.794666349E12, 34456.0], [1.794666392E12, 49560.0], [1.794666347E12, 25960.0], [1.79466639E12, 46256.0], [1.794666351E12, 49560.0], [1.794666394E12, 45784.0], [1.794666353E12, 50504.0], [1.794666396E12, 44368.0], [1.794666357E12, 45312.0], [1.7946664E12, 41064.0], [1.794666355E12, 44840.0], [1.794666398E12, 45312.0], [1.794666359E12, 44840.0], [1.794666361E12, 58149.0], [1.794666365E12, 44368.0], [1.794666363E12, 47672.0], [1.794666367E12, 64851.0], [1.79466637E12, 47483.0], [1.794666372E12, 50504.0], [1.794666376E12, 49560.0], [1.794666374E12, 48616.0], [1.794666378E12, 47483.0], [1.79466638E12, 42480.0], [1.794666384E12, 43896.0], [1.794666382E12, 48144.0], [1.794666386E12, 42952.0], [1.794666345E12, 19352.0], [1.794666388E12, 47672.0]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.794666391E12, 13312.0], [1.794666348E12, 9984.0], [1.794666352E12, 11904.0], [1.79466635E12, 11136.0], [1.794666393E12, 12288.0], [1.794666354E12, 12928.0], [1.794666397E12, 14080.0], [1.794666395E12, 12160.0], [1.794666399E12, 12928.0], [1.794666356E12, 12800.0], [1.79466636E12, 11008.0], [1.794666358E12, 12544.0], [1.794666362E12, 12928.0], [1.794666364E12, 12288.0], [1.794666368E12, 12416.0], [1.794666366E12, 13184.0], [1.794666369E12, 11648.0], [1.794666373E12, 12672.0], [1.794666371E12, 12672.0], [1.794666375E12, 12160.0], [1.794666377E12, 12288.0], [1.794666381E12, 13056.0], [1.794666379E12, 12160.0], [1.794666383E12, 11776.0], [1.794666344E12, 3584.0], [1.794666385E12, 13184.0], [1.794666346E12, 6144.0], [1.794666389E12, 12800.0], [1.794666387E12, 11776.0], [1.794666349E12, 9344.0], [1.794666392E12, 13440.0], [1.794666347E12, 7040.0], [1.79466639E12, 12544.0], [1.794666351E12, 13440.0], [1.794666394E12, 12416.0], [1.794666353E12, 13696.0], [1.794666396E12, 12032.0], [1.794666357E12, 12288.0], [1.7946664E12, 11136.0], [1.794666355E12, 12160.0], [1.794666398E12, 12288.0], [1.794666359E12, 12160.0], [1.794666361E12, 10752.0], [1.794666365E12, 12032.0], [1.794666363E12, 12928.0], [1.794666367E12, 11136.0], [1.79466637E12, 12160.0], [1.794666372E12, 13696.0], [1.794666376E12, 13440.0], [1.794666374E12, 13184.0], [1.794666378E12, 12160.0], [1.79466638E12, 11520.0], [1.794666384E12, 11904.0], [1.794666382E12, 13056.0], [1.794666386E12, 11648.0], [1.794666345E12, 5248.0], [1.794666388E12, 12928.0]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.7946664E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 4.178947368421049, "minX": 1.794666344E12, "maxY": 67.64705882352942, "series": [{"data": [[1.794666391E12, 5.249999999999998], [1.794666348E12, 6.08974358974359], [1.794666352E12, 5.440860215053762], [1.79466635E12, 6.057471264367815], [1.794666393E12, 4.510416666666668], [1.794666354E12, 6.000000000000002], [1.794666397E12, 5.645454545454544], [1.794666395E12, 5.8210526315789455], [1.794666399E12, 4.2871287128712865], [1.794666356E12, 5.000000000000001], [1.79466636E12, 12.912621359223305], [1.794666358E12, 4.357142857142856], [1.794666362E12, 5.078431372549019], [1.794666364E12, 5.541666666666666], [1.794666368E12, 5.536082474226805], [1.794666366E12, 4.8446601941747565], [1.794666369E12, 5.2747252747252755], [1.794666373E12, 5.585858585858585], [1.794666371E12, 4.979797979797981], [1.794666375E12, 5.5473684210526315], [1.794666377E12, 5.520833333333336], [1.794666381E12, 5.1470588235294095], [1.794666379E12, 11.725490196078429], [1.794666383E12, 5.108695652173913], [1.794666344E12, 67.64705882352942], [1.794666385E12, 6.194174757281555], [1.794666346E12, 5.791666666666666], [1.794666389E12, 5.03], [1.794666387E12, 5.065217391304349], [1.794666349E12, 4.931506849315067], [1.794666392E12, 4.838095238095235], [1.794666347E12, 7.6363636363636385], [1.79466639E12, 4.693877551020408], [1.794666351E12, 6.466666666666666], [1.794666394E12, 6.030927835051547], [1.794666353E12, 6.046728971962616], [1.794666396E12, 5.063829787234043], [1.794666357E12, 5.281250000000002], [1.7946664E12, 5.402298850574715], [1.794666355E12, 4.621052631578947], [1.794666398E12, 5.041666666666665], [1.794666359E12, 4.178947368421049], [1.794666361E12, 14.142857142857148], [1.794666365E12, 5.148936170212766], [1.794666363E12, 5.00990099009901], [1.794666367E12, 13.812499999999998], [1.79466637E12, 5.270833333333335], [1.794666372E12, 5.327102803738319], [1.794666376E12, 5.295238095238096], [1.794666374E12, 5.92233009708738], [1.794666378E12, 5.322916666666666], [1.79466638E12, 4.72222222222222], [1.794666384E12, 5.60215053763441], [1.794666382E12, 5.431372549019608], [1.794666386E12, 5.285714285714288], [1.794666345E12, 6.219512195121952], [1.794666388E12, 5.039603960396041]], "isOverall": false, "label": "Tarifas", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.7946664E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 4.000000000000002, "minX": 1.794666344E12, "maxY": 57.23529411764706, "series": [{"data": [[1.794666391E12, 5.0480769230769225], [1.794666348E12, 5.653846153846154], [1.794666352E12, 5.107526881720431], [1.79466635E12, 5.586206896551724], [1.794666393E12, 4.208333333333334], [1.794666354E12, 5.6138613861386135], [1.794666397E12, 5.381818181818184], [1.794666395E12, 5.43157894736842], [1.794666399E12, 4.069306930693069], [1.794666356E12, 4.74], [1.79466636E12, 12.25242718446602], [1.794666358E12, 4.1020408163265305], [1.794666362E12, 4.784313725490197], [1.794666364E12, 5.281249999999998], [1.794666368E12, 5.2577319587628875], [1.794666366E12, 4.6116504854368925], [1.794666369E12, 4.978021978021976], [1.794666373E12, 5.323232323232323], [1.794666371E12, 4.777777777777776], [1.794666375E12, 5.284210526315792], [1.794666377E12, 5.218749999999998], [1.794666381E12, 4.81372549019608], [1.794666379E12, 11.284313725490197], [1.794666383E12, 4.858695652173912], [1.794666344E12, 57.23529411764706], [1.794666385E12, 5.805825242718448], [1.794666346E12, 5.166666666666664], [1.794666389E12, 4.769999999999998], [1.794666387E12, 4.684782608695652], [1.794666349E12, 4.575342465753423], [1.794666392E12, 4.533333333333332], [1.794666347E12, 7.036363636363637], [1.79466639E12, 4.418367346938777], [1.794666351E12, 6.133333333333331], [1.794666394E12, 5.639175257731959], [1.794666353E12, 5.728971962616821], [1.794666396E12, 4.744680851063832], [1.794666357E12, 5.010416666666667], [1.7946664E12, 5.137931034482761], [1.794666355E12, 4.400000000000002], [1.794666398E12, 4.833333333333332], [1.794666359E12, 4.000000000000002], [1.794666361E12, 13.483516483516487], [1.794666365E12, 4.904255319148935], [1.794666363E12, 4.752475247524756], [1.794666367E12, 12.77083333333333], [1.79466637E12, 5.093750000000001], [1.794666372E12, 5.093457943925233], [1.794666376E12, 4.999999999999997], [1.794666374E12, 5.650485436893201], [1.794666378E12, 5.041666666666667], [1.79466638E12, 4.388888888888889], [1.794666384E12, 5.193548387096774], [1.794666382E12, 5.127450980392156], [1.794666386E12, 5.021978021978023], [1.794666345E12, 5.53658536585366], [1.794666388E12, 4.742574257425743]], "isOverall": false, "label": "Tarifas", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.7946664E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 1.3571428571428574, "minX": 1.794666344E12, "maxY": 44.05882352941177, "series": [{"data": [[1.794666391E12, 1.7692307692307694], [1.794666348E12, 2.397435897435898], [1.794666352E12, 2.1290322580645165], [1.79466635E12, 2.3908045977011496], [1.794666393E12, 1.7083333333333321], [1.794666354E12, 2.059405940594058], [1.794666397E12, 1.9999999999999998], [1.794666395E12, 2.0736842105263156], [1.794666399E12, 1.6831683168316838], [1.794666356E12, 1.6099999999999999], [1.79466636E12, 2.067961165048543], [1.794666358E12, 1.3571428571428574], [1.794666362E12, 1.7941176470588238], [1.794666364E12, 1.8124999999999998], [1.794666368E12, 1.845360824742268], [1.794666366E12, 1.660194174757282], [1.794666369E12, 1.8901098901098896], [1.794666373E12, 1.7171717171717173], [1.794666371E12, 1.7171717171717167], [1.794666375E12, 1.9052631578947368], [1.794666377E12, 2.0], [1.794666381E12, 1.7941176470588234], [1.794666379E12, 1.9411764705882353], [1.794666383E12, 1.815217391304348], [1.794666344E12, 44.05882352941177], [1.794666385E12, 2.174757281553398], [1.794666346E12, 2.229166666666667], [1.794666389E12, 1.6900000000000004], [1.794666387E12, 1.923913043478261], [1.794666349E12, 2.205479452054794], [1.794666392E12, 1.7714285714285714], [1.794666347E12, 3.2545454545454553], [1.79466639E12, 1.826530612244898], [1.794666351E12, 2.2952380952380946], [1.794666394E12, 2.0206185567010304], [1.794666353E12, 2.158878504672897], [1.794666396E12, 1.7127659574468086], [1.794666357E12, 1.8333333333333333], [1.7946664E12, 2.0574712643678152], [1.794666355E12, 1.6842105263157892], [1.794666398E12, 1.958333333333333], [1.794666359E12, 1.515789473684211], [1.794666361E12, 2.2857142857142865], [1.794666365E12, 1.8191489361702131], [1.794666363E12, 1.7227722772277223], [1.794666367E12, 2.6666666666666674], [1.79466637E12, 1.7395833333333333], [1.794666372E12, 1.6542056074766356], [1.794666376E12, 1.99047619047619], [1.794666374E12, 2.1165048543689315], [1.794666378E12, 1.8541666666666663], [1.79466638E12, 1.655555555555556], [1.794666384E12, 2.086021505376343], [1.794666382E12, 1.901960784313725], [1.794666386E12, 1.9670329670329674], [1.794666345E12, 2.6097560975609757], [1.794666388E12, 1.8118811881188117]], "isOverall": false, "label": "Tarifas", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.7946664E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 1.0, "minX": 1.794666344E12, "maxY": 347.0, "series": [{"data": [[1.794666391E12, 15.0], [1.794666348E12, 20.0], [1.794666352E12, 13.0], [1.79466635E12, 14.0], [1.794666393E12, 9.0], [1.794666354E12, 15.0], [1.794666397E12, 14.0], [1.794666395E12, 12.0], [1.794666399E12, 10.0], [1.794666356E12, 11.0], [1.79466636E12, 166.0], [1.794666358E12, 11.0], [1.794666362E12, 15.0], [1.794666364E12, 12.0], [1.794666368E12, 11.0], [1.794666366E12, 13.0], [1.794666369E12, 13.0], [1.794666373E12, 12.0], [1.794666371E12, 12.0], [1.794666375E12, 14.0], [1.794666377E12, 12.0], [1.794666381E12, 12.0], [1.794666379E12, 114.0], [1.794666383E12, 11.0], [1.794666344E12, 347.0], [1.794666385E12, 15.0], [1.794666346E12, 12.0], [1.794666389E12, 13.0], [1.794666387E12, 9.0], [1.794666349E12, 16.0], [1.794666392E12, 12.0], [1.794666347E12, 34.0], [1.79466639E12, 11.0], [1.794666351E12, 13.0], [1.794666394E12, 14.0], [1.794666353E12, 13.0], [1.794666396E12, 13.0], [1.794666357E12, 13.0], [1.7946664E12, 12.0], [1.794666355E12, 8.0], [1.794666398E12, 10.0], [1.794666359E12, 10.0], [1.794666361E12, 132.0], [1.794666365E12, 13.0], [1.794666363E12, 11.0], [1.794666367E12, 83.0], [1.79466637E12, 15.0], [1.794666372E12, 10.0], [1.794666376E12, 10.0], [1.794666374E12, 15.0], [1.794666378E12, 13.0], [1.79466638E12, 10.0], [1.794666384E12, 15.0], [1.794666382E12, 12.0], [1.794666386E12, 13.0], [1.794666345E12, 14.0], [1.794666388E12, 9.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.794666391E12, 2.0], [1.794666348E12, 2.0], [1.794666352E12, 2.0], [1.79466635E12, 3.0], [1.794666393E12, 2.0], [1.794666354E12, 2.0], [1.794666397E12, 1.0], [1.794666395E12, 3.0], [1.794666399E12, 2.0], [1.794666356E12, 2.0], [1.79466636E12, 2.0], [1.794666358E12, 2.0], [1.794666362E12, 2.0], [1.794666364E12, 2.0], [1.794666368E12, 3.0], [1.794666366E12, 1.0], [1.794666369E12, 2.0], [1.794666373E12, 2.0], [1.794666371E12, 2.0], [1.794666375E12, 2.0], [1.794666377E12, 2.0], [1.794666381E12, 3.0], [1.794666379E12, 2.0], [1.794666383E12, 2.0], [1.794666344E12, 3.0], [1.794666385E12, 3.0], [1.794666346E12, 3.0], [1.794666389E12, 2.0], [1.794666387E12, 2.0], [1.794666349E12, 3.0], [1.794666392E12, 2.0], [1.794666347E12, 3.0], [1.79466639E12, 2.0], [1.794666351E12, 3.0], [1.794666394E12, 2.0], [1.794666353E12, 2.0], [1.794666396E12, 2.0], [1.794666357E12, 2.0], [1.7946664E12, 3.0], [1.794666355E12, 2.0], [1.794666398E12, 2.0], [1.794666359E12, 2.0], [1.794666361E12, 2.0], [1.794666365E12, 2.0], [1.794666363E12, 2.0], [1.794666367E12, 2.0], [1.79466637E12, 2.0], [1.794666372E12, 2.0], [1.794666376E12, 2.0], [1.794666374E12, 2.0], [1.794666378E12, 2.0], [1.79466638E12, 2.0], [1.794666384E12, 2.0], [1.794666382E12, 2.0], [1.794666386E12, 2.0], [1.794666345E12, 4.0], [1.794666388E12, 2.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.794666391E12, 8.0], [1.794666348E12, 8.0], [1.794666352E12, 8.0], [1.79466635E12, 9.0], [1.794666393E12, 7.0], [1.794666354E12, 10.0], [1.794666397E12, 9.900000000000006], [1.794666395E12, 9.0], [1.794666399E12, 7.0], [1.794666356E12, 8.0], [1.79466636E12, 9.299999999999997], [1.794666358E12, 7.0], [1.794666362E12, 8.0], [1.794666364E12, 8.299999999999997], [1.794666368E12, 8.0], [1.794666366E12, 8.600000000000009], [1.794666369E12, 8.0], [1.794666373E12, 9.0], [1.794666371E12, 8.0], [1.794666375E12, 9.400000000000006], [1.794666377E12, 8.299999999999997], [1.794666381E12, 7.0], [1.794666379E12, 14.80000000000004], [1.794666383E12, 8.0], [1.794666344E12, 323.40000000000003], [1.794666385E12, 10.0], [1.794666346E12, 8.100000000000001], [1.794666389E12, 8.0], [1.794666387E12, 8.0], [1.794666349E12, 7.0], [1.794666392E12, 7.0], [1.794666347E12, 12.799999999999997], [1.79466639E12, 7.0], [1.794666351E12, 9.400000000000006], [1.794666394E12, 9.200000000000003], [1.794666353E12, 8.200000000000003], [1.794666396E12, 9.5], [1.794666357E12, 8.0], [1.7946664E12, 8.0], [1.794666355E12, 7.0], [1.794666398E12, 7.299999999999997], [1.794666359E12, 7.0], [1.794666361E12, 25.5], [1.794666365E12, 9.0], [1.794666363E12, 8.0], [1.794666367E12, 57.000000000000014], [1.79466637E12, 9.0], [1.794666372E12, 8.0], [1.794666376E12, 8.0], [1.794666374E12, 9.600000000000009], [1.794666378E12, 8.400000000000006], [1.79466638E12, 7.0], [1.794666384E12, 8.0], [1.794666382E12, 8.700000000000003], [1.794666386E12, 8.0], [1.794666345E12, 9.0], [1.794666388E12, 8.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.794666391E12, 14.800000000000011], [1.794666348E12, 20.0], [1.794666352E12, 13.0], [1.79466635E12, 14.0], [1.794666393E12, 9.0], [1.794666354E12, 14.940000000000012], [1.794666397E12, 13.780000000000001], [1.794666395E12, 12.0], [1.794666399E12, 9.980000000000004], [1.794666356E12, 10.97999999999999], [1.79466636E12, 166.0], [1.794666358E12, 11.0], [1.794666362E12, 14.940000000000012], [1.794666364E12, 12.0], [1.794666368E12, 11.0], [1.794666366E12, 13.0], [1.794666369E12, 13.0], [1.794666373E12, 12.0], [1.794666371E12, 12.0], [1.794666375E12, 14.0], [1.794666377E12, 12.0], [1.794666381E12, 11.969999999999999], [1.794666379E12, 114.0], [1.794666383E12, 11.0], [1.794666344E12, 347.0], [1.794666385E12, 15.0], [1.794666346E12, 12.0], [1.794666389E12, 12.97999999999999], [1.794666387E12, 9.0], [1.794666349E12, 16.0], [1.794666392E12, 11.879999999999995], [1.794666347E12, 34.0], [1.79466639E12, 11.0], [1.794666351E12, 12.939999999999998], [1.794666394E12, 14.0], [1.794666353E12, 13.0], [1.794666396E12, 13.0], [1.794666357E12, 13.0], [1.7946664E12, 12.0], [1.794666355E12, 8.0], [1.794666398E12, 10.0], [1.794666359E12, 10.0], [1.794666361E12, 132.0], [1.794666365E12, 13.0], [1.794666363E12, 10.980000000000004], [1.794666367E12, 83.0], [1.79466637E12, 15.0], [1.794666372E12, 10.0], [1.794666376E12, 10.0], [1.794666374E12, 14.879999999999981], [1.794666378E12, 13.0], [1.79466638E12, 10.0], [1.794666384E12, 15.0], [1.794666382E12, 11.939999999999998], [1.794666386E12, 13.0], [1.794666345E12, 14.0], [1.794666388E12, 9.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.794666391E12, 5.0], [1.794666348E12, 6.0], [1.794666352E12, 5.0], [1.79466635E12, 6.0], [1.794666393E12, 4.0], [1.794666354E12, 6.0], [1.794666397E12, 5.0], [1.794666395E12, 5.0], [1.794666399E12, 4.0], [1.794666356E12, 5.0], [1.79466636E12, 5.0], [1.794666358E12, 4.0], [1.794666362E12, 4.0], [1.794666364E12, 5.0], [1.794666368E12, 5.0], [1.794666366E12, 4.0], [1.794666369E12, 5.0], [1.794666373E12, 5.0], [1.794666371E12, 4.0], [1.794666375E12, 5.0], [1.794666377E12, 5.0], [1.794666381E12, 5.0], [1.794666379E12, 5.0], [1.794666383E12, 5.0], [1.794666344E12, 7.5], [1.794666385E12, 6.0], [1.794666346E12, 5.0], [1.794666389E12, 5.0], [1.794666387E12, 5.0], [1.794666349E12, 4.0], [1.794666392E12, 5.0], [1.794666347E12, 5.0], [1.79466639E12, 4.5], [1.794666351E12, 6.0], [1.794666394E12, 6.0], [1.794666353E12, 6.0], [1.794666396E12, 4.0], [1.794666357E12, 5.0], [1.7946664E12, 5.0], [1.794666355E12, 4.0], [1.794666398E12, 5.0], [1.794666359E12, 4.0], [1.794666361E12, 5.0], [1.794666365E12, 4.5], [1.794666363E12, 5.0], [1.794666367E12, 5.0], [1.79466637E12, 5.0], [1.794666372E12, 5.0], [1.794666376E12, 5.0], [1.794666374E12, 5.0], [1.794666378E12, 5.0], [1.79466638E12, 4.0], [1.794666384E12, 5.0], [1.794666382E12, 5.0], [1.794666386E12, 5.0], [1.794666345E12, 6.0], [1.794666388E12, 5.0]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.794666391E12, 9.0], [1.794666348E12, 10.049999999999997], [1.794666352E12, 10.0], [1.79466635E12, 11.0], [1.794666393E12, 8.0], [1.794666354E12, 11.0], [1.794666397E12, 10.0], [1.794666395E12, 9.199999999999989], [1.794666399E12, 7.0], [1.794666356E12, 8.949999999999989], [1.79466636E12, 133.24999999999994], [1.794666358E12, 7.049999999999997], [1.794666362E12, 9.0], [1.794666364E12, 9.299999999999983], [1.794666368E12, 9.099999999999994], [1.794666366E12, 12.799999999999997], [1.794666369E12, 10.0], [1.794666373E12, 10.0], [1.794666371E12, 10.0], [1.794666375E12, 11.0], [1.794666377E12, 11.0], [1.794666381E12, 9.0], [1.794666379E12, 105.39999999999998], [1.794666383E12, 8.349999999999994], [1.794666344E12, 342.04999999999995], [1.794666385E12, 11.799999999999997], [1.794666346E12, 9.549999999999997], [1.794666389E12, 9.0], [1.794666387E12, 8.349999999999994], [1.794666349E12, 8.0], [1.794666392E12, 8.0], [1.794666347E12, 28.199999999999996], [1.79466639E12, 8.0], [1.794666351E12, 11.0], [1.794666394E12, 11.0], [1.794666353E12, 11.599999999999994], [1.794666396E12, 11.0], [1.794666357E12, 9.149999999999991], [1.7946664E12, 9.0], [1.794666355E12, 8.0], [1.794666398E12, 8.0], [1.794666359E12, 8.0], [1.794666361E12, 121.25], [1.794666365E12, 11.0], [1.794666363E12, 8.899999999999991], [1.794666367E12, 75.79999999999998], [1.79466637E12, 11.199999999999989], [1.794666372E12, 9.0], [1.794666376E12, 9.699999999999989], [1.794666374E12, 10.799999999999997], [1.794666378E12, 11.199999999999989], [1.79466638E12, 8.0], [1.794666384E12, 10.299999999999997], [1.794666382E12, 10.0], [1.794666386E12, 10.0], [1.794666345E12, 11.799999999999997], [1.794666388E12, 8.0]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.7946664E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 1.0, "minX": 34.0, "maxY": 7.5, "series": [{"data": [[34.0, 7.5], [41.0, 6.0], [48.0, 5.0], [55.0, 5.0], [73.0, 4.0], [78.0, 6.0], [87.0, 5.0], [91.0, 5.0], [90.0, 4.0], [93.0, 5.0], [95.0, 5.0], [94.0, 4.0], [92.0, 5.0], [96.0, 5.0], [98.0, 4.0], [97.0, 5.0], [99.0, 5.0], [101.0, 5.0], [100.0, 5.0], [103.0, 5.0], [102.0, 5.0], [105.0, 5.0], [107.0, 5.0], [104.0, 5.0], [110.0, 5.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[34.0, 6.5], [91.0, 3.0], [96.0, 3.0], [103.0, 1.0], [102.0, 1.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 110.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 0.0, "minX": 34.0, "maxY": 6.5, "series": [{"data": [[34.0, 6.5], [41.0, 5.0], [48.0, 5.0], [55.0, 5.0], [73.0, 4.0], [78.0, 5.0], [87.0, 5.0], [91.0, 5.0], [90.0, 4.0], [93.0, 5.0], [95.0, 4.0], [94.0, 4.0], [92.0, 4.0], [96.0, 5.0], [98.0, 4.0], [97.0, 5.0], [99.0, 5.0], [101.0, 4.0], [100.0, 4.0], [103.0, 5.0], [102.0, 4.0], [105.0, 5.0], [107.0, 5.0], [104.0, 5.0], [110.0, 5.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[34.0, 0.0], [91.0, 0.0], [96.0, 0.0], [103.0, 0.0], [102.0, 0.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 110.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 34.0, "minX": 1.794666344E12, "maxY": 111.0, "series": [{"data": [[1.794666391E12, 103.0], [1.794666348E12, 78.0], [1.794666352E12, 93.0], [1.79466635E12, 85.0], [1.794666393E12, 96.0], [1.794666354E12, 99.0], [1.794666397E12, 111.0], [1.794666395E12, 97.0], [1.794666399E12, 101.0], [1.794666356E12, 103.0], [1.79466636E12, 103.0], [1.794666358E12, 98.0], [1.794666362E12, 102.0], [1.794666364E12, 96.0], [1.794666368E12, 99.0], [1.794666366E12, 103.0], [1.794666369E12, 89.0], [1.794666373E12, 99.0], [1.794666371E12, 100.0], [1.794666375E12, 95.0], [1.794666377E12, 96.0], [1.794666381E12, 103.0], [1.794666379E12, 102.0], [1.794666383E12, 94.0], [1.794666344E12, 34.0], [1.794666385E12, 103.0], [1.794666346E12, 48.0], [1.794666389E12, 99.0], [1.794666387E12, 94.0], [1.794666349E12, 75.0], [1.794666392E12, 105.0], [1.794666347E12, 55.0], [1.79466639E12, 98.0], [1.794666351E12, 105.0], [1.794666394E12, 97.0], [1.794666353E12, 109.0], [1.794666396E12, 92.0], [1.794666357E12, 93.0], [1.7946664E12, 87.0], [1.794666355E12, 95.0], [1.794666398E12, 95.0], [1.794666359E12, 95.0], [1.794666361E12, 91.0], [1.794666365E12, 94.0], [1.794666363E12, 101.0], [1.794666367E12, 96.0], [1.79466637E12, 96.0], [1.794666372E12, 106.0], [1.794666376E12, 105.0], [1.794666374E12, 103.0], [1.794666378E12, 96.0], [1.79466638E12, 90.0], [1.794666384E12, 91.0], [1.794666382E12, 101.0], [1.794666386E12, 91.0], [1.794666345E12, 41.0], [1.794666388E12, 101.0]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.7946664E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 1.0, "minX": 1.794666344E12, "maxY": 110.0, "series": [{"data": [[1.794666391E12, 104.0], [1.794666348E12, 78.0], [1.794666352E12, 93.0], [1.79466635E12, 87.0], [1.794666393E12, 96.0], [1.794666354E12, 101.0], [1.794666397E12, 110.0], [1.794666395E12, 95.0], [1.794666399E12, 101.0], [1.794666356E12, 100.0], [1.79466636E12, 86.0], [1.794666358E12, 98.0], [1.794666362E12, 101.0], [1.794666364E12, 96.0], [1.794666368E12, 97.0], [1.794666366E12, 103.0], [1.794666369E12, 91.0], [1.794666373E12, 99.0], [1.794666371E12, 99.0], [1.794666375E12, 95.0], [1.794666377E12, 96.0], [1.794666381E12, 102.0], [1.794666379E12, 95.0], [1.794666383E12, 92.0], [1.794666344E12, 28.0], [1.794666385E12, 103.0], [1.794666346E12, 48.0], [1.794666389E12, 100.0], [1.794666387E12, 92.0], [1.794666349E12, 73.0], [1.794666392E12, 105.0], [1.794666347E12, 55.0], [1.79466639E12, 98.0], [1.794666351E12, 105.0], [1.794666394E12, 97.0], [1.794666353E12, 107.0], [1.794666396E12, 94.0], [1.794666357E12, 96.0], [1.7946664E12, 87.0], [1.794666355E12, 95.0], [1.794666398E12, 96.0], [1.794666359E12, 95.0], [1.794666361E12, 84.0], [1.794666365E12, 94.0], [1.794666363E12, 101.0], [1.794666367E12, 87.0], [1.79466637E12, 95.0], [1.794666372E12, 107.0], [1.794666376E12, 105.0], [1.794666374E12, 103.0], [1.794666378E12, 95.0], [1.79466638E12, 90.0], [1.794666384E12, 93.0], [1.794666382E12, 102.0], [1.794666386E12, 91.0], [1.794666345E12, 41.0], [1.794666388E12, 101.0]], "isOverall": false, "label": "200", "isController": false}, {"data": [[1.79466637E12, 1.0], [1.79466636E12, 17.0], [1.794666379E12, 7.0], [1.794666362E12, 1.0], [1.794666361E12, 7.0], [1.794666344E12, 6.0], [1.794666367E12, 9.0], [1.794666378E12, 1.0]], "isOverall": false, "label": "Non HTTP response code: org.apache.http.conn.HttpHostConnectException", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.7946664E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 1.0, "minX": 1.794666344E12, "maxY": 110.0, "series": [{"data": [[1.79466637E12, 1.0], [1.79466636E12, 17.0], [1.794666379E12, 7.0], [1.794666362E12, 1.0], [1.794666361E12, 7.0], [1.794666344E12, 6.0], [1.794666367E12, 9.0], [1.794666378E12, 1.0]], "isOverall": false, "label": "Tarifas-failure", "isController": false}, {"data": [[1.794666391E12, 104.0], [1.794666348E12, 78.0], [1.794666352E12, 93.0], [1.79466635E12, 87.0], [1.794666393E12, 96.0], [1.794666354E12, 101.0], [1.794666397E12, 110.0], [1.794666395E12, 95.0], [1.794666399E12, 101.0], [1.794666356E12, 100.0], [1.79466636E12, 86.0], [1.794666358E12, 98.0], [1.794666362E12, 101.0], [1.794666364E12, 96.0], [1.794666368E12, 97.0], [1.794666366E12, 103.0], [1.794666369E12, 91.0], [1.794666373E12, 99.0], [1.794666371E12, 99.0], [1.794666375E12, 95.0], [1.794666377E12, 96.0], [1.794666381E12, 102.0], [1.794666379E12, 95.0], [1.794666383E12, 92.0], [1.794666344E12, 28.0], [1.794666385E12, 103.0], [1.794666346E12, 48.0], [1.794666389E12, 100.0], [1.794666387E12, 92.0], [1.794666349E12, 73.0], [1.794666392E12, 105.0], [1.794666347E12, 55.0], [1.79466639E12, 98.0], [1.794666351E12, 105.0], [1.794666394E12, 97.0], [1.794666353E12, 107.0], [1.794666396E12, 94.0], [1.794666357E12, 96.0], [1.7946664E12, 87.0], [1.794666355E12, 95.0], [1.794666398E12, 96.0], [1.794666359E12, 95.0], [1.794666361E12, 84.0], [1.794666365E12, 94.0], [1.794666363E12, 101.0], [1.794666367E12, 87.0], [1.79466637E12, 95.0], [1.794666372E12, 107.0], [1.794666376E12, 105.0], [1.794666374E12, 103.0], [1.794666378E12, 95.0], [1.79466638E12, 90.0], [1.794666384E12, 93.0], [1.794666382E12, 102.0], [1.794666386E12, 91.0], [1.794666345E12, 41.0], [1.794666388E12, 101.0]], "isOverall": false, "label": "Tarifas-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.7946664E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 1.0, "minX": 1.794666344E12, "maxY": 110.0, "series": [{"data": [[1.794666391E12, 104.0], [1.794666348E12, 78.0], [1.794666352E12, 93.0], [1.79466635E12, 87.0], [1.794666393E12, 96.0], [1.794666354E12, 101.0], [1.794666397E12, 110.0], [1.794666395E12, 95.0], [1.794666399E12, 101.0], [1.794666356E12, 100.0], [1.79466636E12, 86.0], [1.794666358E12, 98.0], [1.794666362E12, 101.0], [1.794666364E12, 96.0], [1.794666368E12, 97.0], [1.794666366E12, 103.0], [1.794666369E12, 91.0], [1.794666373E12, 99.0], [1.794666371E12, 99.0], [1.794666375E12, 95.0], [1.794666377E12, 96.0], [1.794666381E12, 102.0], [1.794666379E12, 95.0], [1.794666383E12, 92.0], [1.794666344E12, 28.0], [1.794666385E12, 103.0], [1.794666346E12, 48.0], [1.794666389E12, 100.0], [1.794666387E12, 92.0], [1.794666349E12, 73.0], [1.794666392E12, 105.0], [1.794666347E12, 55.0], [1.79466639E12, 98.0], [1.794666351E12, 105.0], [1.794666394E12, 97.0], [1.794666353E12, 107.0], [1.794666396E12, 94.0], [1.794666357E12, 96.0], [1.7946664E12, 87.0], [1.794666355E12, 95.0], [1.794666398E12, 96.0], [1.794666359E12, 95.0], [1.794666361E12, 84.0], [1.794666365E12, 94.0], [1.794666363E12, 101.0], [1.794666367E12, 87.0], [1.79466637E12, 95.0], [1.794666372E12, 107.0], [1.794666376E12, 105.0], [1.794666374E12, 103.0], [1.794666378E12, 95.0], [1.79466638E12, 90.0], [1.794666384E12, 93.0], [1.794666382E12, 102.0], [1.794666386E12, 91.0], [1.794666345E12, 41.0], [1.794666388E12, 101.0]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [[1.79466637E12, 1.0], [1.79466636E12, 17.0], [1.794666379E12, 7.0], [1.794666362E12, 1.0], [1.794666361E12, 7.0], [1.794666344E12, 6.0], [1.794666367E12, 9.0], [1.794666378E12, 1.0]], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.7946664E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

