/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 0.0, "minX": 0.0, "maxY": 180.0, "series": [{"data": [[0.0, 0.0], [0.1, 1.0], [0.2, 1.0], [0.3, 1.0], [0.4, 1.0], [0.5, 1.0], [0.6, 1.0], [0.7, 1.0], [0.8, 1.0], [0.9, 1.0], [1.0, 1.0], [1.1, 1.0], [1.2, 1.0], [1.3, 1.0], [1.4, 1.0], [1.5, 1.0], [1.6, 1.0], [1.7, 1.0], [1.8, 1.0], [1.9, 1.0], [2.0, 1.0], [2.1, 1.0], [2.2, 1.0], [2.3, 1.0], [2.4, 1.0], [2.5, 1.0], [2.6, 1.0], [2.7, 1.0], [2.8, 1.0], [2.9, 1.0], [3.0, 1.0], [3.1, 1.0], [3.2, 1.0], [3.3, 1.0], [3.4, 1.0], [3.5, 1.0], [3.6, 1.0], [3.7, 1.0], [3.8, 1.0], [3.9, 1.0], [4.0, 1.0], [4.1, 1.0], [4.2, 1.0], [4.3, 1.0], [4.4, 1.0], [4.5, 1.0], [4.6, 1.0], [4.7, 1.0], [4.8, 1.0], [4.9, 1.0], [5.0, 1.0], [5.1, 1.0], [5.2, 1.0], [5.3, 1.0], [5.4, 1.0], [5.5, 1.0], [5.6, 1.0], [5.7, 1.0], [5.8, 1.0], [5.9, 1.0], [6.0, 1.0], [6.1, 1.0], [6.2, 1.0], [6.3, 1.0], [6.4, 1.0], [6.5, 1.0], [6.6, 1.0], [6.7, 1.0], [6.8, 1.0], [6.9, 1.0], [7.0, 1.0], [7.1, 1.0], [7.2, 1.0], [7.3, 1.0], [7.4, 1.0], [7.5, 1.0], [7.6, 1.0], [7.7, 1.0], [7.8, 1.0], [7.9, 1.0], [8.0, 1.0], [8.1, 1.0], [8.2, 1.0], [8.3, 1.0], [8.4, 1.0], [8.5, 1.0], [8.6, 1.0], [8.7, 1.0], [8.8, 1.0], [8.9, 1.0], [9.0, 1.0], [9.1, 1.0], [9.2, 1.0], [9.3, 1.0], [9.4, 1.0], [9.5, 1.0], [9.6, 1.0], [9.7, 1.0], [9.8, 1.0], [9.9, 1.0], [10.0, 1.0], [10.1, 1.0], [10.2, 1.0], [10.3, 1.0], [10.4, 1.0], [10.5, 1.0], [10.6, 1.0], [10.7, 1.0], [10.8, 1.0], [10.9, 1.0], [11.0, 1.0], [11.1, 1.0], [11.2, 1.0], [11.3, 1.0], [11.4, 1.0], [11.5, 1.0], [11.6, 1.0], [11.7, 1.0], [11.8, 1.0], [11.9, 1.0], [12.0, 1.0], [12.1, 1.0], [12.2, 1.0], [12.3, 1.0], [12.4, 1.0], [12.5, 1.0], [12.6, 1.0], [12.7, 1.0], [12.8, 1.0], [12.9, 1.0], [13.0, 1.0], [13.1, 1.0], [13.2, 1.0], [13.3, 1.0], [13.4, 1.0], [13.5, 1.0], [13.6, 1.0], [13.7, 1.0], [13.8, 1.0], [13.9, 2.0], [14.0, 2.0], [14.1, 2.0], [14.2, 2.0], [14.3, 2.0], [14.4, 2.0], [14.5, 2.0], [14.6, 2.0], [14.7, 2.0], [14.8, 2.0], [14.9, 2.0], [15.0, 2.0], [15.1, 2.0], [15.2, 2.0], [15.3, 2.0], [15.4, 2.0], [15.5, 2.0], [15.6, 2.0], [15.7, 2.0], [15.8, 2.0], [15.9, 2.0], [16.0, 2.0], [16.1, 2.0], [16.2, 2.0], [16.3, 2.0], [16.4, 2.0], [16.5, 2.0], [16.6, 2.0], [16.7, 2.0], [16.8, 2.0], [16.9, 2.0], [17.0, 2.0], [17.1, 2.0], [17.2, 2.0], [17.3, 2.0], [17.4, 2.0], [17.5, 2.0], [17.6, 2.0], [17.7, 2.0], [17.8, 2.0], [17.9, 2.0], [18.0, 2.0], [18.1, 2.0], [18.2, 2.0], [18.3, 2.0], [18.4, 2.0], [18.5, 2.0], [18.6, 2.0], [18.7, 2.0], [18.8, 2.0], [18.9, 2.0], [19.0, 2.0], [19.1, 2.0], [19.2, 2.0], [19.3, 2.0], [19.4, 2.0], [19.5, 2.0], [19.6, 2.0], [19.7, 2.0], [19.8, 2.0], [19.9, 2.0], [20.0, 2.0], [20.1, 2.0], [20.2, 2.0], [20.3, 2.0], [20.4, 2.0], [20.5, 2.0], [20.6, 2.0], [20.7, 2.0], [20.8, 2.0], [20.9, 2.0], [21.0, 2.0], [21.1, 2.0], [21.2, 2.0], [21.3, 2.0], [21.4, 2.0], [21.5, 2.0], [21.6, 2.0], [21.7, 2.0], [21.8, 2.0], [21.9, 2.0], [22.0, 2.0], [22.1, 2.0], [22.2, 2.0], [22.3, 2.0], [22.4, 2.0], [22.5, 2.0], [22.6, 2.0], [22.7, 2.0], [22.8, 2.0], [22.9, 2.0], [23.0, 2.0], [23.1, 2.0], [23.2, 2.0], [23.3, 2.0], [23.4, 2.0], [23.5, 2.0], [23.6, 2.0], [23.7, 2.0], [23.8, 2.0], [23.9, 2.0], [24.0, 2.0], [24.1, 2.0], [24.2, 2.0], [24.3, 2.0], [24.4, 2.0], [24.5, 2.0], [24.6, 2.0], [24.7, 2.0], [24.8, 2.0], [24.9, 2.0], [25.0, 2.0], [25.1, 2.0], [25.2, 2.0], [25.3, 2.0], [25.4, 2.0], [25.5, 2.0], [25.6, 2.0], [25.7, 2.0], [25.8, 2.0], [25.9, 2.0], [26.0, 2.0], [26.1, 2.0], [26.2, 2.0], [26.3, 2.0], [26.4, 2.0], [26.5, 2.0], [26.6, 2.0], [26.7, 2.0], [26.8, 2.0], [26.9, 2.0], [27.0, 2.0], [27.1, 2.0], [27.2, 2.0], [27.3, 2.0], [27.4, 2.0], [27.5, 2.0], [27.6, 2.0], [27.7, 2.0], [27.8, 2.0], [27.9, 2.0], [28.0, 2.0], [28.1, 2.0], [28.2, 2.0], [28.3, 2.0], [28.4, 2.0], [28.5, 2.0], [28.6, 2.0], [28.7, 2.0], [28.8, 2.0], [28.9, 2.0], [29.0, 2.0], [29.1, 2.0], [29.2, 2.0], [29.3, 2.0], [29.4, 2.0], [29.5, 2.0], [29.6, 2.0], [29.7, 2.0], [29.8, 2.0], [29.9, 2.0], [30.0, 2.0], [30.1, 2.0], [30.2, 2.0], [30.3, 2.0], [30.4, 2.0], [30.5, 2.0], [30.6, 2.0], [30.7, 2.0], [30.8, 2.0], [30.9, 2.0], [31.0, 2.0], [31.1, 2.0], [31.2, 2.0], [31.3, 2.0], [31.4, 2.0], [31.5, 2.0], [31.6, 2.0], [31.7, 2.0], [31.8, 2.0], [31.9, 2.0], [32.0, 2.0], [32.1, 2.0], [32.2, 2.0], [32.3, 2.0], [32.4, 2.0], [32.5, 2.0], [32.6, 2.0], [32.7, 2.0], [32.8, 2.0], [32.9, 2.0], [33.0, 2.0], [33.1, 2.0], [33.2, 2.0], [33.3, 2.0], [33.4, 2.0], [33.5, 2.0], [33.6, 2.0], [33.7, 2.0], [33.8, 2.0], [33.9, 2.0], [34.0, 2.0], [34.1, 2.0], [34.2, 2.0], [34.3, 2.0], [34.4, 2.0], [34.5, 2.0], [34.6, 2.0], [34.7, 2.0], [34.8, 2.0], [34.9, 2.0], [35.0, 2.0], [35.1, 2.0], [35.2, 2.0], [35.3, 2.0], [35.4, 2.0], [35.5, 2.0], [35.6, 2.0], [35.7, 2.0], [35.8, 2.0], [35.9, 2.0], [36.0, 2.0], [36.1, 2.0], [36.2, 2.0], [36.3, 2.0], [36.4, 2.0], [36.5, 2.0], [36.6, 2.0], [36.7, 2.0], [36.8, 2.0], [36.9, 2.0], [37.0, 2.0], [37.1, 2.0], [37.2, 2.0], [37.3, 2.0], [37.4, 2.0], [37.5, 2.0], [37.6, 2.0], [37.7, 2.0], [37.8, 2.0], [37.9, 2.0], [38.0, 2.0], [38.1, 2.0], [38.2, 2.0], [38.3, 2.0], [38.4, 2.0], [38.5, 2.0], [38.6, 2.0], [38.7, 2.0], [38.8, 2.0], [38.9, 2.0], [39.0, 2.0], [39.1, 2.0], [39.2, 2.0], [39.3, 2.0], [39.4, 2.0], [39.5, 2.0], [39.6, 2.0], [39.7, 2.0], [39.8, 2.0], [39.9, 2.0], [40.0, 2.0], [40.1, 2.0], [40.2, 2.0], [40.3, 2.0], [40.4, 2.0], [40.5, 2.0], [40.6, 2.0], [40.7, 2.0], [40.8, 2.0], [40.9, 2.0], [41.0, 2.0], [41.1, 2.0], [41.2, 2.0], [41.3, 2.0], [41.4, 2.0], [41.5, 2.0], [41.6, 2.0], [41.7, 2.0], [41.8, 2.0], [41.9, 2.0], [42.0, 2.0], [42.1, 2.0], [42.2, 2.0], [42.3, 2.0], [42.4, 2.0], [42.5, 2.0], [42.6, 2.0], [42.7, 2.0], [42.8, 2.0], [42.9, 2.0], [43.0, 2.0], [43.1, 2.0], [43.2, 2.0], [43.3, 2.0], [43.4, 2.0], [43.5, 2.0], [43.6, 2.0], [43.7, 2.0], [43.8, 2.0], [43.9, 2.0], [44.0, 2.0], [44.1, 2.0], [44.2, 2.0], [44.3, 2.0], [44.4, 2.0], [44.5, 2.0], [44.6, 2.0], [44.7, 2.0], [44.8, 2.0], [44.9, 2.0], [45.0, 2.0], [45.1, 2.0], [45.2, 2.0], [45.3, 2.0], [45.4, 2.0], [45.5, 2.0], [45.6, 2.0], [45.7, 2.0], [45.8, 2.0], [45.9, 2.0], [46.0, 2.0], [46.1, 2.0], [46.2, 2.0], [46.3, 2.0], [46.4, 2.0], [46.5, 2.0], [46.6, 2.0], [46.7, 2.0], [46.8, 2.0], [46.9, 2.0], [47.0, 2.0], [47.1, 2.0], [47.2, 2.0], [47.3, 2.0], [47.4, 2.0], [47.5, 2.0], [47.6, 2.0], [47.7, 2.0], [47.8, 2.0], [47.9, 2.0], [48.0, 2.0], [48.1, 2.0], [48.2, 2.0], [48.3, 2.0], [48.4, 2.0], [48.5, 2.0], [48.6, 2.0], [48.7, 2.0], [48.8, 2.0], [48.9, 2.0], [49.0, 2.0], [49.1, 2.0], [49.2, 2.0], [49.3, 2.0], [49.4, 2.0], [49.5, 2.0], [49.6, 2.0], [49.7, 2.0], [49.8, 2.0], [49.9, 2.0], [50.0, 2.0], [50.1, 2.0], [50.2, 2.0], [50.3, 2.0], [50.4, 2.0], [50.5, 2.0], [50.6, 2.0], [50.7, 2.0], [50.8, 2.0], [50.9, 2.0], [51.0, 2.0], [51.1, 2.0], [51.2, 2.0], [51.3, 2.0], [51.4, 2.0], [51.5, 2.0], [51.6, 2.0], [51.7, 2.0], [51.8, 2.0], [51.9, 2.0], [52.0, 2.0], [52.1, 2.0], [52.2, 2.0], [52.3, 2.0], [52.4, 2.0], [52.5, 2.0], [52.6, 2.0], [52.7, 2.0], [52.8, 2.0], [52.9, 2.0], [53.0, 2.0], [53.1, 2.0], [53.2, 2.0], [53.3, 2.0], [53.4, 2.0], [53.5, 2.0], [53.6, 2.0], [53.7, 2.0], [53.8, 2.0], [53.9, 2.0], [54.0, 2.0], [54.1, 2.0], [54.2, 2.0], [54.3, 2.0], [54.4, 2.0], [54.5, 2.0], [54.6, 2.0], [54.7, 2.0], [54.8, 2.0], [54.9, 2.0], [55.0, 2.0], [55.1, 2.0], [55.2, 2.0], [55.3, 2.0], [55.4, 2.0], [55.5, 2.0], [55.6, 2.0], [55.7, 2.0], [55.8, 2.0], [55.9, 2.0], [56.0, 2.0], [56.1, 2.0], [56.2, 2.0], [56.3, 2.0], [56.4, 2.0], [56.5, 2.0], [56.6, 2.0], [56.7, 2.0], [56.8, 2.0], [56.9, 2.0], [57.0, 2.0], [57.1, 2.0], [57.2, 2.0], [57.3, 2.0], [57.4, 2.0], [57.5, 2.0], [57.6, 2.0], [57.7, 2.0], [57.8, 2.0], [57.9, 2.0], [58.0, 2.0], [58.1, 2.0], [58.2, 2.0], [58.3, 2.0], [58.4, 2.0], [58.5, 3.0], [58.6, 3.0], [58.7, 3.0], [58.8, 3.0], [58.9, 3.0], [59.0, 3.0], [59.1, 3.0], [59.2, 3.0], [59.3, 3.0], [59.4, 3.0], [59.5, 3.0], [59.6, 3.0], [59.7, 3.0], [59.8, 3.0], [59.9, 3.0], [60.0, 3.0], [60.1, 3.0], [60.2, 3.0], [60.3, 3.0], [60.4, 3.0], [60.5, 3.0], [60.6, 3.0], [60.7, 3.0], [60.8, 3.0], [60.9, 3.0], [61.0, 3.0], [61.1, 3.0], [61.2, 3.0], [61.3, 3.0], [61.4, 3.0], [61.5, 3.0], [61.6, 3.0], [61.7, 3.0], [61.8, 3.0], [61.9, 3.0], [62.0, 3.0], [62.1, 3.0], [62.2, 3.0], [62.3, 3.0], [62.4, 3.0], [62.5, 3.0], [62.6, 3.0], [62.7, 3.0], [62.8, 3.0], [62.9, 3.0], [63.0, 3.0], [63.1, 3.0], [63.2, 3.0], [63.3, 3.0], [63.4, 3.0], [63.5, 3.0], [63.6, 3.0], [63.7, 3.0], [63.8, 3.0], [63.9, 3.0], [64.0, 3.0], [64.1, 3.0], [64.2, 3.0], [64.3, 3.0], [64.4, 3.0], [64.5, 3.0], [64.6, 3.0], [64.7, 3.0], [64.8, 3.0], [64.9, 3.0], [65.0, 3.0], [65.1, 3.0], [65.2, 3.0], [65.3, 3.0], [65.4, 3.0], [65.5, 3.0], [65.6, 3.0], [65.7, 3.0], [65.8, 3.0], [65.9, 3.0], [66.0, 3.0], [66.1, 3.0], [66.2, 3.0], [66.3, 3.0], [66.4, 3.0], [66.5, 3.0], [66.6, 3.0], [66.7, 3.0], [66.8, 3.0], [66.9, 3.0], [67.0, 3.0], [67.1, 3.0], [67.2, 3.0], [67.3, 3.0], [67.4, 3.0], [67.5, 3.0], [67.6, 3.0], [67.7, 3.0], [67.8, 3.0], [67.9, 3.0], [68.0, 3.0], [68.1, 3.0], [68.2, 3.0], [68.3, 3.0], [68.4, 3.0], [68.5, 3.0], [68.6, 3.0], [68.7, 3.0], [68.8, 3.0], [68.9, 3.0], [69.0, 3.0], [69.1, 3.0], [69.2, 3.0], [69.3, 3.0], [69.4, 3.0], [69.5, 3.0], [69.6, 3.0], [69.7, 3.0], [69.8, 3.0], [69.9, 3.0], [70.0, 3.0], [70.1, 3.0], [70.2, 3.0], [70.3, 3.0], [70.4, 3.0], [70.5, 3.0], [70.6, 3.0], [70.7, 3.0], [70.8, 3.0], [70.9, 3.0], [71.0, 3.0], [71.1, 3.0], [71.2, 3.0], [71.3, 3.0], [71.4, 3.0], [71.5, 3.0], [71.6, 3.0], [71.7, 3.0], [71.8, 3.0], [71.9, 3.0], [72.0, 3.0], [72.1, 3.0], [72.2, 3.0], [72.3, 3.0], [72.4, 3.0], [72.5, 3.0], [72.6, 3.0], [72.7, 3.0], [72.8, 3.0], [72.9, 3.0], [73.0, 3.0], [73.1, 3.0], [73.2, 3.0], [73.3, 3.0], [73.4, 3.0], [73.5, 3.0], [73.6, 3.0], [73.7, 3.0], [73.8, 3.0], [73.9, 3.0], [74.0, 3.0], [74.1, 3.0], [74.2, 3.0], [74.3, 3.0], [74.4, 3.0], [74.5, 3.0], [74.6, 3.0], [74.7, 3.0], [74.8, 3.0], [74.9, 3.0], [75.0, 3.0], [75.1, 3.0], [75.2, 3.0], [75.3, 3.0], [75.4, 3.0], [75.5, 3.0], [75.6, 3.0], [75.7, 3.0], [75.8, 3.0], [75.9, 3.0], [76.0, 3.0], [76.1, 3.0], [76.2, 3.0], [76.3, 3.0], [76.4, 3.0], [76.5, 3.0], [76.6, 3.0], [76.7, 3.0], [76.8, 3.0], [76.9, 3.0], [77.0, 3.0], [77.1, 3.0], [77.2, 3.0], [77.3, 3.0], [77.4, 3.0], [77.5, 3.0], [77.6, 3.0], [77.7, 3.0], [77.8, 3.0], [77.9, 3.0], [78.0, 3.0], [78.1, 3.0], [78.2, 3.0], [78.3, 3.0], [78.4, 3.0], [78.5, 3.0], [78.6, 3.0], [78.7, 3.0], [78.8, 3.0], [78.9, 3.0], [79.0, 3.0], [79.1, 3.0], [79.2, 3.0], [79.3, 3.0], [79.4, 3.0], [79.5, 3.0], [79.6, 3.0], [79.7, 3.0], [79.8, 3.0], [79.9, 3.0], [80.0, 3.0], [80.1, 3.0], [80.2, 3.0], [80.3, 3.0], [80.4, 3.0], [80.5, 3.0], [80.6, 3.0], [80.7, 3.0], [80.8, 3.0], [80.9, 3.0], [81.0, 3.0], [81.1, 3.0], [81.2, 3.0], [81.3, 3.0], [81.4, 3.0], [81.5, 3.0], [81.6, 3.0], [81.7, 3.0], [81.8, 3.0], [81.9, 3.0], [82.0, 3.0], [82.1, 3.0], [82.2, 3.0], [82.3, 3.0], [82.4, 3.0], [82.5, 3.0], [82.6, 3.0], [82.7, 3.0], [82.8, 3.0], [82.9, 3.0], [83.0, 3.0], [83.1, 3.0], [83.2, 3.0], [83.3, 3.0], [83.4, 3.0], [83.5, 3.0], [83.6, 3.0], [83.7, 3.0], [83.8, 3.0], [83.9, 3.0], [84.0, 3.0], [84.1, 3.0], [84.2, 3.0], [84.3, 3.0], [84.4, 3.0], [84.5, 3.0], [84.6, 3.0], [84.7, 3.0], [84.8, 3.0], [84.9, 3.0], [85.0, 3.0], [85.1, 4.0], [85.2, 4.0], [85.3, 4.0], [85.4, 4.0], [85.5, 4.0], [85.6, 4.0], [85.7, 4.0], [85.8, 4.0], [85.9, 4.0], [86.0, 4.0], [86.1, 4.0], [86.2, 4.0], [86.3, 4.0], [86.4, 4.0], [86.5, 4.0], [86.6, 4.0], [86.7, 4.0], [86.8, 4.0], [86.9, 4.0], [87.0, 4.0], [87.1, 4.0], [87.2, 4.0], [87.3, 4.0], [87.4, 4.0], [87.5, 4.0], [87.6, 4.0], [87.7, 4.0], [87.8, 4.0], [87.9, 4.0], [88.0, 4.0], [88.1, 4.0], [88.2, 4.0], [88.3, 4.0], [88.4, 4.0], [88.5, 4.0], [88.6, 4.0], [88.7, 4.0], [88.8, 4.0], [88.9, 4.0], [89.0, 4.0], [89.1, 4.0], [89.2, 4.0], [89.3, 4.0], [89.4, 4.0], [89.5, 4.0], [89.6, 4.0], [89.7, 4.0], [89.8, 4.0], [89.9, 4.0], [90.0, 4.0], [90.1, 4.0], [90.2, 4.0], [90.3, 4.0], [90.4, 4.0], [90.5, 4.0], [90.6, 4.0], [90.7, 4.0], [90.8, 4.0], [90.9, 4.0], [91.0, 4.0], [91.1, 4.0], [91.2, 4.0], [91.3, 4.0], [91.4, 4.0], [91.5, 4.0], [91.6, 4.0], [91.7, 4.0], [91.8, 4.0], [91.9, 4.0], [92.0, 4.0], [92.1, 4.0], [92.2, 4.0], [92.3, 4.0], [92.4, 4.0], [92.5, 4.0], [92.6, 4.0], [92.7, 4.0], [92.8, 4.0], [92.9, 4.0], [93.0, 4.0], [93.1, 4.0], [93.2, 4.0], [93.3, 4.0], [93.4, 4.0], [93.5, 4.0], [93.6, 4.0], [93.7, 4.0], [93.8, 4.0], [93.9, 4.0], [94.0, 4.0], [94.1, 4.0], [94.2, 4.0], [94.3, 4.0], [94.4, 4.0], [94.5, 4.0], [94.6, 4.0], [94.7, 4.0], [94.8, 4.0], [94.9, 4.0], [95.0, 4.0], [95.1, 4.0], [95.2, 4.0], [95.3, 4.0], [95.4, 4.0], [95.5, 4.0], [95.6, 4.0], [95.7, 4.0], [95.8, 4.0], [95.9, 5.0], [96.0, 5.0], [96.1, 5.0], [96.2, 5.0], [96.3, 5.0], [96.4, 5.0], [96.5, 5.0], [96.6, 5.0], [96.7, 5.0], [96.8, 5.0], [96.9, 5.0], [97.0, 5.0], [97.1, 5.0], [97.2, 5.0], [97.3, 5.0], [97.4, 5.0], [97.5, 5.0], [97.6, 5.0], [97.7, 5.0], [97.8, 5.0], [97.9, 5.0], [98.0, 5.0], [98.1, 5.0], [98.2, 5.0], [98.3, 6.0], [98.4, 6.0], [98.5, 6.0], [98.6, 6.0], [98.7, 6.0], [98.8, 7.0], [98.9, 8.0], [99.0, 9.0], [99.1, 10.0], [99.2, 12.0], [99.3, 13.0], [99.4, 15.0], [99.5, 30.0], [99.6, 43.0], [99.7, 63.0], [99.8, 99.0], [99.9, 132.0]], "isOverall": false, "label": "Tarifas", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 10.0, "minX": 0.0, "maxY": 5437.0, "series": [{"data": [[0.0, 5437.0], [100.0, 10.0]], "isOverall": false, "label": "Tarifas", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 100.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 19.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1.500ms"], [2, "Requests having \nresponse time > 1.500ms"], [3, "Requests in error"]], "maxY": 5428.0, "series": [{"data": [[0.0, 5428.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1.500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1.500ms", "isController": false}, {"data": [[3.0, 19.0]], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 22.1, "minX": 1.794629791E12, "maxY": 100.0, "series": [{"data": [[1.794629804E12, 100.0], [1.794629847E12, 100.0], [1.794629849E12, 33.63636363636364], [1.794629806E12, 100.0], [1.794629808E12, 100.0], [1.79462981E12, 100.0], [1.794629812E12, 100.0], [1.794629814E12, 100.0], [1.794629816E12, 100.0], [1.794629818E12, 100.0], [1.79462982E12, 100.0], [1.794629822E12, 100.0], [1.794629824E12, 100.0], [1.794629826E12, 100.0], [1.794629828E12, 100.0], [1.79462983E12, 100.0], [1.794629832E12, 100.0], [1.794629791E12, 22.1], [1.794629834E12, 100.0], [1.794629793E12, 39.96774193548387], [1.794629836E12, 100.0], [1.794629795E12, 60.4], [1.794629838E12, 100.0], [1.794629797E12, 79.6923076923077], [1.79462984E12, 100.0], [1.794629799E12, 98.79166666666667], [1.794629842E12, 100.0], [1.794629801E12, 100.0], [1.794629844E12, 100.0], [1.794629803E12, 100.0], [1.794629846E12, 100.0], [1.794629805E12, 100.0], [1.794629848E12, 90.81730769230765], [1.794629807E12, 100.0], [1.794629809E12, 100.0], [1.794629811E12, 100.0], [1.794629813E12, 100.0], [1.794629815E12, 100.0], [1.794629817E12, 100.0], [1.794629819E12, 100.0], [1.794629821E12, 100.0], [1.794629823E12, 100.0], [1.794629825E12, 100.0], [1.794629827E12, 100.0], [1.794629829E12, 100.0], [1.794629831E12, 100.0], [1.794629833E12, 100.0], [1.794629792E12, 30.333333333333332], [1.794629835E12, 100.0], [1.794629837E12, 100.0], [1.794629794E12, 50.0], [1.794629796E12, 70.18333333333335], [1.794629839E12, 100.0], [1.794629841E12, 100.0], [1.794629798E12, 89.83516483516483], [1.7946298E12, 100.0], [1.794629843E12, 100.0], [1.794629845E12, 100.0], [1.794629802E12, 100.0]], "isOverall": false, "label": "Usuarios parametrizados - experimentacion", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.794629849E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 1.75, "minX": 1.0, "maxY": 76.63636363636363, "series": [{"data": [[2.0, 3.0], [3.0, 4.0], [4.0, 4.0], [6.0, 4.5], [8.0, 3.5], [9.0, 3.0], [10.0, 3.0], [11.0, 4.0], [12.0, 3.0], [14.0, 3.5], [15.0, 3.0], [16.0, 3.0], [17.0, 2.0], [18.0, 3.0], [19.0, 17.666666666666668], [20.0, 3.0], [21.0, 3.0], [22.0, 3.0], [23.0, 3.0], [24.0, 2.3333333333333335], [25.0, 2.5], [26.0, 3.25], [27.0, 2.25], [28.0, 4.0], [29.0, 3.25], [30.0, 3.0], [31.0, 3.0], [32.0, 4.0], [33.0, 3.0], [34.0, 3.285714285714286], [35.0, 2.2], [36.0, 2.0], [37.0, 3.5], [38.0, 3.5], [39.0, 3.25], [40.0, 2.4285714285714284], [41.0, 1.75], [42.0, 3.25], [43.0, 3.8], [44.0, 2.25], [45.0, 3.0], [46.0, 2.5], [47.0, 2.125], [48.0, 2.6666666666666665], [49.0, 3.8], [50.0, 2.625], [51.0, 3.0], [52.0, 3.5], [53.0, 2.111111111111111], [54.0, 3.0], [55.0, 3.0], [56.0, 2.4000000000000004], [57.0, 3.0], [58.0, 2.5], [59.0, 4.166666666666667], [60.0, 2.6666666666666665], [61.0, 2.3333333333333335], [62.0, 2.25], [63.0, 2.4444444444444446], [64.0, 2.571428571428571], [65.0, 2.333333333333334], [66.0, 2.5], [67.0, 3.8], [68.0, 2.3333333333333335], [69.0, 2.5], [70.0, 3.166666666666667], [71.0, 2.6666666666666665], [72.0, 2.4285714285714284], [73.0, 1.8888888888888888], [74.0, 2.5], [75.0, 2.6999999999999997], [76.0, 2.857142857142857], [77.0, 2.75], [78.0, 2.4000000000000004], [79.0, 2.0], [80.0, 1.9], [81.0, 2.857142857142857], [82.0, 2.7777777777777772], [83.0, 2.5], [84.0, 2.6], [85.0, 13.2], [86.0, 76.63636363636363], [87.0, 25.11111111111111], [88.0, 3.333333333333333], [89.0, 4.071428571428571], [90.0, 3.0833333333333335], [91.0, 2.5], [92.0, 3.0], [93.0, 1.7999999999999998], [94.0, 2.2727272727272734], [95.0, 3.0], [96.0, 2.1999999999999997], [97.0, 2.8888888888888897], [98.0, 2.6], [99.0, 2.5833333333333335], [100.0, 2.7338941321296684], [1.0, 5.0]], "isOverall": false, "label": "Tarifas", "isController": false}, {"data": [[96.53387185606744, 2.947494033412897]], "isOverall": false, "label": "Tarifas-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 1280.0, "minX": 1.794629791E12, "maxY": 64662.0, "series": [{"data": [[1.794629804E12, 44840.0], [1.794629847E12, 47200.0], [1.794629849E12, 31152.0], [1.794629806E12, 43424.0], [1.794629808E12, 48616.0], [1.79462981E12, 43896.0], [1.794629812E12, 44368.0], [1.794629814E12, 44368.0], [1.794629816E12, 50032.0], [1.794629818E12, 46728.0], [1.79462982E12, 62114.0], [1.794629822E12, 45312.0], [1.794629824E12, 49088.0], [1.794629826E12, 46728.0], [1.794629828E12, 43896.0], [1.79462983E12, 49560.0], [1.794629832E12, 43424.0], [1.794629791E12, 4720.0], [1.794629834E12, 43424.0], [1.794629793E12, 14632.0], [1.794629836E12, 49088.0], [1.794629795E12, 30680.0], [1.794629838E12, 48616.0], [1.794629797E12, 35022.0], [1.79462984E12, 49088.0], [1.794629799E12, 45312.0], [1.794629842E12, 46728.0], [1.794629801E12, 44840.0], [1.794629844E12, 47672.0], [1.794629803E12, 47200.0], [1.794629846E12, 45312.0], [1.794629805E12, 50976.0], [1.794629848E12, 49088.0], [1.794629807E12, 47200.0], [1.794629809E12, 48144.0], [1.794629811E12, 51920.0], [1.794629813E12, 45312.0], [1.794629815E12, 43896.0], [1.794629817E12, 43896.0], [1.794629819E12, 47200.0], [1.794629821E12, 47672.0], [1.794629823E12, 44840.0], [1.794629825E12, 48616.0], [1.794629827E12, 50976.0], [1.794629829E12, 47672.0], [1.794629831E12, 55035.0], [1.794629833E12, 48616.0], [1.794629792E12, 12744.0], [1.794629835E12, 47200.0], [1.794629837E12, 47200.0], [1.794629794E12, 21712.0], [1.794629796E12, 28320.0], [1.794629839E12, 46728.0], [1.794629841E12, 43896.0], [1.794629798E12, 64662.0], [1.7946298E12, 49088.0], [1.794629843E12, 49088.0], [1.794629845E12, 46256.0], [1.794629802E12, 47200.0]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.794629804E12, 12160.0], [1.794629847E12, 12800.0], [1.794629849E12, 8448.0], [1.794629806E12, 11776.0], [1.794629808E12, 13184.0], [1.79462981E12, 11904.0], [1.794629812E12, 12032.0], [1.794629814E12, 12032.0], [1.794629816E12, 13568.0], [1.794629818E12, 12672.0], [1.79462982E12, 12544.0], [1.794629822E12, 12288.0], [1.794629824E12, 13312.0], [1.794629826E12, 12672.0], [1.794629828E12, 11904.0], [1.79462983E12, 13440.0], [1.794629832E12, 11776.0], [1.794629791E12, 1280.0], [1.794629834E12, 11776.0], [1.794629793E12, 3968.0], [1.794629836E12, 13312.0], [1.794629795E12, 8320.0], [1.794629838E12, 13184.0], [1.794629797E12, 8064.0], [1.79462984E12, 13312.0], [1.794629799E12, 12288.0], [1.794629842E12, 12672.0], [1.794629801E12, 12160.0], [1.794629844E12, 12928.0], [1.794629803E12, 12800.0], [1.794629846E12, 12288.0], [1.794629805E12, 13824.0], [1.794629848E12, 13312.0], [1.794629807E12, 12800.0], [1.794629809E12, 13056.0], [1.794629811E12, 14080.0], [1.794629813E12, 12288.0], [1.794629815E12, 11904.0], [1.794629817E12, 11904.0], [1.794629819E12, 12800.0], [1.794629821E12, 12928.0], [1.794629823E12, 12160.0], [1.794629825E12, 13184.0], [1.794629827E12, 13824.0], [1.794629829E12, 12928.0], [1.794629831E12, 14208.0], [1.794629833E12, 13184.0], [1.794629792E12, 3456.0], [1.794629835E12, 12800.0], [1.794629837E12, 12800.0], [1.794629794E12, 5888.0], [1.794629796E12, 7680.0], [1.794629839E12, 12672.0], [1.794629841E12, 11904.0], [1.794629798E12, 10368.0], [1.7946298E12, 13312.0], [1.794629843E12, 13312.0], [1.794629845E12, 12544.0], [1.794629802E12, 12800.0]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.794629849E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 1.78494623655914, "minX": 1.794629791E12, "maxY": 14.758241758241754, "series": [{"data": [[1.794629804E12, 2.0421052631578958], [1.794629847E12, 2.96], [1.794629849E12, 3.5757575757575757], [1.794629806E12, 1.9565217391304353], [1.794629808E12, 1.9611650485436887], [1.79462981E12, 1.9569892473118278], [1.794629812E12, 1.9255319148936174], [1.794629814E12, 1.8191489361702127], [1.794629816E12, 1.9056603773584897], [1.794629818E12, 1.787878787878788], [1.79462982E12, 10.500000000000002], [1.794629822E12, 1.927083333333334], [1.794629824E12, 1.990384615384615], [1.794629826E12, 2.01010101010101], [1.794629828E12, 1.8924731182795695], [1.79462983E12, 1.9428571428571424], [1.794629832E12, 3.2282608695652177], [1.794629791E12, 7.1], [1.794629834E12, 3.2500000000000013], [1.794629793E12, 2.6129032258064515], [1.794629836E12, 3.192307692307692], [1.794629795E12, 2.4615384615384612], [1.794629838E12, 3.2912621359223295], [1.794629797E12, 2.261538461538462], [1.79462984E12, 3.5288461538461533], [1.794629799E12, 2.2708333333333335], [1.794629842E12, 3.2929292929292924], [1.794629801E12, 2.315789473684211], [1.794629844E12, 2.9801980198019806], [1.794629803E12, 1.9600000000000009], [1.794629846E12, 3.520833333333334], [1.794629805E12, 2.009259259259259], [1.794629848E12, 3.5673076923076925], [1.794629807E12, 1.8699999999999999], [1.794629809E12, 2.3529411764705888], [1.794629811E12, 1.9636363636363636], [1.794629813E12, 2.0625000000000004], [1.794629815E12, 1.78494623655914], [1.794629817E12, 2.0537634408602155], [1.794629819E12, 1.9399999999999995], [1.794629821E12, 2.108910891089108], [1.794629823E12, 1.9157894736842112], [1.794629825E12, 1.805825242718447], [1.794629827E12, 1.953703703703704], [1.794629829E12, 1.9009900990099005], [1.794629831E12, 6.642857142857143], [1.794629833E12, 3.456310679611652], [1.794629792E12, 2.740740740740741], [1.794629835E12, 3.479999999999999], [1.794629837E12, 3.3499999999999983], [1.794629794E12, 2.543478260869566], [1.794629796E12, 2.483333333333334], [1.794629839E12, 3.707070707070706], [1.794629841E12, 3.602150537634408], [1.794629798E12, 14.758241758241754], [1.7946298E12, 3.096153846153846], [1.794629843E12, 3.1442307692307687], [1.794629845E12, 3.10204081632653], [1.794629802E12, 1.9400000000000002]], "isOverall": false, "label": "Tarifas", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.794629849E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 1.627659574468085, "minX": 1.794629791E12, "maxY": 14.417582417582421, "series": [{"data": [[1.794629804E12, 1.852631578947368], [1.794629847E12, 2.830000000000001], [1.794629849E12, 3.499999999999999], [1.794629806E12, 1.8586956521739129], [1.794629808E12, 1.8252427184466018], [1.79462981E12, 1.860215053763441], [1.794629812E12, 1.7234042553191493], [1.794629814E12, 1.627659574468085], [1.794629816E12, 1.6415094339622638], [1.794629818E12, 1.6565656565656566], [1.79462982E12, 10.298076923076927], [1.794629822E12, 1.7708333333333335], [1.794629824E12, 1.8653846153846156], [1.794629826E12, 1.8484848484848486], [1.794629828E12, 1.6989247311827962], [1.79462983E12, 1.8095238095238095], [1.794629832E12, 2.9782608695652164], [1.794629791E12, 6.6], [1.794629834E12, 3.0434782608695645], [1.794629793E12, 2.322580645161291], [1.794629836E12, 3.067307692307693], [1.794629795E12, 2.3230769230769237], [1.794629838E12, 3.0679611650485445], [1.794629797E12, 2.046153846153847], [1.79462984E12, 3.288461538461539], [1.794629799E12, 2.1041666666666683], [1.794629842E12, 3.08080808080808], [1.794629801E12, 2.2000000000000006], [1.794629844E12, 2.7821782178217824], [1.794629803E12, 1.7399999999999998], [1.794629846E12, 3.177083333333334], [1.794629805E12, 1.8425925925925921], [1.794629848E12, 3.317307692307692], [1.794629807E12, 1.7], [1.794629809E12, 2.254901960784315], [1.794629811E12, 1.8545454545454547], [1.794629813E12, 1.958333333333333], [1.794629815E12, 1.645161290322581], [1.794629817E12, 1.8709677419354838], [1.794629819E12, 1.74], [1.794629821E12, 1.9702970297029707], [1.794629823E12, 1.8], [1.794629825E12, 1.6893203883495147], [1.794629827E12, 1.8425925925925926], [1.794629829E12, 1.7623762376237624], [1.794629831E12, 6.517857142857143], [1.794629833E12, 3.233009708737862], [1.794629792E12, 2.3703703703703707], [1.794629835E12, 3.2999999999999994], [1.794629837E12, 3.0399999999999996], [1.794629794E12, 2.2608695652173907], [1.794629796E12, 2.266666666666667], [1.794629839E12, 3.5252525252525255], [1.794629841E12, 3.3763440860215055], [1.794629798E12, 14.417582417582421], [1.7946298E12, 2.932692307692307], [1.794629843E12, 2.951923076923077], [1.794629845E12, 2.8265306122448983], [1.794629802E12, 1.8299999999999998]], "isOverall": false, "label": "Tarifas", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.794629849E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.6600000000000004, "minX": 1.794629791E12, "maxY": 4.699999999999999, "series": [{"data": [[1.794629804E12, 0.8105263157894737], [1.794629847E12, 1.3800000000000003], [1.794629849E12, 1.6818181818181819], [1.794629806E12, 0.7717391304347827], [1.794629808E12, 0.7766990291262135], [1.79462981E12, 0.8172043010752688], [1.794629812E12, 0.7127659574468083], [1.794629814E12, 0.8085106382978722], [1.794629816E12, 0.6792452830188678], [1.794629818E12, 0.6767676767676764], [1.79462982E12, 0.7788461538461537], [1.794629822E12, 0.7395833333333333], [1.794629824E12, 0.8846153846153842], [1.794629826E12, 0.8484848484848487], [1.794629828E12, 0.7956989247311829], [1.79462983E12, 0.8000000000000002], [1.794629832E12, 1.3586956521739135], [1.794629791E12, 4.699999999999999], [1.794629834E12, 1.4456521739130437], [1.794629793E12, 1.1935483870967742], [1.794629836E12, 1.4134615384615385], [1.794629795E12, 1.1076923076923075], [1.794629838E12, 1.4466019417475726], [1.794629797E12, 1.1384615384615389], [1.79462984E12, 1.3269230769230778], [1.794629799E12, 0.9374999999999999], [1.794629842E12, 1.3535353535353534], [1.794629801E12, 1.0736842105263158], [1.794629844E12, 1.3168316831683164], [1.794629803E12, 0.6699999999999999], [1.794629846E12, 1.3749999999999993], [1.794629805E12, 0.7222222222222219], [1.794629848E12, 1.4519230769230775], [1.794629807E12, 0.6600000000000004], [1.794629809E12, 0.9803921568627452], [1.794629811E12, 0.8090909090909093], [1.794629813E12, 0.8437500000000002], [1.794629815E12, 0.7311827956989246], [1.794629817E12, 0.7956989247311826], [1.794629819E12, 0.8600000000000002], [1.794629821E12, 0.8316831683168319], [1.794629823E12, 0.8210526315789474], [1.794629825E12, 0.766990291262136], [1.794629827E12, 0.7685185185185182], [1.794629829E12, 0.7524752475247526], [1.794629831E12, 1.2321428571428574], [1.794629833E12, 1.4854368932038833], [1.794629792E12, 1.2592592592592595], [1.794629835E12, 1.4300000000000002], [1.794629837E12, 1.4300000000000002], [1.794629794E12, 1.1304347826086958], [1.794629796E12, 1.116666666666667], [1.794629839E12, 1.4141414141414141], [1.794629841E12, 1.4516129032258063], [1.794629798E12, 1.2747252747252744], [1.7946298E12, 1.3076923076923077], [1.794629843E12, 1.230769230769231], [1.794629845E12, 1.3469387755102042], [1.794629802E12, 0.8699999999999996]], "isOverall": false, "label": "Tarifas", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.794629849E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.794629791E12, "maxY": 180.0, "series": [{"data": [[1.794629804E12, 3.0], [1.794629847E12, 4.0], [1.794629849E12, 6.0], [1.794629806E12, 5.0], [1.794629808E12, 6.0], [1.79462981E12, 3.0], [1.794629812E12, 3.0], [1.794629814E12, 3.0], [1.794629816E12, 3.0], [1.794629818E12, 3.0], [1.79462982E12, 132.0], [1.794629822E12, 3.0], [1.794629824E12, 4.0], [1.794629826E12, 3.0], [1.794629828E12, 3.0], [1.79462983E12, 3.0], [1.794629832E12, 9.0], [1.794629791E12, 34.0], [1.794629834E12, 5.0], [1.794629793E12, 4.0], [1.794629836E12, 5.0], [1.794629795E12, 7.0], [1.794629838E12, 5.0], [1.794629797E12, 4.0], [1.79462984E12, 7.0], [1.794629799E12, 4.0], [1.794629842E12, 6.0], [1.794629801E12, 8.0], [1.794629844E12, 6.0], [1.794629803E12, 4.0], [1.794629846E12, 12.0], [1.794629805E12, 3.0], [1.794629848E12, 10.0], [1.794629807E12, 3.0], [1.794629809E12, 9.0], [1.794629811E12, 4.0], [1.794629813E12, 4.0], [1.794629815E12, 4.0], [1.794629817E12, 4.0], [1.794629819E12, 4.0], [1.794629821E12, 4.0], [1.794629823E12, 3.0], [1.794629825E12, 3.0], [1.794629827E12, 4.0], [1.794629829E12, 3.0], [1.794629831E12, 63.0], [1.794629833E12, 13.0], [1.794629792E12, 4.0], [1.794629835E12, 7.0], [1.794629837E12, 5.0], [1.794629794E12, 4.0], [1.794629796E12, 9.0], [1.794629839E12, 13.0], [1.794629841E12, 6.0], [1.794629798E12, 180.0], [1.7946298E12, 12.0], [1.794629843E12, 5.0], [1.794629845E12, 6.0], [1.794629802E12, 4.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.794629804E12, 1.0], [1.794629847E12, 1.0], [1.794629849E12, 2.0], [1.794629806E12, 1.0], [1.794629808E12, 1.0], [1.79462981E12, 1.0], [1.794629812E12, 1.0], [1.794629814E12, 1.0], [1.794629816E12, 1.0], [1.794629818E12, 1.0], [1.79462982E12, 1.0], [1.794629822E12, 1.0], [1.794629824E12, 1.0], [1.794629826E12, 1.0], [1.794629828E12, 1.0], [1.79462983E12, 1.0], [1.794629832E12, 2.0], [1.794629791E12, 2.0], [1.794629834E12, 1.0], [1.794629793E12, 1.0], [1.794629836E12, 1.0], [1.794629795E12, 2.0], [1.794629838E12, 2.0], [1.794629797E12, 1.0], [1.79462984E12, 2.0], [1.794629799E12, 1.0], [1.794629842E12, 1.0], [1.794629801E12, 1.0], [1.794629844E12, 1.0], [1.794629803E12, 1.0], [1.794629846E12, 1.0], [1.794629805E12, 1.0], [1.794629848E12, 2.0], [1.794629807E12, 1.0], [1.794629809E12, 1.0], [1.794629811E12, 1.0], [1.794629813E12, 1.0], [1.794629815E12, 1.0], [1.794629817E12, 1.0], [1.794629819E12, 1.0], [1.794629821E12, 1.0], [1.794629823E12, 1.0], [1.794629825E12, 1.0], [1.794629827E12, 1.0], [1.794629829E12, 0.0], [1.794629831E12, 1.0], [1.794629833E12, 2.0], [1.794629792E12, 1.0], [1.794629835E12, 1.0], [1.794629837E12, 2.0], [1.794629794E12, 1.0], [1.794629796E12, 1.0], [1.794629839E12, 2.0], [1.794629841E12, 1.0], [1.794629798E12, 1.0], [1.7946298E12, 1.0], [1.794629843E12, 1.0], [1.794629845E12, 1.0], [1.794629802E12, 1.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.794629804E12, 3.0], [1.794629847E12, 4.0], [1.794629849E12, 5.0], [1.794629806E12, 3.0], [1.794629808E12, 3.0], [1.79462981E12, 3.0], [1.794629812E12, 3.0], [1.794629814E12, 3.0], [1.794629816E12, 3.0], [1.794629818E12, 3.0], [1.79462982E12, 38.300000000000026], [1.794629822E12, 3.0], [1.794629824E12, 3.0], [1.794629826E12, 3.0], [1.794629828E12, 3.0], [1.79462983E12, 3.0], [1.794629832E12, 4.0], [1.794629791E12, 32.10000000000001], [1.794629834E12, 4.0], [1.794629793E12, 4.0], [1.794629836E12, 4.0], [1.794629795E12, 3.0], [1.794629838E12, 4.0], [1.794629797E12, 3.0], [1.79462984E12, 5.0], [1.794629799E12, 3.0], [1.794629842E12, 5.0], [1.794629801E12, 3.0], [1.794629844E12, 4.0], [1.794629803E12, 3.0], [1.794629846E12, 5.0], [1.794629805E12, 3.0], [1.794629848E12, 5.0], [1.794629807E12, 3.0], [1.794629809E12, 3.0], [1.794629811E12, 3.0], [1.794629813E12, 3.0], [1.794629815E12, 3.0], [1.794629817E12, 3.0], [1.794629819E12, 3.0], [1.794629821E12, 3.0], [1.794629823E12, 3.0], [1.794629825E12, 3.0], [1.794629827E12, 3.0], [1.794629829E12, 3.0], [1.794629831E12, 15.799999999999997], [1.794629833E12, 4.0], [1.794629792E12, 4.0], [1.794629835E12, 5.0], [1.794629837E12, 4.0], [1.794629794E12, 4.0], [1.794629796E12, 3.0], [1.794629839E12, 4.0], [1.794629841E12, 5.0], [1.794629798E12, 69.19999999999983], [1.7946298E12, 4.0], [1.794629843E12, 4.0], [1.794629845E12, 4.0], [1.794629802E12, 3.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.794629804E12, 3.0], [1.794629847E12, 4.0], [1.794629849E12, 6.0], [1.794629806E12, 5.0], [1.794629808E12, 5.9199999999999875], [1.79462981E12, 3.0], [1.794629812E12, 3.0], [1.794629814E12, 3.0], [1.794629816E12, 3.0], [1.794629818E12, 3.0], [1.79462982E12, 132.0], [1.794629822E12, 3.0], [1.794629824E12, 4.0], [1.794629826E12, 3.0], [1.794629828E12, 3.0], [1.79462983E12, 3.0], [1.794629832E12, 9.0], [1.794629791E12, 34.0], [1.794629834E12, 5.0], [1.794629793E12, 4.0], [1.794629836E12, 5.0], [1.794629795E12, 7.0], [1.794629838E12, 5.0], [1.794629797E12, 4.0], [1.79462984E12, 7.0], [1.794629799E12, 4.0], [1.794629842E12, 6.0], [1.794629801E12, 8.0], [1.794629844E12, 5.980000000000004], [1.794629803E12, 4.0], [1.794629846E12, 12.0], [1.794629805E12, 3.0], [1.794629848E12, 9.950000000000003], [1.794629807E12, 3.0], [1.794629809E12, 9.0], [1.794629811E12, 4.0], [1.794629813E12, 4.0], [1.794629815E12, 4.0], [1.794629817E12, 4.0], [1.794629819E12, 3.989999999999995], [1.794629821E12, 4.0], [1.794629823E12, 3.0], [1.794629825E12, 3.0], [1.794629827E12, 4.0], [1.794629829E12, 3.0], [1.794629831E12, 63.0], [1.794629833E12, 12.759999999999962], [1.794629792E12, 4.0], [1.794629835E12, 6.989999999999995], [1.794629837E12, 5.0], [1.794629794E12, 4.0], [1.794629796E12, 9.0], [1.794629839E12, 13.0], [1.794629841E12, 6.0], [1.794629798E12, 180.0], [1.7946298E12, 11.950000000000003], [1.794629843E12, 5.0], [1.794629845E12, 6.0], [1.794629802E12, 3.989999999999995]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.794629804E12, 2.0], [1.794629847E12, 3.0], [1.794629849E12, 3.5], [1.794629806E12, 2.0], [1.794629808E12, 2.0], [1.79462981E12, 2.0], [1.794629812E12, 2.0], [1.794629814E12, 2.0], [1.794629816E12, 2.0], [1.794629818E12, 2.0], [1.79462982E12, 2.0], [1.794629822E12, 2.0], [1.794629824E12, 2.0], [1.794629826E12, 2.0], [1.794629828E12, 2.0], [1.79462983E12, 2.0], [1.794629832E12, 3.0], [1.794629791E12, 3.0], [1.794629834E12, 3.0], [1.794629793E12, 2.0], [1.794629836E12, 3.0], [1.794629795E12, 2.0], [1.794629838E12, 3.0], [1.794629797E12, 2.0], [1.79462984E12, 3.0], [1.794629799E12, 2.0], [1.794629842E12, 3.0], [1.794629801E12, 2.0], [1.794629844E12, 3.0], [1.794629803E12, 2.0], [1.794629846E12, 3.0], [1.794629805E12, 2.0], [1.794629848E12, 3.0], [1.794629807E12, 2.0], [1.794629809E12, 2.0], [1.794629811E12, 2.0], [1.794629813E12, 2.0], [1.794629815E12, 2.0], [1.794629817E12, 2.0], [1.794629819E12, 2.0], [1.794629821E12, 2.0], [1.794629823E12, 2.0], [1.794629825E12, 2.0], [1.794629827E12, 2.0], [1.794629829E12, 2.0], [1.794629831E12, 2.0], [1.794629833E12, 3.0], [1.794629792E12, 3.0], [1.794629835E12, 3.0], [1.794629837E12, 3.0], [1.794629794E12, 2.0], [1.794629796E12, 2.0], [1.794629839E12, 3.0], [1.794629841E12, 4.0], [1.794629798E12, 2.0], [1.7946298E12, 3.0], [1.794629843E12, 3.0], [1.794629845E12, 3.0], [1.794629802E12, 2.0]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.794629804E12, 3.0], [1.794629847E12, 4.0], [1.794629849E12, 5.0], [1.794629806E12, 3.0], [1.794629808E12, 3.0], [1.79462981E12, 3.0], [1.794629812E12, 3.0], [1.794629814E12, 3.0], [1.794629816E12, 3.0], [1.794629818E12, 3.0], [1.79462982E12, 99.64999999999996], [1.794629822E12, 3.0], [1.794629824E12, 3.0], [1.794629826E12, 3.0], [1.794629828E12, 3.0], [1.79462983E12, 3.0], [1.794629832E12, 4.349999999999994], [1.794629791E12, 34.0], [1.794629834E12, 4.349999999999994], [1.794629793E12, 4.0], [1.794629836E12, 5.0], [1.794629795E12, 3.6999999999999957], [1.794629838E12, 5.0], [1.794629797E12, 3.799999999999997], [1.79462984E12, 5.75], [1.794629799E12, 3.0], [1.794629842E12, 5.0], [1.794629801E12, 3.0], [1.794629844E12, 5.0], [1.794629803E12, 3.0], [1.794629846E12, 6.0], [1.794629805E12, 3.0], [1.794629848E12, 5.75], [1.794629807E12, 3.0], [1.794629809E12, 4.0], [1.794629811E12, 3.0], [1.794629813E12, 3.0], [1.794629815E12, 3.0], [1.794629817E12, 3.0], [1.794629819E12, 3.0], [1.794629821E12, 3.0], [1.794629823E12, 3.0], [1.794629825E12, 3.0], [1.794629827E12, 4.0], [1.794629829E12, 3.0], [1.794629831E12, 45.39999999999995], [1.794629833E12, 5.0], [1.794629792E12, 4.0], [1.794629835E12, 5.0], [1.794629837E12, 5.0], [1.794629794E12, 4.0], [1.794629796E12, 4.0], [1.794629839E12, 8.0], [1.794629841E12, 5.0], [1.794629798E12, 153.99999999999983], [1.7946298E12, 5.75], [1.794629843E12, 5.0], [1.794629845E12, 4.049999999999997], [1.794629802E12, 3.0]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.794629849E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 1.0, "minX": 10.0, "maxY": 3.5, "series": [{"data": [[46.0, 2.0], [60.0, 2.0], [65.0, 2.0], [66.0, 3.5], [91.0, 2.0], [95.0, 2.0], [92.0, 3.0], [93.0, 2.0], [94.0, 2.0], [96.0, 2.0], [99.0, 3.0], [98.0, 3.0], [100.0, 2.0], [103.0, 2.0], [102.0, 2.0], [101.0, 2.0], [104.0, 3.0], [106.0, 2.0], [105.0, 2.0], [108.0, 2.0], [110.0, 2.0], [112.0, 2.0], [10.0, 3.0], [27.0, 3.0], [31.0, 2.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[65.0, 2.5], [91.0, 1.5], [104.0, 1.0], [112.0, 2.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 112.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 0.0, "minX": 10.0, "maxY": 3.0, "series": [{"data": [[46.0, 2.0], [60.0, 2.0], [65.0, 2.0], [66.0, 3.0], [91.0, 2.0], [95.0, 2.0], [92.0, 3.0], [93.0, 2.0], [94.0, 2.0], [96.0, 2.0], [99.0, 2.0], [98.0, 3.0], [100.0, 2.0], [103.0, 2.0], [102.0, 2.0], [101.0, 2.0], [104.0, 3.0], [106.0, 2.0], [105.0, 2.0], [108.0, 2.0], [110.0, 2.0], [112.0, 2.0], [10.0, 2.5], [27.0, 2.0], [31.0, 2.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[65.0, 0.0], [91.0, 0.0], [104.0, 0.0], [112.0, 0.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 112.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 10.0, "minX": 1.794629791E12, "maxY": 112.0, "series": [{"data": [[1.794629804E12, 95.0], [1.794629847E12, 100.0], [1.794629849E12, 66.0], [1.794629806E12, 93.0], [1.794629808E12, 102.0], [1.79462981E12, 94.0], [1.794629812E12, 94.0], [1.794629814E12, 94.0], [1.794629816E12, 105.0], [1.794629818E12, 99.0], [1.79462982E12, 105.0], [1.794629822E12, 96.0], [1.794629824E12, 105.0], [1.794629826E12, 100.0], [1.794629828E12, 93.0], [1.79462983E12, 104.0], [1.794629832E12, 92.0], [1.794629791E12, 10.0], [1.794629834E12, 94.0], [1.794629793E12, 31.0], [1.794629836E12, 103.0], [1.794629795E12, 65.0], [1.794629838E12, 103.0], [1.794629797E12, 71.0], [1.79462984E12, 104.0], [1.794629799E12, 96.0], [1.794629842E12, 99.0], [1.794629801E12, 95.0], [1.794629844E12, 101.0], [1.794629803E12, 100.0], [1.794629846E12, 96.0], [1.794629805E12, 108.0], [1.794629848E12, 104.0], [1.794629807E12, 100.0], [1.794629809E12, 102.0], [1.794629811E12, 109.0], [1.794629813E12, 96.0], [1.794629815E12, 94.0], [1.794629817E12, 93.0], [1.794629819E12, 100.0], [1.794629821E12, 100.0], [1.794629823E12, 95.0], [1.794629825E12, 102.0], [1.794629827E12, 107.0], [1.794629829E12, 102.0], [1.794629831E12, 112.0], [1.794629833E12, 103.0], [1.794629792E12, 27.0], [1.794629835E12, 99.0], [1.794629837E12, 100.0], [1.794629794E12, 46.0], [1.794629796E12, 60.0], [1.794629839E12, 99.0], [1.794629841E12, 93.0], [1.794629798E12, 85.0], [1.7946298E12, 104.0], [1.794629843E12, 104.0], [1.794629845E12, 98.0], [1.794629802E12, 100.0]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.794629849E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 1.0, "minX": 1.794629791E12, "maxY": 111.0, "series": [{"data": [[1.794629804E12, 95.0], [1.794629847E12, 100.0], [1.794629849E12, 66.0], [1.794629806E12, 92.0], [1.794629808E12, 103.0], [1.79462981E12, 93.0], [1.794629812E12, 94.0], [1.794629814E12, 94.0], [1.794629816E12, 106.0], [1.794629818E12, 99.0], [1.79462982E12, 98.0], [1.794629822E12, 96.0], [1.794629824E12, 104.0], [1.794629826E12, 99.0], [1.794629828E12, 93.0], [1.79462983E12, 105.0], [1.794629832E12, 92.0], [1.794629791E12, 10.0], [1.794629834E12, 92.0], [1.794629793E12, 31.0], [1.794629836E12, 104.0], [1.794629795E12, 65.0], [1.794629838E12, 103.0], [1.794629797E12, 63.0], [1.79462984E12, 104.0], [1.794629799E12, 96.0], [1.794629842E12, 99.0], [1.794629801E12, 95.0], [1.794629844E12, 101.0], [1.794629803E12, 100.0], [1.794629846E12, 96.0], [1.794629805E12, 108.0], [1.794629848E12, 104.0], [1.794629807E12, 100.0], [1.794629809E12, 102.0], [1.794629811E12, 110.0], [1.794629813E12, 96.0], [1.794629815E12, 93.0], [1.794629817E12, 93.0], [1.794629819E12, 100.0], [1.794629821E12, 101.0], [1.794629823E12, 95.0], [1.794629825E12, 103.0], [1.794629827E12, 108.0], [1.794629829E12, 101.0], [1.794629831E12, 111.0], [1.794629833E12, 103.0], [1.794629792E12, 27.0], [1.794629835E12, 100.0], [1.794629837E12, 100.0], [1.794629794E12, 46.0], [1.794629796E12, 60.0], [1.794629839E12, 99.0], [1.794629841E12, 93.0], [1.794629798E12, 81.0], [1.7946298E12, 104.0], [1.794629843E12, 104.0], [1.794629845E12, 98.0], [1.794629802E12, 100.0]], "isOverall": false, "label": "200", "isController": false}, {"data": [[1.794629797E12, 2.0], [1.79462982E12, 6.0], [1.794629798E12, 10.0], [1.794629831E12, 1.0]], "isOverall": false, "label": "Non HTTP response code: org.apache.http.conn.HttpHostConnectException", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.794629849E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 1.0, "minX": 1.794629791E12, "maxY": 111.0, "series": [{"data": [[1.794629797E12, 2.0], [1.79462982E12, 6.0], [1.794629798E12, 10.0], [1.794629831E12, 1.0]], "isOverall": false, "label": "Tarifas-failure", "isController": false}, {"data": [[1.794629804E12, 95.0], [1.794629847E12, 100.0], [1.794629849E12, 66.0], [1.794629806E12, 92.0], [1.794629808E12, 103.0], [1.79462981E12, 93.0], [1.794629812E12, 94.0], [1.794629814E12, 94.0], [1.794629816E12, 106.0], [1.794629818E12, 99.0], [1.79462982E12, 98.0], [1.794629822E12, 96.0], [1.794629824E12, 104.0], [1.794629826E12, 99.0], [1.794629828E12, 93.0], [1.79462983E12, 105.0], [1.794629832E12, 92.0], [1.794629791E12, 10.0], [1.794629834E12, 92.0], [1.794629793E12, 31.0], [1.794629836E12, 104.0], [1.794629795E12, 65.0], [1.794629838E12, 103.0], [1.794629797E12, 63.0], [1.79462984E12, 104.0], [1.794629799E12, 96.0], [1.794629842E12, 99.0], [1.794629801E12, 95.0], [1.794629844E12, 101.0], [1.794629803E12, 100.0], [1.794629846E12, 96.0], [1.794629805E12, 108.0], [1.794629848E12, 104.0], [1.794629807E12, 100.0], [1.794629809E12, 102.0], [1.794629811E12, 110.0], [1.794629813E12, 96.0], [1.794629815E12, 93.0], [1.794629817E12, 93.0], [1.794629819E12, 100.0], [1.794629821E12, 101.0], [1.794629823E12, 95.0], [1.794629825E12, 103.0], [1.794629827E12, 108.0], [1.794629829E12, 101.0], [1.794629831E12, 111.0], [1.794629833E12, 103.0], [1.794629792E12, 27.0], [1.794629835E12, 100.0], [1.794629837E12, 100.0], [1.794629794E12, 46.0], [1.794629796E12, 60.0], [1.794629839E12, 99.0], [1.794629841E12, 93.0], [1.794629798E12, 81.0], [1.7946298E12, 104.0], [1.794629843E12, 104.0], [1.794629845E12, 98.0], [1.794629802E12, 100.0]], "isOverall": false, "label": "Tarifas-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.794629849E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 1.0, "minX": 1.794629791E12, "maxY": 111.0, "series": [{"data": [[1.794629804E12, 95.0], [1.794629847E12, 100.0], [1.794629849E12, 66.0], [1.794629806E12, 92.0], [1.794629808E12, 103.0], [1.79462981E12, 93.0], [1.794629812E12, 94.0], [1.794629814E12, 94.0], [1.794629816E12, 106.0], [1.794629818E12, 99.0], [1.79462982E12, 98.0], [1.794629822E12, 96.0], [1.794629824E12, 104.0], [1.794629826E12, 99.0], [1.794629828E12, 93.0], [1.79462983E12, 105.0], [1.794629832E12, 92.0], [1.794629791E12, 10.0], [1.794629834E12, 92.0], [1.794629793E12, 31.0], [1.794629836E12, 104.0], [1.794629795E12, 65.0], [1.794629838E12, 103.0], [1.794629797E12, 63.0], [1.79462984E12, 104.0], [1.794629799E12, 96.0], [1.794629842E12, 99.0], [1.794629801E12, 95.0], [1.794629844E12, 101.0], [1.794629803E12, 100.0], [1.794629846E12, 96.0], [1.794629805E12, 108.0], [1.794629848E12, 104.0], [1.794629807E12, 100.0], [1.794629809E12, 102.0], [1.794629811E12, 110.0], [1.794629813E12, 96.0], [1.794629815E12, 93.0], [1.794629817E12, 93.0], [1.794629819E12, 100.0], [1.794629821E12, 101.0], [1.794629823E12, 95.0], [1.794629825E12, 103.0], [1.794629827E12, 108.0], [1.794629829E12, 101.0], [1.794629831E12, 111.0], [1.794629833E12, 103.0], [1.794629792E12, 27.0], [1.794629835E12, 100.0], [1.794629837E12, 100.0], [1.794629794E12, 46.0], [1.794629796E12, 60.0], [1.794629839E12, 99.0], [1.794629841E12, 93.0], [1.794629798E12, 81.0], [1.7946298E12, 104.0], [1.794629843E12, 104.0], [1.794629845E12, 98.0], [1.794629802E12, 100.0]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [[1.794629797E12, 2.0], [1.79462982E12, 6.0], [1.794629798E12, 10.0], [1.794629831E12, 1.0]], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.794629849E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

