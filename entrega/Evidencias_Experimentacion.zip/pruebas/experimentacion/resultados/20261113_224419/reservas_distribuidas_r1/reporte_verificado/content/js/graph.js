/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 65.0, "minX": 0.0, "maxY": 558.0, "series": [{"data": [[0.0, 65.0], [0.1, 65.0], [0.2, 66.0], [0.3, 66.0], [0.4, 77.0], [0.5, 77.0], [0.6, 77.0], [0.7, 89.0], [0.8, 102.0], [0.9, 102.0], [1.0, 106.0], [1.1, 106.0], [1.2, 108.0], [1.3, 108.0], [1.4, 108.0], [1.5, 108.0], [1.6, 110.0], [1.7, 110.0], [1.8, 111.0], [1.9, 111.0], [2.0, 112.0], [2.1, 112.0], [2.2, 113.0], [2.3, 113.0], [2.4, 113.0], [2.5, 114.0], [2.6, 114.0], [2.7, 117.0], [2.8, 117.0], [2.9, 117.0], [3.0, 117.0], [3.1, 118.0], [3.2, 118.0], [3.3, 118.0], [3.4, 118.0], [3.5, 118.0], [3.6, 118.0], [3.7, 119.0], [3.8, 119.0], [3.9, 119.0], [4.0, 119.0], [4.1, 119.0], [4.2, 120.0], [4.3, 120.0], [4.4, 120.0], [4.5, 120.0], [4.6, 120.0], [4.7, 120.0], [4.8, 120.0], [4.9, 120.0], [5.0, 121.0], [5.1, 121.0], [5.2, 121.0], [5.3, 121.0], [5.4, 122.0], [5.5, 122.0], [5.6, 122.0], [5.7, 122.0], [5.8, 122.0], [5.9, 123.0], [6.0, 123.0], [6.1, 124.0], [6.2, 124.0], [6.3, 124.0], [6.4, 124.0], [6.5, 125.0], [6.6, 125.0], [6.7, 129.0], [6.8, 129.0], [6.9, 153.0], [7.0, 153.0], [7.1, 166.0], [7.2, 166.0], [7.3, 166.0], [7.4, 166.0], [7.5, 178.0], [7.6, 178.0], [7.7, 186.0], [7.8, 186.0], [7.9, 203.0], [8.0, 203.0], [8.1, 207.0], [8.2, 207.0], [8.3, 213.0], [8.4, 220.0], [8.5, 220.0], [8.6, 228.0], [8.7, 228.0], [8.8, 231.0], [8.9, 231.0], [9.0, 231.0], [9.1, 231.0], [9.2, 232.0], [9.3, 232.0], [9.4, 241.0], [9.5, 241.0], [9.6, 242.0], [9.7, 242.0], [9.8, 246.0], [9.9, 246.0], [10.0, 246.0], [10.1, 246.0], [10.2, 263.0], [10.3, 263.0], [10.4, 266.0], [10.5, 266.0], [10.6, 272.0], [10.7, 272.0], [10.8, 283.0], [10.9, 283.0], [11.0, 285.0], [11.1, 285.0], [11.2, 291.0], [11.3, 291.0], [11.4, 292.0], [11.5, 292.0], [11.6, 294.0], [11.7, 294.0], [11.8, 295.0], [11.9, 295.0], [12.0, 297.0], [12.1, 297.0], [12.2, 303.0], [12.3, 303.0], [12.4, 303.0], [12.5, 303.0], [12.6, 305.0], [12.7, 305.0], [12.8, 308.0], [12.9, 308.0], [13.0, 308.0], [13.1, 308.0], [13.2, 309.0], [13.3, 309.0], [13.4, 309.0], [13.5, 309.0], [13.6, 311.0], [13.7, 311.0], [13.8, 312.0], [13.9, 312.0], [14.0, 312.0], [14.1, 312.0], [14.2, 313.0], [14.3, 313.0], [14.4, 313.0], [14.5, 313.0], [14.6, 313.0], [14.7, 313.0], [14.8, 314.0], [14.9, 314.0], [15.0, 314.0], [15.1, 314.0], [15.2, 315.0], [15.3, 315.0], [15.4, 315.0], [15.5, 315.0], [15.6, 316.0], [15.7, 316.0], [15.8, 318.0], [15.9, 318.0], [16.0, 319.0], [16.1, 319.0], [16.2, 320.0], [16.3, 320.0], [16.4, 320.0], [16.5, 320.0], [16.6, 320.0], [16.7, 320.0], [16.8, 321.0], [16.9, 321.0], [17.0, 322.0], [17.1, 322.0], [17.2, 322.0], [17.3, 322.0], [17.4, 323.0], [17.5, 323.0], [17.6, 324.0], [17.7, 324.0], [17.8, 325.0], [17.9, 325.0], [18.0, 326.0], [18.1, 326.0], [18.2, 326.0], [18.3, 326.0], [18.4, 327.0], [18.5, 327.0], [18.6, 328.0], [18.7, 328.0], [18.8, 329.0], [18.9, 329.0], [19.0, 329.0], [19.1, 329.0], [19.2, 332.0], [19.3, 332.0], [19.4, 333.0], [19.5, 333.0], [19.6, 334.0], [19.7, 334.0], [19.8, 335.0], [19.9, 335.0], [20.0, 337.0], [20.1, 337.0], [20.2, 337.0], [20.3, 337.0], [20.4, 339.0], [20.5, 339.0], [20.6, 339.0], [20.7, 339.0], [20.8, 340.0], [20.9, 340.0], [21.0, 341.0], [21.1, 341.0], [21.2, 341.0], [21.3, 341.0], [21.4, 342.0], [21.5, 342.0], [21.6, 346.0], [21.7, 346.0], [21.8, 348.0], [21.9, 348.0], [22.0, 349.0], [22.1, 349.0], [22.2, 350.0], [22.3, 350.0], [22.4, 350.0], [22.5, 350.0], [22.6, 350.0], [22.7, 350.0], [22.8, 350.0], [22.9, 350.0], [23.0, 351.0], [23.1, 351.0], [23.2, 351.0], [23.3, 351.0], [23.4, 351.0], [23.5, 351.0], [23.6, 351.0], [23.7, 351.0], [23.8, 351.0], [23.9, 351.0], [24.0, 351.0], [24.1, 351.0], [24.2, 352.0], [24.3, 352.0], [24.4, 352.0], [24.5, 352.0], [24.6, 352.0], [24.7, 352.0], [24.8, 352.0], [24.9, 352.0], [25.0, 352.0], [25.1, 352.0], [25.2, 352.0], [25.3, 352.0], [25.4, 352.0], [25.5, 352.0], [25.6, 352.0], [25.7, 352.0], [25.8, 352.0], [25.9, 352.0], [26.0, 352.0], [26.1, 352.0], [26.2, 352.0], [26.3, 352.0], [26.4, 352.0], [26.5, 352.0], [26.6, 353.0], [26.7, 353.0], [26.8, 353.0], [26.9, 353.0], [27.0, 353.0], [27.1, 353.0], [27.2, 353.0], [27.3, 353.0], [27.4, 353.0], [27.5, 353.0], [27.6, 353.0], [27.7, 353.0], [27.8, 353.0], [27.9, 353.0], [28.0, 353.0], [28.1, 353.0], [28.2, 353.0], [28.3, 353.0], [28.4, 353.0], [28.5, 353.0], [28.6, 354.0], [28.7, 354.0], [28.8, 354.0], [28.9, 354.0], [29.0, 354.0], [29.1, 354.0], [29.2, 354.0], [29.3, 354.0], [29.4, 354.0], [29.5, 354.0], [29.6, 354.0], [29.7, 354.0], [29.8, 354.0], [29.9, 354.0], [30.0, 354.0], [30.1, 354.0], [30.2, 355.0], [30.3, 355.0], [30.4, 355.0], [30.5, 355.0], [30.6, 355.0], [30.7, 355.0], [30.8, 355.0], [30.9, 355.0], [31.0, 355.0], [31.1, 355.0], [31.2, 355.0], [31.3, 355.0], [31.4, 356.0], [31.5, 356.0], [31.6, 356.0], [31.7, 356.0], [31.8, 356.0], [31.9, 356.0], [32.0, 356.0], [32.1, 356.0], [32.2, 356.0], [32.3, 356.0], [32.4, 356.0], [32.5, 356.0], [32.6, 356.0], [32.7, 356.0], [32.8, 356.0], [32.9, 356.0], [33.0, 356.0], [33.1, 356.0], [33.2, 357.0], [33.3, 357.0], [33.4, 357.0], [33.5, 357.0], [33.6, 357.0], [33.7, 357.0], [33.8, 357.0], [33.9, 357.0], [34.0, 357.0], [34.1, 357.0], [34.2, 357.0], [34.3, 357.0], [34.4, 358.0], [34.5, 358.0], [34.6, 358.0], [34.7, 358.0], [34.8, 358.0], [34.9, 358.0], [35.0, 358.0], [35.1, 358.0], [35.2, 358.0], [35.3, 358.0], [35.4, 359.0], [35.5, 359.0], [35.6, 359.0], [35.7, 359.0], [35.8, 359.0], [35.9, 359.0], [36.0, 359.0], [36.1, 359.0], [36.2, 359.0], [36.3, 359.0], [36.4, 359.0], [36.5, 359.0], [36.6, 359.0], [36.7, 359.0], [36.8, 359.0], [36.9, 359.0], [37.0, 359.0], [37.1, 359.0], [37.2, 359.0], [37.3, 359.0], [37.4, 359.0], [37.5, 359.0], [37.6, 359.0], [37.7, 359.0], [37.8, 359.0], [37.9, 359.0], [38.0, 359.0], [38.1, 359.0], [38.2, 359.0], [38.3, 359.0], [38.4, 359.0], [38.5, 359.0], [38.6, 360.0], [38.7, 360.0], [38.8, 360.0], [38.9, 360.0], [39.0, 360.0], [39.1, 360.0], [39.2, 360.0], [39.3, 360.0], [39.4, 360.0], [39.5, 360.0], [39.6, 360.0], [39.7, 360.0], [39.8, 360.0], [39.9, 360.0], [40.0, 360.0], [40.1, 360.0], [40.2, 360.0], [40.3, 360.0], [40.4, 360.0], [40.5, 360.0], [40.6, 360.0], [40.7, 360.0], [40.8, 361.0], [40.9, 361.0], [41.0, 361.0], [41.1, 361.0], [41.2, 361.0], [41.3, 361.0], [41.4, 361.0], [41.5, 361.0], [41.6, 361.0], [41.7, 361.0], [41.8, 361.0], [41.9, 361.0], [42.0, 361.0], [42.1, 361.0], [42.2, 361.0], [42.3, 361.0], [42.4, 362.0], [42.5, 362.0], [42.6, 362.0], [42.7, 362.0], [42.8, 362.0], [42.9, 362.0], [43.0, 363.0], [43.1, 363.0], [43.2, 363.0], [43.3, 363.0], [43.4, 364.0], [43.5, 364.0], [43.6, 364.0], [43.7, 364.0], [43.8, 364.0], [43.9, 364.0], [44.0, 365.0], [44.1, 365.0], [44.2, 365.0], [44.3, 365.0], [44.4, 365.0], [44.5, 365.0], [44.6, 365.0], [44.7, 365.0], [44.8, 366.0], [44.9, 366.0], [45.0, 366.0], [45.1, 366.0], [45.2, 367.0], [45.3, 367.0], [45.4, 367.0], [45.5, 367.0], [45.6, 367.0], [45.7, 367.0], [45.8, 367.0], [45.9, 367.0], [46.0, 370.0], [46.1, 370.0], [46.2, 371.0], [46.3, 371.0], [46.4, 372.0], [46.5, 372.0], [46.6, 372.0], [46.7, 372.0], [46.8, 374.0], [46.9, 374.0], [47.0, 375.0], [47.1, 375.0], [47.2, 376.0], [47.3, 376.0], [47.4, 376.0], [47.5, 376.0], [47.6, 378.0], [47.7, 378.0], [47.8, 379.0], [47.9, 379.0], [48.0, 380.0], [48.1, 380.0], [48.2, 381.0], [48.3, 381.0], [48.4, 381.0], [48.5, 381.0], [48.6, 384.0], [48.7, 384.0], [48.8, 384.0], [48.9, 384.0], [49.0, 385.0], [49.1, 385.0], [49.2, 386.0], [49.3, 386.0], [49.4, 387.0], [49.5, 387.0], [49.6, 390.0], [49.7, 390.0], [49.8, 391.0], [49.9, 391.0], [50.0, 393.0], [50.1, 393.0], [50.2, 393.0], [50.3, 393.0], [50.4, 393.0], [50.5, 393.0], [50.6, 393.0], [50.7, 393.0], [50.8, 394.0], [50.9, 394.0], [51.0, 396.0], [51.1, 396.0], [51.2, 397.0], [51.3, 397.0], [51.4, 397.0], [51.5, 398.0], [51.6, 398.0], [51.7, 398.0], [51.8, 398.0], [51.9, 399.0], [52.0, 399.0], [52.1, 400.0], [52.2, 400.0], [52.3, 403.0], [52.4, 403.0], [52.5, 403.0], [52.6, 403.0], [52.7, 403.0], [52.8, 403.0], [52.9, 404.0], [53.0, 404.0], [53.1, 404.0], [53.2, 404.0], [53.3, 404.0], [53.4, 404.0], [53.5, 404.0], [53.6, 404.0], [53.7, 404.0], [53.8, 404.0], [53.9, 405.0], [54.0, 405.0], [54.1, 405.0], [54.2, 405.0], [54.3, 405.0], [54.4, 405.0], [54.5, 405.0], [54.6, 405.0], [54.7, 405.0], [54.8, 405.0], [54.9, 405.0], [55.0, 405.0], [55.1, 405.0], [55.2, 405.0], [55.3, 405.0], [55.4, 405.0], [55.5, 405.0], [55.6, 405.0], [55.7, 406.0], [55.8, 406.0], [55.9, 407.0], [56.0, 407.0], [56.1, 407.0], [56.2, 407.0], [56.3, 407.0], [56.4, 407.0], [56.5, 407.0], [56.6, 407.0], [56.7, 408.0], [56.8, 408.0], [56.9, 408.0], [57.0, 408.0], [57.1, 408.0], [57.2, 408.0], [57.3, 408.0], [57.4, 408.0], [57.5, 409.0], [57.6, 409.0], [57.7, 409.0], [57.8, 409.0], [57.9, 409.0], [58.0, 409.0], [58.1, 409.0], [58.2, 409.0], [58.3, 409.0], [58.4, 409.0], [58.5, 409.0], [58.6, 409.0], [58.7, 409.0], [58.8, 409.0], [58.9, 409.0], [59.0, 409.0], [59.1, 409.0], [59.2, 409.0], [59.3, 409.0], [59.4, 409.0], [59.5, 410.0], [59.6, 410.0], [59.7, 410.0], [59.8, 410.0], [59.9, 410.0], [60.0, 410.0], [60.1, 411.0], [60.2, 411.0], [60.3, 411.0], [60.4, 411.0], [60.5, 411.0], [60.6, 411.0], [60.7, 411.0], [60.8, 411.0], [60.9, 412.0], [61.0, 412.0], [61.1, 412.0], [61.2, 412.0], [61.3, 412.0], [61.4, 412.0], [61.5, 413.0], [61.6, 413.0], [61.7, 413.0], [61.8, 413.0], [61.9, 414.0], [62.0, 414.0], [62.1, 414.0], [62.2, 414.0], [62.3, 414.0], [62.4, 414.0], [62.5, 415.0], [62.6, 415.0], [62.7, 415.0], [62.8, 415.0], [62.9, 415.0], [63.0, 415.0], [63.1, 415.0], [63.2, 415.0], [63.3, 415.0], [63.4, 415.0], [63.5, 415.0], [63.6, 415.0], [63.7, 415.0], [63.8, 415.0], [63.9, 415.0], [64.0, 416.0], [64.1, 416.0], [64.2, 416.0], [64.3, 416.0], [64.4, 416.0], [64.5, 416.0], [64.6, 416.0], [64.7, 416.0], [64.8, 416.0], [64.9, 416.0], [65.0, 416.0], [65.1, 416.0], [65.2, 416.0], [65.3, 416.0], [65.4, 416.0], [65.5, 416.0], [65.6, 416.0], [65.7, 416.0], [65.8, 416.0], [65.9, 416.0], [66.0, 417.0], [66.1, 417.0], [66.2, 417.0], [66.3, 417.0], [66.4, 417.0], [66.5, 417.0], [66.6, 417.0], [66.7, 417.0], [66.8, 417.0], [66.9, 417.0], [67.0, 417.0], [67.1, 417.0], [67.2, 417.0], [67.3, 417.0], [67.4, 417.0], [67.5, 417.0], [67.6, 417.0], [67.7, 417.0], [67.8, 417.0], [67.9, 417.0], [68.0, 417.0], [68.1, 417.0], [68.2, 417.0], [68.3, 417.0], [68.4, 417.0], [68.5, 417.0], [68.6, 418.0], [68.7, 418.0], [68.8, 418.0], [68.9, 418.0], [69.0, 418.0], [69.1, 418.0], [69.2, 418.0], [69.3, 418.0], [69.4, 418.0], [69.5, 418.0], [69.6, 418.0], [69.7, 418.0], [69.8, 418.0], [69.9, 418.0], [70.0, 418.0], [70.1, 418.0], [70.2, 418.0], [70.3, 418.0], [70.4, 418.0], [70.5, 418.0], [70.6, 418.0], [70.7, 418.0], [70.8, 418.0], [70.9, 418.0], [71.0, 419.0], [71.1, 419.0], [71.2, 419.0], [71.3, 419.0], [71.4, 419.0], [71.5, 419.0], [71.6, 419.0], [71.7, 419.0], [71.8, 419.0], [71.9, 419.0], [72.0, 419.0], [72.1, 419.0], [72.2, 420.0], [72.3, 420.0], [72.4, 420.0], [72.5, 420.0], [72.6, 420.0], [72.7, 420.0], [72.8, 420.0], [72.9, 420.0], [73.0, 420.0], [73.1, 420.0], [73.2, 420.0], [73.3, 420.0], [73.4, 420.0], [73.5, 420.0], [73.6, 420.0], [73.7, 420.0], [73.8, 420.0], [73.9, 420.0], [74.0, 420.0], [74.1, 420.0], [74.2, 420.0], [74.3, 420.0], [74.4, 420.0], [74.5, 420.0], [74.6, 420.0], [74.7, 420.0], [74.8, 421.0], [74.9, 421.0], [75.0, 421.0], [75.1, 421.0], [75.2, 421.0], [75.3, 421.0], [75.4, 421.0], [75.5, 421.0], [75.6, 421.0], [75.7, 421.0], [75.8, 421.0], [75.9, 421.0], [76.0, 421.0], [76.1, 421.0], [76.2, 421.0], [76.3, 421.0], [76.4, 421.0], [76.5, 421.0], [76.6, 421.0], [76.7, 421.0], [76.8, 422.0], [76.9, 422.0], [77.0, 422.0], [77.1, 422.0], [77.2, 422.0], [77.3, 422.0], [77.4, 422.0], [77.5, 422.0], [77.6, 422.0], [77.7, 422.0], [77.8, 422.0], [77.9, 422.0], [78.0, 422.0], [78.1, 422.0], [78.2, 422.0], [78.3, 422.0], [78.4, 422.0], [78.5, 422.0], [78.6, 422.0], [78.7, 422.0], [78.8, 422.0], [78.9, 422.0], [79.0, 423.0], [79.1, 423.0], [79.2, 423.0], [79.3, 423.0], [79.4, 423.0], [79.5, 423.0], [79.6, 423.0], [79.7, 423.0], [79.8, 423.0], [79.9, 423.0], [80.0, 423.0], [80.1, 423.0], [80.2, 423.0], [80.3, 423.0], [80.4, 423.0], [80.5, 423.0], [80.6, 423.0], [80.7, 423.0], [80.8, 423.0], [80.9, 423.0], [81.0, 423.0], [81.1, 423.0], [81.2, 423.0], [81.3, 423.0], [81.4, 423.0], [81.5, 423.0], [81.6, 423.0], [81.7, 423.0], [81.8, 424.0], [81.9, 424.0], [82.0, 424.0], [82.1, 424.0], [82.2, 424.0], [82.3, 424.0], [82.4, 424.0], [82.5, 424.0], [82.6, 424.0], [82.7, 424.0], [82.8, 424.0], [82.9, 424.0], [83.0, 424.0], [83.1, 424.0], [83.2, 424.0], [83.3, 424.0], [83.4, 424.0], [83.5, 424.0], [83.6, 424.0], [83.7, 424.0], [83.8, 424.0], [83.9, 424.0], [84.0, 424.0], [84.1, 424.0], [84.2, 424.0], [84.3, 424.0], [84.4, 424.0], [84.5, 424.0], [84.6, 424.0], [84.7, 424.0], [84.8, 424.0], [84.9, 424.0], [85.0, 425.0], [85.1, 425.0], [85.2, 425.0], [85.3, 425.0], [85.4, 425.0], [85.5, 425.0], [85.6, 426.0], [85.7, 426.0], [85.8, 426.0], [85.9, 426.0], [86.0, 426.0], [86.1, 426.0], [86.2, 426.0], [86.3, 426.0], [86.4, 426.0], [86.5, 426.0], [86.6, 426.0], [86.7, 426.0], [86.8, 427.0], [86.9, 427.0], [87.0, 427.0], [87.1, 427.0], [87.2, 427.0], [87.3, 427.0], [87.4, 429.0], [87.5, 429.0], [87.6, 430.0], [87.7, 430.0], [87.8, 430.0], [87.9, 430.0], [88.0, 430.0], [88.1, 430.0], [88.2, 431.0], [88.3, 431.0], [88.4, 433.0], [88.5, 433.0], [88.6, 433.0], [88.7, 433.0], [88.8, 434.0], [88.9, 434.0], [89.0, 434.0], [89.1, 434.0], [89.2, 435.0], [89.3, 435.0], [89.4, 436.0], [89.5, 436.0], [89.6, 436.0], [89.7, 438.0], [89.8, 438.0], [89.9, 438.0], [90.0, 438.0], [90.1, 440.0], [90.2, 440.0], [90.3, 441.0], [90.4, 441.0], [90.5, 447.0], [90.6, 447.0], [90.7, 448.0], [90.8, 448.0], [90.9, 450.0], [91.0, 450.0], [91.1, 450.0], [91.2, 450.0], [91.3, 452.0], [91.4, 452.0], [91.5, 456.0], [91.6, 456.0], [91.7, 461.0], [91.8, 461.0], [91.9, 469.0], [92.0, 469.0], [92.1, 475.0], [92.2, 475.0], [92.3, 476.0], [92.4, 476.0], [92.5, 479.0], [92.6, 479.0], [92.7, 480.0], [92.8, 480.0], [92.9, 481.0], [93.0, 481.0], [93.1, 481.0], [93.2, 481.0], [93.3, 491.0], [93.4, 491.0], [93.5, 491.0], [93.6, 491.0], [93.7, 493.0], [93.8, 493.0], [93.9, 497.0], [94.0, 497.0], [94.1, 501.0], [94.2, 501.0], [94.3, 501.0], [94.4, 501.0], [94.5, 502.0], [94.6, 502.0], [94.7, 509.0], [94.8, 509.0], [94.9, 517.0], [95.0, 517.0], [95.1, 519.0], [95.2, 519.0], [95.3, 519.0], [95.4, 519.0], [95.5, 519.0], [95.6, 519.0], [95.7, 521.0], [95.8, 521.0], [95.9, 524.0], [96.0, 524.0], [96.1, 525.0], [96.2, 525.0], [96.3, 527.0], [96.4, 527.0], [96.5, 529.0], [96.6, 529.0], [96.7, 532.0], [96.8, 532.0], [96.9, 534.0], [97.0, 534.0], [97.1, 534.0], [97.2, 534.0], [97.3, 537.0], [97.4, 537.0], [97.5, 539.0], [97.6, 539.0], [97.7, 542.0], [97.8, 542.0], [97.9, 544.0], [98.0, 544.0], [98.1, 544.0], [98.2, 544.0], [98.3, 548.0], [98.4, 548.0], [98.5, 552.0], [98.6, 552.0], [98.7, 552.0], [98.8, 552.0], [98.9, 553.0], [99.0, 553.0], [99.1, 553.0], [99.2, 553.0], [99.3, 554.0], [99.4, 554.0], [99.5, 554.0], [99.6, 554.0], [99.7, 555.0], [99.8, 555.0], [99.9, 558.0], [100.0, 558.0]], "isOverall": false, "label": "SeleccionTarifaYCantidad", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 4.0, "minX": 0.0, "maxY": 210.0, "series": [{"data": [[0.0, 4.0], [300.0, 199.0], [400.0, 210.0], [200.0, 22.0], [100.0, 35.0], [500.0, 30.0]], "isOverall": false, "label": "SeleccionTarifaYCantidad", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 500.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 14.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1.500ms"], [2, "Requests having \nresponse time > 1.500ms"], [3, "Requests in error"]], "maxY": 462.0, "series": [{"data": [[0.0, 24.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 14.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1.500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1.500ms", "isController": false}, {"data": [[3.0, 462.0]], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 500.0, "minX": 1.794629933E12, "maxY": 500.0, "series": [{"data": [[1.794629933E12, 500.0], [1.794629934E12, 500.0]], "isOverall": false, "label": "Usuarios parametrizados - experimentacion", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.794629934E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 370.4900000000001, "minX": 500.0, "maxY": 370.4900000000001, "series": [{"data": [[500.0, 370.4900000000001]], "isOverall": false, "label": "SeleccionTarifaYCantidad", "isController": false}, {"data": [[500.0, 370.4900000000001]], "isOverall": false, "label": "SeleccionTarifaYCantidad-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 500.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 0.0, "minX": 1.794629933E12, "maxY": 620944.0, "series": [{"data": [[1.794629933E12, 610533.0], [1.794629934E12, 620944.0]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.794629933E12, 0.0], [1.794629934E12, 9224.0]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.794629934E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 315.5757575757576, "minX": 1.794629933E12, "maxY": 417.6468401486989, "series": [{"data": [[1.794629933E12, 315.5757575757576], [1.794629934E12, 417.6468401486989]], "isOverall": false, "label": "SeleccionTarifaYCantidad", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.794629934E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.794629933E12, "maxY": 63.69144981412639, "series": [{"data": [[1.794629933E12, 0.0], [1.794629934E12, 63.69144981412639]], "isOverall": false, "label": "SeleccionTarifaYCantidad", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.794629934E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 315.45454545454544, "minX": 1.794629933E12, "maxY": 393.88475836431246, "series": [{"data": [[1.794629933E12, 315.45454545454544], [1.794629934E12, 393.88475836431246]], "isOverall": false, "label": "SeleccionTarifaYCantidad", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.794629934E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 312.0, "minX": 1.794629934E12, "maxY": 555.0, "series": [{"data": [[1.794629934E12, 555.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.794629934E12, 312.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.794629934E12, 553.1]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.794629934E12, 555.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.794629934E12, 477.5]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.794629934E12, 554.05]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.794629934E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 355.0, "minX": 231.0, "maxY": 477.5, "series": [{"data": [[269.0, 477.5]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[269.0, 418.0], [231.0, 355.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 269.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 0.0, "minX": 231.0, "maxY": 477.0, "series": [{"data": [[269.0, 477.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[269.0, 0.0], [231.0, 0.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 269.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 500.0, "minX": 1.794629933E12, "maxY": 500.0, "series": [{"data": [[1.794629933E12, 500.0]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.794629933E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 38.0, "minX": 1.794629933E12, "maxY": 231.0, "series": [{"data": [[1.794629934E12, 38.0]], "isOverall": false, "label": "201", "isController": false}, {"data": [[1.794629933E12, 231.0], [1.794629934E12, 231.0]], "isOverall": false, "label": "Non HTTP response code: org.apache.http.conn.HttpHostConnectException", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.794629934E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 38.0, "minX": 1.794629933E12, "maxY": 231.0, "series": [{"data": [[1.794629933E12, 231.0], [1.794629934E12, 231.0]], "isOverall": false, "label": "SeleccionTarifaYCantidad-failure", "isController": false}, {"data": [[1.794629934E12, 38.0]], "isOverall": false, "label": "SeleccionTarifaYCantidad-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.794629934E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 38.0, "minX": 1.794629933E12, "maxY": 231.0, "series": [{"data": [[1.794629934E12, 38.0]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [[1.794629933E12, 231.0], [1.794629934E12, 231.0]], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.794629934E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -18000000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

